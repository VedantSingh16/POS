import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import type { AuthenticatedRequest } from '../auth/auth.guard.js';
import { PermissionsGuard } from '../auth/permissions.guard.js';
import { RequirePermissions } from '../auth/permissions.decorator.js';
import { AdminService } from './admin.service.js';

@Controller('api/admin')
@UseGuards(AuthGuard, PermissionsGuard)
export class AdminController {
  constructor(private readonly admin: AdminService) {}

  @Get('overview')
  @RequirePermissions('org.overview.view')
  overview(@Req() request: AuthenticatedRequest) {
    return this.admin.getOverview(request.user!);
  }

  @Get('settings')
  @RequirePermissions('org.settings.manage')
  settings(@Req() request: AuthenticatedRequest) {
    return this.admin.getSettings(request.user!);
  }

  @Patch('settings')
  @RequirePermissions('org.settings.manage')
  updateSettings(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.updateSettings(request.user!, body);
  }

  @Get('audit')
  @RequirePermissions('audit.view')
  async audit(@Req() request: AuthenticatedRequest) {
    return { audit: await this.admin.listAuditLogs(request.user!) };
  }

  @Get('users')
  @RequirePermissions('users.view')
  async users(@Req() request: AuthenticatedRequest) {
    return { users: await this.admin.listUsers(request.user!) };
  }

  @Post('users')
  @RequirePermissions('users.manage')
  createUser(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createUser(request.user!, body);
  }

  @Patch('users/:userId')
  @RequirePermissions('users.manage')
  updateUser(@Req() request: AuthenticatedRequest, @Param('userId') userId: string, @Body() body: Record<string, unknown>) {
    return this.admin.updateUser(request.user!, userId, body);
  }

  @Get('roles')
  @RequirePermissions('roles.view')
  async roles(@Req() request: AuthenticatedRequest) {
    return { roles: await this.admin.listRoles(request.user!) };
  }

  @Post('roles')
  @RequirePermissions('roles.manage')
  createRole(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createRole(request.user!, body);
  }

  @Patch('roles/:roleId')
  @RequirePermissions('roles.manage')
  updateRole(@Req() request: AuthenticatedRequest, @Param('roleId') roleId: string, @Body() body: Record<string, unknown>) {
    return this.admin.updateRole(request.user!, roleId, body);
  }

  @Get('stores')
  @RequirePermissions('stores.view')
  async stores(@Req() request: AuthenticatedRequest) {
    return { stores: await this.admin.listStores(request.user!) };
  }

  @Post('stores')
  @RequirePermissions('stores.manage')
  createStore(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createStore(request.user!, body);
  }

  @Patch('stores/:storeId')
  @RequirePermissions('stores.manage')
  updateStore(@Req() request: AuthenticatedRequest, @Param('storeId') storeId: string, @Body() body: Record<string, unknown>) {
    return this.admin.updateStore(request.user!, storeId, body);
  }

  @Get('registers')
  @RequirePermissions('registers.view')
  async registers(@Req() request: AuthenticatedRequest) {
    return { registers: await this.admin.listRegisters(request.user!) };
  }

  @Get('stores/:storeId/registers')
  @RequirePermissions('registers.view')
  async storeRegisters(@Req() request: AuthenticatedRequest, @Param('storeId') storeId: string) {
    return { registers: await this.admin.listRegisters(request.user!, storeId) };
  }

  @Post('stores/:storeId/registers')
  @RequirePermissions('registers.manage')
  createRegister(@Req() request: AuthenticatedRequest, @Param('storeId') storeId: string, @Body() body: Record<string, unknown>) {
    return this.admin.createRegister(request.user!, storeId, body);
  }

  @Patch('registers/:registerId')
  @RequirePermissions('registers.manage')
  updateRegister(@Req() request: AuthenticatedRequest, @Param('registerId') registerId: string, @Body() body: Record<string, unknown>) {
    return this.admin.updateRegister(request.user!, registerId, body);
  }

  @Get('catalog/categories')
  @RequirePermissions('catalog.view')
  async categories(@Req() request: AuthenticatedRequest) {
    return { categories: await this.admin.listCategories(request.user!) };
  }

  @Post('catalog/categories')
  @RequirePermissions('catalog.manage')
  createCategory(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createCategory(request.user!, body);
  }

  @Get('catalog/uoms')
  @RequirePermissions('catalog.view')
  async uoms(@Req() request: AuthenticatedRequest) {
    return { units: await this.admin.listUoms(request.user!) };
  }

  @Post('catalog/uoms')
  @RequirePermissions('catalog.manage')
  createUom(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createUom(request.user!, body);
  }

  @Get('catalog/tax-groups')
  @RequirePermissions('tax.view')
  async taxGroups(@Req() request: AuthenticatedRequest) {
    return { taxGroups: await this.admin.listTaxGroups(request.user!) };
  }

  @Post('catalog/tax-groups')
  @RequirePermissions('tax.manage')
  createTaxGroup(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createTaxGroup(request.user!, body);
  }

  @Get('catalog/products')
  @RequirePermissions('catalog.view')
  async products(@Req() request: AuthenticatedRequest) {
    return { products: await this.admin.listProducts(request.user!) };
  }

  @Post('catalog/products')
  @RequirePermissions('catalog.manage')
  createProduct(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) {
    return this.admin.createProduct(request.user!, body);
  }

  @Post('catalog/products/:productId/variants')
  @RequirePermissions('catalog.manage')
  createVariant(@Req() request: AuthenticatedRequest, @Param('productId') productId: string, @Body() body: Record<string, unknown>) {
    return this.admin.createVariant(request.user!, productId, body);
  }
}
