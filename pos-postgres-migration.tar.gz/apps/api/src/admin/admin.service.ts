import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { AuditService } from '../audit/audit.service.js';
import { AuthService } from '../auth/auth.service.js';
import { UserContext } from '../auth/auth.types.js';
import { ORGANISATION_ADMINISTRATOR_ROLE } from '../auth/permission-catalogue.js';
import { JsonObject, optionalString, requiredString, stringArray, uuid } from '../common/input.js';
import { isUniqueViolation, Tx } from '../database/db.js';
import { PrismaService } from '../database/prisma.service.js';
import { Prisma, ProductStatus, RecordStatus, UserStatus } from '../generated/prisma/client.js';

type RoleAssignmentInput = { roleId: string; scopeType: 'ORGANIZATION' | 'STORE'; storeId: string | null };

const USER_STATUSES: readonly string[] = Object.values(UserStatus);
const RECORD_STATUSES: readonly string[] = Object.values(RecordStatus);
const PRODUCT_STATUSES: readonly string[] = Object.values(ProductStatus);

const SETTINGS_KEYS = ['receiptFooter', 'defaultTaxInclusive', 'defaultStoreId', 'notificationEmail'] as const;

const userInclude = {
  roles: { include: { role: { select: { id: true, name: true } } }, orderBy: { role: { name: 'asc' } } },
  stores: { select: { storeId: true } },
} satisfies Prisma.UserInclude;

type UserWithAccess = Prisma.UserGetPayload<{ include: typeof userInclude }>;

const productInclude = {
  variants: {
    orderBy: { name: 'asc' },
    include: {
      uom: { select: { code: true } },
      taxGroup: { select: { code: true } },
      barcodes: { select: { code: true }, orderBy: { code: 'asc' } },
      prices: { orderBy: { effectiveFrom: 'desc' } },
    },
  },
} satisfies Prisma.ProductInclude;

type ProductWithVariants = Prisma.ProductGetPayload<{ include: typeof productInclude }>;

@Injectable()
export class AdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly auth: AuthService,
    private readonly audit: AuditService,
  ) {}

  // ───────────── Organisation ─────────────

  async getOverview(context: UserContext) {
    const organizationId = context.organizationId;
    const [organization, entitlement, activeStores, activeUsers, activeRegisters] = await Promise.all([
      this.prisma.organization.findUnique({ where: { id: organizationId } }),
      this.prisma.organizationEntitlement.findUnique({ where: { organizationId } }),
      this.prisma.store.count({ where: { organizationId, status: 'ACTIVE' } }),
      this.prisma.user.count({ where: { organizationId, status: 'ACTIVE' } }),
      this.prisma.register.count({ where: { organizationId, status: 'ACTIVE' } }),
    ]);
    if (!organization) throw new NotFoundException('Organisation not found');
    const maxStores = entitlement?.maxStores ?? 0;
    return {
      organization,
      entitlement: { maxStores, currentStores: activeStores, remainingStores: Math.max(0, maxStores - activeStores) },
      counts: { activeUsers, activeRegisters },
      administrator: context,
    };
  }

  async getSettings(context: UserContext) {
    const row = await this.prisma.organizationSettings.findUnique({ where: { organizationId: context.organizationId } });
    return { settings: (row?.settings ?? {}) as JsonObject };
  }

  async updateSettings(context: UserContext, input: JsonObject) {
    const next: JsonObject = { ...(await this.getSettings(context)).settings };
    for (const key of SETTINGS_KEYS) {
      if (key in input) next[key] = input[key];
    }
    if (typeof next.defaultStoreId === 'string') {
      await this.ensureStore(context.organizationId, uuid(next.defaultStoreId, 'defaultStoreId'));
    }
    await this.prisma.$transaction(async (tx) => {
      await tx.organizationSettings.upsert({
        where: { organizationId: context.organizationId },
        create: { organizationId: context.organizationId, settings: next as Prisma.InputJsonObject },
        update: { settings: next as Prisma.InputJsonObject },
      });
      await this.audit.record(context, 'organization.settings.updated', 'OrganizationSettings', context.organizationId, { keys: Object.keys(input) }, tx);
    });
    return { settings: next };
  }

  async listAuditLogs(context: UserContext) {
    const logs = await this.prisma.auditLog.findMany({
      where: { organizationId: context.organizationId },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    return logs.map(({ organizationId: _organizationId, ...log }) => log);
  }

  // ───────────── Users ─────────────

  async listUsers(context: UserContext) {
    const users = await this.prisma.user.findMany({
      where: { organizationId: context.organizationId },
      include: userInclude,
      orderBy: [{ firstName: 'asc' }, { lastName: 'asc' }, { email: 'asc' }],
    });
    return users.map((user) => this.userDto(user));
  }

  async createUser(context: UserContext, input: JsonObject) {
    const email = this.email(input.email);
    const password = requiredString(input.password, 'password');
    if (password.length < 12) throw new BadRequestException('Password must be at least 12 characters');
    const firstName = requiredString(input.firstName, 'firstName');
    const lastName = optionalString(input.lastName) ?? '';
    const storeIds = stringArray(input.storeIds).map((id) => uuid(id, 'storeIds'));
    const assignments = this.roleAssignments(input);
    if (assignments.length === 0) throw new BadRequestException('At least one role is required');
    await this.validateAccess(context.organizationId, storeIds, assignments);

    try {
      const userId = await this.prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            organizationId: context.organizationId,
            email,
            passwordHash: this.auth.hashPassword(password),
            firstName,
            lastName,
            defaultStoreId: storeIds[0] ?? null,
          },
        });
        await this.writeAccess(tx, context.organizationId, user.id, assignments, storeIds);
        await this.audit.record(context, 'user.created', 'User', user.id, { email }, tx);
        return user.id;
      });
      return await this.getUser(context, userId);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A user with this email already exists');
      throw error;
    }
  }

  async updateUser(context: UserContext, userId: string, input: JsonObject) {
    const user = await this.ensureUser(context.organizationId, userId);
    const nextStatus = typeof input.status === 'string' ? input.status.toUpperCase() : undefined;
    if (nextStatus && !USER_STATUSES.includes(nextStatus)) throw new BadRequestException('Invalid user status');
    if (user.status === 'ACTIVE' && nextStatus && nextStatus !== 'ACTIVE') {
      await this.assertNotLastAdministrator(context.organizationId, userId);
    }

    const storeIds = input.storeIds === undefined ? undefined : stringArray(input.storeIds).map((id) => uuid(id, 'storeIds'));
    const assignments = input.roleIds === undefined && input.roleAssignments === undefined ? undefined : this.roleAssignments(input);
    if (assignments && assignments.length === 0) throw new BadRequestException('At least one role is required');
    await this.validateAccess(context.organizationId, storeIds ?? [], assignments ?? []);
    if (assignments) {
      const stillAdministrator = await this.holdsAdministratorRole(assignments);
      if (!stillAdministrator) await this.assertNotLastAdministrator(context.organizationId, userId);
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: {
          firstName: optionalString(input.firstName) ?? user.firstName,
          lastName: optionalString(input.lastName) ?? user.lastName,
          ...(nextStatus ? { status: nextStatus as UserStatus } : {}),
          ...(storeIds ? { defaultStoreId: storeIds[0] ?? null } : {}),
        },
      });
      if (storeIds) await tx.userStore.deleteMany({ where: { userId } });
      if (assignments) await tx.userRole.deleteMany({ where: { userId } });
      await this.writeAccess(tx, context.organizationId, userId, assignments ?? [], storeIds ?? []);
      await this.audit.record(context, 'user.updated', 'User', userId, { status: nextStatus, storeIdsChanged: Boolean(storeIds), rolesChanged: Boolean(assignments) }, tx);
    });
    return this.getUser(context, userId);
  }

  // ───────────── Roles ─────────────

  async listRoles(context: UserContext) {
    const roles = await this.prisma.role.findMany({
      where: { organizationId: context.organizationId },
      include: { permissions: { select: { permissionCode: true }, orderBy: { permissionCode: 'asc' } } },
      orderBy: [{ isSystem: 'desc' }, { name: 'asc' }],
    });
    return roles.map((role) => this.roleDto(role));
  }

  async createRole(context: UserContext, input: JsonObject) {
    const name = requiredString(input.name, 'name');
    const description = optionalString(input.description) ?? '';
    const permissions = stringArray(input.permissions);
    await this.ensurePermissions(permissions);
    try {
      const role = await this.prisma.$transaction(async (tx) => {
        const created = await tx.role.create({
          data: {
            organizationId: context.organizationId,
            name,
            description,
            permissions: { create: [...new Set(permissions)].map((permissionCode) => ({ permissionCode })) },
          },
          include: { permissions: { select: { permissionCode: true }, orderBy: { permissionCode: 'asc' } } },
        });
        await this.audit.record(context, 'role.created', 'Role', created.id, { name, permissions }, tx);
        return created;
      });
      return this.roleDto(role);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A role with this name already exists');
      throw error;
    }
  }

  async updateRole(context: UserContext, roleId: string, input: JsonObject) {
    const role = await this.prisma.role.findFirst({ where: { id: roleId, organizationId: context.organizationId } });
    if (!role) throw new NotFoundException('Role not found');
    if (role.isSystem) throw new BadRequestException('System roles cannot be edited');

    const status = typeof input.status === 'string' ? input.status.toUpperCase() : undefined;
    if (status && !RECORD_STATUSES.includes(status)) throw new BadRequestException('Invalid role status');
    if (status === 'DISABLED' && (await this.prisma.userRole.count({ where: { roleId } })) > 0) {
      throw new ConflictException('Reassign users before disabling this role');
    }
    const permissions = input.permissions === undefined ? undefined : stringArray(input.permissions);
    if (permissions) await this.ensurePermissions(permissions);

    try {
      const updated = await this.prisma.$transaction(async (tx) => {
        await tx.role.update({
          where: { id: roleId },
          data: {
            name: optionalString(input.name) || role.name,
            ...(optionalString(input.description) !== undefined ? { description: optionalString(input.description) } : {}),
            ...(status ? { status: status as RecordStatus } : {}),
          },
        });
        if (permissions) {
          await tx.rolePermission.deleteMany({ where: { roleId } });
          await tx.rolePermission.createMany({ data: [...new Set(permissions)].map((permissionCode) => ({ roleId, permissionCode })) });
        }
        await this.audit.record(context, 'role.updated', 'Role', roleId, { name: input.name, status, permissionsChanged: Boolean(permissions) }, tx);
        return tx.role.findUniqueOrThrow({
          where: { id: roleId },
          include: { permissions: { select: { permissionCode: true }, orderBy: { permissionCode: 'asc' } } },
        });
      });
      return this.roleDto(updated);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A role with this name already exists');
      throw error;
    }
  }

  // ───────────── Stores & registers ─────────────

  async listStores(context: UserContext) {
    const stores = await this.prisma.store.findMany({
      where: { organizationId: context.organizationId, ...(this.hasOrganizationScope(context, 'stores.view') ? {} : { id: { in: context.storeIds } }) },
      include: { _count: { select: { registers: { where: { status: 'ACTIVE' } } } } },
      orderBy: { name: 'asc' },
    });
    return stores.map(({ _count, organizationId: _organizationId, ...store }) => ({ ...store, registerCount: _count.registers }));
  }

  async createStore(context: UserContext, input: JsonObject) {
    const code = requiredString(input.code, 'code').toUpperCase();
    const name = requiredString(input.name, 'name');
    const address = optionalString(input.address) ?? '';
    const timezone = optionalString(input.timezone) || 'Asia/Kolkata';

    try {
      const storeId = await this.prisma.$transaction(async (tx) => {
        // Serialise concurrent store creation for this organisation so the platform limit cannot be exceeded.
        await tx.$queryRaw`SELECT id FROM organizations WHERE id = ${context.organizationId}::uuid FOR UPDATE`;
        const organization = await tx.organization.findUnique({ where: { id: context.organizationId }, select: { status: true } });
        if (!organization || organization.status !== 'ACTIVE') throw new BadRequestException('Organisation is not active');
        const entitlement = await tx.organizationEntitlement.findUnique({ where: { organizationId: context.organizationId } });
        const current = await tx.store.count({ where: { organizationId: context.organizationId, status: 'ACTIVE' } });
        if (!entitlement || current >= entitlement.maxStores) {
          throw new ConflictException(`Store limit reached (${entitlement?.maxStores ?? 0})`);
        }
        const store = await tx.store.create({ data: { organizationId: context.organizationId, code, name, address, timezone } });
        await tx.stockLocation.create({
          data: { organizationId: context.organizationId, storeId: store.id, code: `${code}-STOCKROOM`, name: `${name} Stockroom` },
        });
        await this.audit.record(context, 'store.created', 'Store', store.id, { code, name }, tx);
        return store.id;
      });
      return await this.getStore(context, storeId);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A store with this code already exists');
      throw error;
    }
  }

  async updateStore(context: UserContext, storeId: string, input: JsonObject) {
    await this.ensureStore(context.organizationId, storeId);
    const status = typeof input.status === 'string' ? input.status.toUpperCase() : undefined;
    if (status && !RECORD_STATUSES.includes(status)) throw new BadRequestException('Invalid store status');
    await this.prisma.$transaction(async (tx) => {
      await tx.store.update({
        where: { id: storeId },
        data: {
          ...(optionalString(input.name) ? { name: optionalString(input.name) } : {}),
          ...(optionalString(input.address) !== undefined ? { address: optionalString(input.address) } : {}),
          ...(optionalString(input.timezone) ? { timezone: optionalString(input.timezone) } : {}),
          ...(status ? { status: status as RecordStatus } : {}),
        },
      });
      await this.audit.record(context, 'store.updated', 'Store', storeId, { status }, tx);
    });
    return this.getStore(context, storeId);
  }

  async listRegisters(context: UserContext, storeId?: string) {
    const organizationWide = this.hasOrganizationScope(context, 'registers.view');
    if (storeId) {
      await this.ensureStore(context.organizationId, storeId);
      if (!organizationWide && !context.storeIds.includes(storeId)) throw new ForbiddenException('User does not have access to this store');
    }
    const registers = await this.prisma.register.findMany({
      where: {
        organizationId: context.organizationId,
        storeId: storeId ?? (organizationWide ? undefined : { in: context.storeIds }),
      },
      orderBy: [{ storeId: 'asc' }, { name: 'asc' }],
    });
    return registers.map((register) => this.registerDto(register));
  }

  async createRegister(context: UserContext, storeId: string, input: JsonObject) {
    await this.ensureStore(context.organizationId, storeId);
    const code = requiredString(input.code, 'code').toUpperCase();
    const name = requiredString(input.name, 'name');
    try {
      const register = await this.prisma.$transaction(async (tx) => {
        const created = await tx.register.create({ data: { organizationId: context.organizationId, storeId, code, name } });
        await this.audit.record(context, 'register.created', 'Register', created.id, { storeId, code }, tx);
        return created;
      });
      return this.registerDto(register);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A register with this code already exists in the store');
      throw error;
    }
  }

  async updateRegister(context: UserContext, registerId: string, input: JsonObject) {
    const register = await this.prisma.register.findFirst({ where: { id: registerId, organizationId: context.organizationId } });
    if (!register) throw new NotFoundException('Register not found');
    const status = typeof input.status === 'string' ? input.status.toUpperCase() : undefined;
    if (status && !RECORD_STATUSES.includes(status)) throw new BadRequestException('Invalid register status');
    const updated = await this.prisma.$transaction(async (tx) => {
      const result = await tx.register.update({
        where: { id: registerId },
        data: { ...(optionalString(input.name) ? { name: optionalString(input.name) } : {}), ...(status ? { status: status as RecordStatus } : {}) },
      });
      await this.audit.record(context, 'register.updated', 'Register', registerId, { status }, tx);
      return result;
    });
    return this.registerDto(updated);
  }

  // ───────────── Catalogue ─────────────

  async listCategories(context: UserContext) {
    const categories = await this.prisma.category.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return categories.map(({ organizationId: _organizationId, ...category }) => category);
  }

  async createCategory(context: UserContext, input: JsonObject) {
    const name = requiredString(input.name, 'name');
    const parentId = typeof input.parentId === 'string' ? uuid(input.parentId, 'parentId') : null;
    if (parentId && !(await this.prisma.category.findFirst({ where: { id: parentId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new BadRequestException('Parent category not found');
    }
    const category = await this.prisma.$transaction(async (tx) => {
      const created = await tx.category.create({ data: { organizationId: context.organizationId, parentId, name } });
      await this.audit.record(context, 'category.created', 'Category', created.id, { name }, tx);
      return created;
    });
    const { organizationId: _organizationId, ...dto } = category;
    return dto;
  }

  async listUoms(context: UserContext) {
    const uoms = await this.prisma.unitOfMeasure.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return uoms.map(({ organizationId: _organizationId, ...uom }) => uom);
  }

  async createUom(context: UserContext, input: JsonObject) {
    const code = requiredString(input.code, 'code').toUpperCase();
    const name = requiredString(input.name, 'name');
    try {
      const uom = await this.prisma.$transaction(async (tx) => {
        const created = await tx.unitOfMeasure.create({
          data: { organizationId: context.organizationId, code, name, allowsDecimal: input.allowsDecimal === true },
        });
        await this.audit.record(context, 'uom.created', 'UnitOfMeasure', created.id, { code }, tx);
        return created;
      });
      const { organizationId: _organizationId, ...dto } = uom;
      return dto;
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A unit of measure with this code already exists');
      throw error;
    }
  }

  async listTaxGroups(context: UserContext) {
    const groups = await this.prisma.taxGroup.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return groups.map((group) => this.taxGroupDto(group));
  }

  async createTaxGroup(context: UserContext, input: JsonObject) {
    const code = requiredString(input.code, 'code').toUpperCase();
    const name = requiredString(input.name, 'name');
    const ratePercent = Number(input.ratePercent);
    if (!Number.isFinite(ratePercent) || ratePercent < 0 || ratePercent > 100) {
      throw new BadRequestException('ratePercent must be between 0 and 100');
    }
    try {
      const group = await this.prisma.$transaction(async (tx) => {
        const created = await tx.taxGroup.create({
          data: { organizationId: context.organizationId, code, name, rateBps: Math.round(ratePercent * 100) },
        });
        await this.audit.record(context, 'tax-group.created', 'TaxGroup', created.id, { code, ratePercent }, tx);
        return created;
      });
      return this.taxGroupDto(group);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A tax group with this code already exists');
      throw error;
    }
  }

  async listProducts(context: UserContext) {
    const products = await this.prisma.product.findMany({
      where: { organizationId: context.organizationId },
      include: productInclude,
      orderBy: { name: 'asc' },
    });
    return products.map((product) => this.productDto(product));
  }

  async createProduct(context: UserContext, input: JsonObject) {
    const name = requiredString(input.name, 'name');
    const categoryId = typeof input.categoryId === 'string' ? uuid(input.categoryId, 'categoryId') : null;
    if (categoryId && !(await this.prisma.category.findFirst({ where: { id: categoryId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new BadRequestException('Category not found');
    }
    const status = this.productStatus(input.status);
    const product = await this.prisma.$transaction(async (tx) => {
      const created = await tx.product.create({
        data: {
          organizationId: context.organizationId,
          categoryId,
          name,
          description: optionalString(input.description) ?? '',
          brand: optionalString(input.brand) ?? '',
          status,
        },
        include: productInclude,
      });
      await this.audit.record(context, 'product.created', 'Product', created.id, { name }, tx);
      return created;
    });
    return this.productDto(product);
  }

  async createVariant(context: UserContext, productId: string, input: JsonObject) {
    const product = await this.prisma.product.findFirst({ where: { id: productId, organizationId: context.organizationId }, select: { id: true } });
    if (!product) throw new NotFoundException('Product not found');
    const sku = requiredString(input.sku, 'sku').toUpperCase();
    const name = requiredString(input.name, 'name');
    const uomId = typeof input.uomId === 'string' ? uuid(input.uomId, 'uomId') : null;
    const taxGroupId = typeof input.taxGroupId === 'string' ? uuid(input.taxGroupId, 'taxGroupId') : null;
    if (uomId && !(await this.prisma.unitOfMeasure.findFirst({ where: { id: uomId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new BadRequestException('Unit of measure not found');
    }
    if (taxGroupId && !(await this.prisma.taxGroup.findFirst({ where: { id: taxGroupId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new BadRequestException('Tax group not found');
    }
    let amountCents: number | undefined;
    if (input.amountCents !== undefined) {
      amountCents = Number(input.amountCents);
      if (!Number.isInteger(amountCents) || amountCents < 0) throw new BadRequestException('amountCents must be a non-negative integer');
    }
    const barcode = optionalString(input.barcode);
    const status = this.productStatus(input.status);

    try {
      await this.prisma.$transaction(async (tx) => {
        const variant = await tx.productVariant.create({
          data: { organizationId: context.organizationId, productId, sku, name, status, uomId, taxGroupId },
        });
        if (barcode) await tx.barcode.create({ data: { organizationId: context.organizationId, variantId: variant.id, code: barcode } });
        if (amountCents !== undefined) {
          await tx.variantPrice.create({
            data: {
              organizationId: context.organizationId,
              variantId: variant.id,
              amountCents,
              currency: optionalString(input.currency) || 'INR',
              includesTax: input.includesTax === true,
            },
          });
        }
        await this.audit.record(context, 'product-variant.created', 'ProductVariant', variant.id, { productId, sku }, tx);
      });
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('SKU or barcode already exists');
      throw error;
    }
    const updated = await this.prisma.product.findUniqueOrThrow({ where: { id: productId }, include: productInclude });
    return this.productDto(updated);
  }

  // ───────────── Helpers ─────────────

  private async getUser(context: UserContext, userId: string) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, organizationId: context.organizationId }, include: userInclude });
    if (!user) throw new NotFoundException('User not found');
    return this.userDto(user);
  }

  private async ensureUser(organizationId: string, userId: string) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, organizationId } });
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  private async ensureStore(organizationId: string, storeId: string) {
    const store = await this.prisma.store.findFirst({ where: { id: storeId, organizationId } });
    if (!store) throw new NotFoundException('Store not found');
    return store;
  }

  private async getStore(context: UserContext, storeId: string) {
    const store = await this.ensureStore(context.organizationId, storeId);
    const registers = await this.prisma.register.findMany({ where: { storeId, organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    const { organizationId: _organizationId, ...dto } = store;
    return { ...dto, registers: registers.map((register) => this.registerDto(register)) };
  }

  private hasOrganizationScope(context: UserContext, permissionCode: string): boolean {
    return context.isOrganisationAdministrator
      || context.grants.some((grant) => grant.permissionCode === permissionCode && grant.scopeType === 'ORGANIZATION');
  }

  private async ensurePermissions(permissionCodes: string[]) {
    const known = new Set((await this.prisma.permission.findMany({ select: { code: true } })).map((permission) => permission.code));
    const unknown = permissionCodes.filter((permission) => !known.has(permission));
    if (unknown.length) throw new BadRequestException(`Unknown permissions: ${unknown.join(', ')}`);
  }

  /** Every referenced store and active role must belong to the caller's organisation. */
  private async validateAccess(organizationId: string, storeIds: string[], assignments: RoleAssignmentInput[]) {
    const allStoreIds = [...new Set([...storeIds, ...assignments.flatMap((a) => (a.storeId ? [a.storeId] : []))])];
    if (allStoreIds.length) {
      const found = await this.prisma.store.count({ where: { organizationId, id: { in: allStoreIds } } });
      if (found !== allStoreIds.length) throw new NotFoundException('Store not found');
    }
    const roleIds = [...new Set(assignments.map((a) => a.roleId))];
    if (roleIds.length) {
      const found = await this.prisma.role.findMany({ where: { organizationId, status: 'ACTIVE', id: { in: roleIds } }, select: { id: true } });
      const missing = roleIds.filter((id) => !found.some((role) => role.id === id));
      if (missing.length) throw new BadRequestException(`Role not found: ${missing[0]}`);
    }
  }

  private async writeAccess(tx: Tx, organizationId: string, userId: string, assignments: RoleAssignmentInput[], storeIds: string[]) {
    if (assignments.length) {
      await tx.userRole.createMany({
        data: assignments.map((a) => ({ organizationId, userId, roleId: a.roleId, scopeType: a.scopeType, storeId: a.scopeType === 'STORE' ? a.storeId : null })),
        skipDuplicates: true,
      });
    }
    if (storeIds.length) {
      await tx.userStore.createMany({
        data: [...new Set(storeIds)].map((storeId, index) => ({ userId, storeId, isDefault: index === 0 })),
      });
    }
  }

  private roleAssignments(input: JsonObject): RoleAssignmentInput[] {
    if (Array.isArray(input.roleAssignments)) {
      return input.roleAssignments.map((assignment) => {
        if (!assignment || typeof assignment !== 'object') throw new BadRequestException('Invalid role assignment');
        const value = assignment as JsonObject;
        const scopeType = value.scopeType === 'STORE' ? 'STORE' : 'ORGANIZATION';
        return {
          roleId: uuid(value.roleId, 'roleId'),
          scopeType,
          storeId: scopeType === 'STORE' ? uuid(value.scopeId ?? value.storeId, 'scopeId') : null,
        } as RoleAssignmentInput;
      });
    }
    return stringArray(input.roleIds).map((roleId) => ({ roleId: uuid(roleId, 'roleIds'), scopeType: 'ORGANIZATION' as const, storeId: null }));
  }

  private async holdsAdministratorRole(assignments: RoleAssignmentInput[]): Promise<boolean> {
    const roles = await this.prisma.role.findMany({
      where: { id: { in: assignments.filter((a) => a.scopeType === 'ORGANIZATION').map((a) => a.roleId) }, name: ORGANISATION_ADMINISTRATOR_ROLE },
      select: { id: true },
    });
    return roles.length > 0;
  }

  private async assertNotLastAdministrator(organizationId: string, userId: string) {
    const isAdministrator = await this.prisma.userRole.count({ where: { userId, role: { name: ORGANISATION_ADMINISTRATOR_ROLE } } });
    if (!isAdministrator) return;
    const administrators = await this.prisma.user.count({
      where: { organizationId, status: 'ACTIVE', roles: { some: { role: { name: ORGANISATION_ADMINISTRATOR_ROLE } } } },
    });
    if (administrators <= 1) throw new ConflictException('The last active Organisation Administrator cannot be disabled');
  }

  private productStatus(value: unknown): ProductStatus {
    if (value === undefined) return 'ACTIVE';
    const status = typeof value === 'string' ? value.toUpperCase() : '';
    if (!PRODUCT_STATUSES.includes(status)) throw new BadRequestException(`status must be one of: ${PRODUCT_STATUSES.join(', ')}`);
    return status as ProductStatus;
  }

  private email(value: unknown): string {
    if (typeof value !== 'string' || !/^\S+@\S+\.\S+$/.test(value.trim())) throw new BadRequestException('A valid email is required');
    return value.trim().toLowerCase();
  }

  // ───────────── DTO mapping ─────────────

  private userDto(user: UserWithAccess) {
    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      status: user.status,
      defaultStoreId: user.defaultStoreId,
      lastLoginAt: user.lastLoginAt,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
      roles: user.roles.map((assignment) => ({
        id: assignment.role.id,
        name: assignment.role.name,
        scopeType: assignment.scopeType,
        scopeId: assignment.storeId,
      })),
      storeIds: user.stores.map((store) => store.storeId),
    };
  }

  private roleDto(role: Prisma.RoleGetPayload<{ include: { permissions: { select: { permissionCode: true } } } }>) {
    return {
      id: role.id,
      name: role.name,
      description: role.description,
      isSystem: role.isSystem,
      status: role.status,
      createdAt: role.createdAt,
      updatedAt: role.updatedAt,
      permissions: role.permissions.map((permission) => permission.permissionCode),
    };
  }

  private registerDto(register: { id: string; storeId: string; code: string; name: string; status: RecordStatus; createdAt: Date; updatedAt: Date }) {
    return {
      id: register.id,
      storeId: register.storeId,
      code: register.code,
      name: register.name,
      status: register.status,
      createdAt: register.createdAt,
      updatedAt: register.updatedAt,
    };
  }

  private taxGroupDto(group: { id: string; code: string; name: string; rateBps: number; createdAt: Date; updatedAt: Date }) {
    return {
      id: group.id,
      code: group.code,
      name: group.name,
      rateBps: group.rateBps,
      ratePercent: group.rateBps / 100,
      createdAt: group.createdAt,
      updatedAt: group.updatedAt,
    };
  }

  private productDto(product: ProductWithVariants) {
    return {
      id: product.id,
      categoryId: product.categoryId,
      name: product.name,
      description: product.description,
      brand: product.brand,
      status: product.status,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
      variants: product.variants.map((variant) => ({
        id: variant.id,
        productId: variant.productId,
        sku: variant.sku,
        name: variant.name,
        status: variant.status,
        uomId: variant.uomId,
        taxGroupId: variant.taxGroupId,
        uomCode: variant.uom?.code ?? null,
        taxCode: variant.taxGroup?.code ?? null,
        createdAt: variant.createdAt,
        updatedAt: variant.updatedAt,
        barcodes: variant.barcodes.map((barcode) => barcode.code),
        prices: variant.prices.map((price) => ({
          id: price.id,
          storeId: price.storeId,
          amountCents: price.amountCents,
          currency: price.currency,
          includesTax: price.includesTax,
          effectiveFrom: price.effectiveFrom,
        })),
      })),
    };
  }
}
