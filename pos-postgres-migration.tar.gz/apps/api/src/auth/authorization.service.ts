import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service.js';
import { ORGANISATION_ADMINISTRATOR_ROLE } from './permission-catalogue.js';
import { PermissionGrant, UserContext } from './auth.types.js';

@Injectable()
export class AuthorizationService {
  constructor(private readonly prisma: PrismaService) {}

  async getUserContext(userId: string): Promise<UserContext> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        stores: { select: { storeId: true } },
        roles: {
          where: { role: { status: 'ACTIVE' } },
          include: { role: { select: { name: true, permissions: { select: { permissionCode: true } } } } },
        },
      },
    });

    if (!user || user.status !== 'ACTIVE') throw new ForbiddenException('User is not active');

    const grants: PermissionGrant[] = user.roles.flatMap((assignment) =>
      assignment.role.permissions.map((permission) => ({
        permissionCode: permission.permissionCode,
        roleName: assignment.role.name,
        scopeType: assignment.scopeType,
        scopeId: assignment.storeId,
      })),
    );

    return {
      userId: user.id,
      organizationId: user.organizationId,
      email: user.email,
      displayName: `${user.firstName} ${user.lastName}`.trim(),
      status: user.status,
      defaultStoreId: user.defaultStoreId,
      storeIds: user.stores.map((store) => store.storeId),
      grants,
      isOrganisationAdministrator: grants.some((grant) => grant.roleName === ORGANISATION_ADMINISTRATOR_ROLE),
    };
  }

  hasPermission(context: UserContext, permissionCode: string, storeId?: string): boolean {
    return context.grants.some((grant) => {
      if (grant.permissionCode !== permissionCode) return false;
      if (grant.scopeType === 'ORGANIZATION') return true;
      return Boolean(storeId && grant.scopeType === 'STORE' && grant.scopeId === storeId);
    });
  }

  canAccessStore(context: UserContext, storeId: string): boolean {
    if (context.isOrganisationAdministrator) return true;
    return context.storeIds.includes(storeId) || context.grants.some(
      (grant) => grant.scopeType === 'STORE' && grant.scopeId === storeId,
    );
  }

  assertPermissions(context: UserContext, permissionCodes: string[], storeId?: string): void {
    const missing = permissionCodes.filter((permission) => !this.hasPermission(context, permission, storeId));
    if (missing.length > 0) throw new ForbiddenException(`Missing permission: ${missing.join(', ')}`);
  }

  assertStoreAccess(context: UserContext, storeId: string): void {
    if (!this.canAccessStore(context, storeId)) throw new ForbiddenException('User does not have access to this store');
  }
}
