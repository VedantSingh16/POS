/** Every permission code the API can enforce, with its description. Seeded into `permissions`. */
export const PERMISSIONS: ReadonlyArray<readonly [string, string]> = [
  ['org.settings.manage', 'Manage organisation settings'],
  ['org.overview.view', 'View organisation overview'],
  ['users.view', 'View organisation users'],
  ['users.manage', 'Create and manage organisation users'],
  ['roles.view', 'View roles and permissions'],
  ['roles.manage', 'Create and manage roles and permissions'],
  ['stores.view', 'View stores'],
  ['stores.manage', 'Create and manage stores'],
  ['registers.view', 'View registers'],
  ['registers.manage', 'Create and manage registers'],
  ['catalog.view', 'View the product catalogue'],
  ['catalog.manage', 'Create and manage catalogue records'],
  ['pricing.view', 'View prices'],
  ['pricing.manage', 'Manage prices'],
  ['tax.view', 'View tax groups'],
  ['tax.manage', 'Manage tax groups'],
  ['audit.view', 'View audit activity'],
  ['report.view', 'View reports'],
  ['report.export', 'Export reports'],
  ['sale.create', 'Create sales'],
  ['sale.hold', 'Hold and resume sales'],
  ['sale.discount', 'Apply discounts'],
  ['sale.void', 'Void sales'],
  ['register.open', 'Open a register'],
  ['register.close', 'Close a register'],
  ['cash.manage', 'Manage cash movements'],
  ['inventory.view', 'View inventory'],
  ['inventory.manage', 'Adjust inventory'],
  ['refund.create', 'Create refunds and returns'],
  ['approval.manage', 'Approve controlled actions'],
  ['customer.view', 'View customers'],
  ['customer.manage', 'Manage customers and loyalty'],
  ['promotion.manage', 'Manage promotions and bundles'],
  ['transfer.manage', 'Manage stock transfers'],
];

export const ALL_PERMISSION_CODES: string[] = PERMISSIONS.map(([code]) => code);

export const ORGANISATION_ADMINISTRATOR_ROLE = 'Organisation Administrator';

export type SystemRoleDefinition = { name: string; description: string; permissions: string[] };

/** System roles created for every organisation. They are locked: they can be assigned but not edited. */
export const SYSTEM_ROLES: SystemRoleDefinition[] = [
  { name: ORGANISATION_ADMINISTRATOR_ROLE, description: 'Full organisation configuration access', permissions: ALL_PERMISSION_CODES },
  { name: 'Store Manager', description: 'Manage assigned store operations', permissions: ['org.overview.view', 'users.view', 'stores.view', 'registers.view', 'registers.manage', 'catalog.view', 'pricing.view', 'tax.view', 'sale.create', 'register.open', 'register.close', 'report.view'] },
  { name: 'Supervisor', description: 'Operational support and permitted approvals', permissions: ['org.overview.view', 'users.view', 'stores.view', 'registers.view', 'catalog.view', 'pricing.view', 'tax.view', 'sale.create', 'register.open', 'register.close'] },
  { name: 'Cashier', description: 'Normal sales and register operations', permissions: ['stores.view', 'registers.view', 'catalog.view', 'sale.create', 'register.open', 'register.close'] },
  { name: 'Inventory User', description: 'Catalogue and inventory-related tasks', permissions: ['stores.view', 'catalog.view', 'catalog.manage', 'pricing.view', 'tax.view'] },
];
