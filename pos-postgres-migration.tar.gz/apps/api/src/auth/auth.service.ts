import { Injectable, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import { AuditService } from '../audit/audit.service.js';
import { PrismaService } from '../database/prisma.service.js';
import { hashPassword, verifyPassword } from '../security/password.js';
import { AuthorizationService } from './authorization.service.js';
import { UserContext } from './auth.types.js';

type LoginInput = {
  email?: unknown;
  password?: unknown;
  pin?: unknown;
  organizationSlug?: unknown;
};

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const SESSION_HOURS = 8;
const IDLE_MINUTES = 60;

const sha256 = (value: string) => createHash('sha256').update(value).digest('hex');

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly authorization: AuthorizationService,
    private readonly audit: AuditService,
  ) {}

  async login(input: LoginInput): Promise<{ accessToken: string; expiresAt: string; user: UserContext }> {
    const email = this.normalizedEmail(input.email);
    const password = typeof input.password === 'string' ? input.password : '';
    const pin = typeof input.pin === 'string' ? input.pin : '';
    const organizationSlug = typeof input.organizationSlug === 'string' ? input.organizationSlug.trim() : undefined;

    // An email can exist in more than one organisation. Without an organisation slug an ambiguous
    // email is rejected rather than guessed.
    const candidates = await this.prisma.user.findMany({
      where: { email, ...(organizationSlug ? { organization: { slug: organizationSlug } } : {}) },
      take: 2,
    });
    const user = candidates.length === 1 ? candidates[0] : undefined;

    if (user?.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      throw new UnauthorizedException('Account temporarily locked after repeated failed attempts');
    }

    const validPassword = Boolean(user && password && verifyPassword(password, user.passwordHash));
    const validPin = Boolean(user && pin && user.pinHash && verifyPassword(pin, user.pinHash));
    if (!user || user.status !== 'ACTIVE' || (!validPassword && !validPin)) {
      if (user) {
        const failedAttempts = user.failedAttempts + 1;
        await this.prisma.user.update({
          where: { id: user.id },
          data: {
            failedAttempts,
            lockedUntil: failedAttempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
          },
        });
      }
      throw new UnauthorizedException('Invalid email or password');
    }

    const rawToken = randomBytes(32).toString('base64url');
    const now = new Date();
    const expiresAt = new Date(now.getTime() + SESSION_HOURS * 3_600_000);

    await this.prisma.$transaction(async (tx) => {
      await tx.session.create({
        data: { tokenHash: sha256(rawToken), userId: user.id, organizationId: user.organizationId, expiresAt, lastSeenAt: now },
      });
      await tx.user.update({ where: { id: user.id }, data: { lastLoginAt: now, failedAttempts: 0, lockedUntil: null } });
      await this.audit.record({ organizationId: user.organizationId, userId: user.id }, 'auth.login', 'User', user.id, {}, tx);
    });

    return { accessToken: rawToken, expiresAt: expiresAt.toISOString(), user: await this.authorization.getUserContext(user.id) };
  }

  async authenticateToken(rawToken: string): Promise<UserContext> {
    const tokenHash = sha256(rawToken);
    const session = await this.prisma.session.findUnique({ where: { tokenHash } });

    if (!session || session.expiresAt.getTime() <= Date.now()) {
      if (session) await this.prisma.session.deleteMany({ where: { tokenHash } });
      throw new UnauthorizedException('Session is missing or expired');
    }
    if (session.lastSeenAt.getTime() + IDLE_MINUTES * 60_000 <= Date.now()) {
      await this.prisma.session.deleteMany({ where: { tokenHash } });
      throw new UnauthorizedException('Session expired after inactivity');
    }
    await this.prisma.session.update({ where: { tokenHash }, data: { lastSeenAt: new Date() } });
    return this.authorization.getUserContext(session.userId);
  }

  async logout(rawToken: string): Promise<void> {
    await this.prisma.session.deleteMany({ where: { tokenHash: sha256(rawToken) } });
  }

  async setPin(context: UserContext, pin: string): Promise<void> {
    if (!/^\d{4,8}$/.test(pin)) throw new UnauthorizedException('PIN must contain 4 to 8 digits');
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: context.userId }, data: { pinHash: hashPassword(pin) } });
      await this.audit.record(context, 'auth.pin.updated', 'User', context.userId, {}, tx);
    });
  }

  private normalizedEmail(value: unknown): string {
    if (typeof value !== 'string' || !value.includes('@')) throw new UnauthorizedException('Invalid email or password');
    return value.trim().toLowerCase();
  }

  hashPassword(password: string): string {
    return hashPassword(password);
  }
}
