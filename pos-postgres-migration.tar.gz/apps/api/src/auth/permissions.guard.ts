import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthorizationService } from './authorization.service.js';
import { REQUIRED_PERMISSIONS } from './permissions.decorator.js';
import { AuthenticatedRequest } from './auth.guard.js';

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly authorization: AuthorizationService,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const permissions = this.reflector.getAllAndOverride<string[]>(REQUIRED_PERMISSIONS, [context.getHandler(), context.getClass()]) ?? [];
    if (permissions.length === 0) return true;

    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    if (!request.user) return false;
    const body = request.body as Record<string, unknown> | undefined;
    const storeId = (request.params.storeId as string | undefined) ?? (body?.storeId as string | undefined) ?? request.header('x-store-id') ?? undefined;
    this.authorization.assertPermissions(request.user, permissions, storeId);
    if (storeId) this.authorization.assertStoreAccess(request.user, storeId);
    return true;
  }
}
