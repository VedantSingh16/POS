import { Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import type { AuthenticatedRequest } from '../auth/auth.guard.js';
import { PermissionsGuard } from '../auth/permissions.guard.js';
import { RequirePermissions } from '../auth/permissions.decorator.js';
import { PosService } from './pos.service.js';

@Controller('api/pos/v1')
@UseGuards(AuthGuard, PermissionsGuard)
export class PosController {
  constructor(private readonly pos: PosService) {}

  @Get('features') features() { return this.pos.featureStatus(); }

  @Get('overview')
  @RequirePermissions('org.overview.view')
  overview(@Req() request: AuthenticatedRequest) { return this.pos.overview(request.user!); }

  @Get('catalog/search')
  @RequirePermissions('catalog.view')
  async search(@Req() request: AuthenticatedRequest, @Query('q') query?: string) { return { products: await this.pos.searchProducts(request.user!, query) }; }

  @Get('sessions')
  @RequirePermissions('registers.view')
  async sessions(@Req() request: AuthenticatedRequest, @Query('storeId') storeId?: string) { return { sessions: await this.pos.listSessions(request.user!, storeId) }; }

  @Post('sessions')
  @RequirePermissions('register.open')
  openSession(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.openSession(request.user!, body); }

  @Get('sessions/:sessionId/summary')
  @RequirePermissions('registers.view')
  sessionSummary(@Req() request: AuthenticatedRequest, @Param('sessionId') sessionId: string) { return this.pos.sessionSummary(request.user!, sessionId); }

  @Post('sessions/:sessionId/cash')
  @RequirePermissions('cash.manage')
  cash(@Req() request: AuthenticatedRequest, @Param('sessionId') sessionId: string, @Body() body: Record<string, unknown>) { return this.pos.cashMovement(request.user!, sessionId, body); }

  @Post('sessions/:sessionId/close')
  @RequirePermissions('register.close')
  close(@Req() request: AuthenticatedRequest, @Param('sessionId') sessionId: string, @Body() body: Record<string, unknown>) { return this.pos.closeSession(request.user!, sessionId, body); }

  @Get('holds')
  @RequirePermissions('sale.hold')
  async holds(@Req() request: AuthenticatedRequest, @Query('storeId') storeId?: string) { return { holds: await this.pos.listHeldSales(request.user!, storeId) }; }

  @Post('holds')
  @RequirePermissions('sale.hold')
  hold(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.holdSale(request.user!, body); }

  @Post('holds/:holdId/resume')
  @RequirePermissions('sale.hold')
  resume(@Req() request: AuthenticatedRequest, @Param('holdId') holdId: string) { return this.pos.resumeHold(request.user!, holdId); }

  @Post('sales')
  @RequirePermissions('sale.create')
  sale(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.completeSale(request.user!, body); }

  @Post('approvals')
  @RequirePermissions('approval.manage')
  requestApproval(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.requestApproval(request.user!, body); }

  @Patch('approvals/:approvalId')
  @RequirePermissions('approval.manage')
  decideApproval(@Req() request: AuthenticatedRequest, @Param('approvalId') approvalId: string, @Body() body: Record<string, unknown>) { return this.pos.decideApproval(request.user!, approvalId, body); }

  @Get('inventory')
  @RequirePermissions('inventory.view')
  inventory(@Req() request: AuthenticatedRequest, @Query('storeId') storeId?: string) { return this.pos.inventory(request.user!, storeId); }

  @Post('inventory/adjustments')
  @RequirePermissions('inventory.manage')
  adjustment(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.adjustInventory(request.user!, body); }

  @Get('locations')
  @RequirePermissions('inventory.view')
  async locations(@Req() request: AuthenticatedRequest) { return { locations: await this.pos.listLocations(request.user!) }; }

  @Post('locations')
  @RequirePermissions('inventory.manage')
  location(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createLocation(request.user!, body); }

  @Post('returns')
  @RequirePermissions('refund.create')
  returns(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createReturn(request.user!, body); }

  @Get('reports')
  @RequirePermissions('report.view')
  reports(@Req() request: AuthenticatedRequest, @Query('from') from?: string, @Query('to') to?: string) { return this.pos.reports(request.user!, from, to); }

  @Get('alerts')
  @RequirePermissions('report.view')
  async alerts(@Req() request: AuthenticatedRequest) { return { alerts: await this.pos.alerts(request.user!) }; }

  @Get('customers')
  @RequirePermissions('customer.view')
  async customers(@Req() request: AuthenticatedRequest) { return { customers: await this.pos.listCustomers(request.user!) }; }

  @Post('customers')
  @RequirePermissions('customer.manage')
  customer(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createCustomer(request.user!, body); }

  @Post('customers/:customerId/ledger')
  @RequirePermissions('customer.manage')
  customerLedger(@Req() request: AuthenticatedRequest, @Param('customerId') customerId: string, @Body() body: Record<string, unknown>) { return this.pos.customerLedger(request.user!, customerId, body); }

  @Get('promotions')
  @RequirePermissions('promotion.manage')
  async promotions(@Req() request: AuthenticatedRequest) { return { promotions: await this.pos.listPromotions(request.user!) }; }

  @Post('promotions')
  @RequirePermissions('promotion.manage')
  promotion(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createPromotion(request.user!, body); }

  @Get('bundles')
  @RequirePermissions('promotion.manage')
  async bundles(@Req() request: AuthenticatedRequest) { return { bundles: await this.pos.listBundles(request.user!) }; }

  @Post('bundles')
  @RequirePermissions('promotion.manage')
  bundle(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createBundle(request.user!, body); }

  @Get('transfers')
  @RequirePermissions('transfer.manage')
  async transfers(@Req() request: AuthenticatedRequest) { return { transfers: await this.pos.listTransfers(request.user!) }; }

  @Post('transfers')
  @RequirePermissions('transfer.manage')
  transfer(@Req() request: AuthenticatedRequest, @Body() body: Record<string, unknown>) { return this.pos.createTransfer(request.user!, body); }

  @Patch('transfers/:transferId')
  @RequirePermissions('transfer.manage')
  transferStatus(@Req() request: AuthenticatedRequest, @Param('transferId') transferId: string, @Body() body: Record<string, unknown>) { return this.pos.updateTransfer(request.user!, transferId, body); }

  @Post('demo/seed')
  @RequirePermissions('catalog.manage')
  seed(@Req() request: AuthenticatedRequest) { return this.pos.seedDemo(request.user!); }
}
