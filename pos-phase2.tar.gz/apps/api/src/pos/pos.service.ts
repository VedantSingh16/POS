import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { AuditService } from '../audit/audit.service.js';
import { UserContext } from '../auth/auth.types.js';
import { AuthorizationService } from '../auth/authorization.service.js';
import { finiteNumber, isUuid, JsonObject, money, oneOf, optionalString, requiredString, uuid } from '../common/input.js';
import { isUniqueViolation, num, Tx } from '../database/db.js';
import { PrismaService } from '../database/prisma.service.js';
import {
  AlertSeverity,
  CashMovementType,
  CustomerLedgerType,
  InventoryMovementType,
  InventoryStatus,
  Prisma,
  PromotionType,
  TenderType,
  TransferStatus,
} from '../generated/prisma/client.js';
import { PHASES } from './pos-features.js';

type LineInput = { variantId?: unknown; quantity?: unknown; note?: unknown };

const SELLABLE_STATUSES = ['ACTIVE', 'SEASONAL'] as const;
const TENDERS = Object.values(TenderType) as TenderType[];
const INVENTORY_STATUSES = Object.values(InventoryStatus) as InventoryStatus[];
const CASH_MOVEMENTS = Object.values(CashMovementType) as CashMovementType[];
const OUTFLOW_MOVEMENTS: CashMovementType[] = ['PAID_OUT', 'DROP', 'PICKUP'];
const TRANSFER_STATUSES = Object.values(TransferStatus) as TransferStatus[];
const TRANSFER_FLOW: Record<TransferStatus, TransferStatus[]> = {
  REQUESTED: ['DISPATCHED', 'IN_TRANSIT', 'CANCELLED'],
  DISPATCHED: ['IN_TRANSIT', 'RECEIVED', 'CANCELLED'],
  IN_TRANSIT: ['RECEIVED', 'CANCELLED'],
  RECEIVED: [],
  CANCELLED: [],
};

type PricedLine = {
  variantId: string;
  sku: string;
  name: string;
  quantity: number;
  unitPriceCents: number;
  taxCents: number;
  netCents: number;
  lineTotalCents: number;
  note: string;
};

type SaleWithDetails = Prisma.SaleGetPayload<{ include: { lines: true; payments: true } }>;

const formatRupees = (cents: number) => `₹${(cents / 100).toFixed(2)}`;

@Injectable()
export class PosService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly authorization: AuthorizationService,
    private readonly audit: AuditService,
  ) {}

  featureStatus() {
    return { plan: 'plan2', generatedAt: new Date().toISOString(), phases: PHASES };
  }

  async overview(context: UserContext) {
    const where = { organizationId: context.organizationId };
    const [products, variants, sales, returns, customers, inventoryMovements, alerts] = await Promise.all([
      this.prisma.product.count({ where }),
      this.prisma.productVariant.count({ where }),
      this.prisma.sale.count({ where }),
      this.prisma.saleReturn.count({ where }),
      this.prisma.customer.count({ where }),
      this.prisma.inventoryMovement.count({ where }),
      this.prisma.alert.count({ where }),
    ]);
    return {
      phases: PHASES,
      counts: { products, variants, sales, returns, customers, inventoryMovements, alerts },
      capabilities: ['POS_CORE', 'POS_INVENTORY', 'POS_REFUNDS', 'POS_CUSTOMERS', 'POS_REPORTING_ADVANCED', 'POS_MULTI_LOCATION'],
    };
  }

  // ───────────── Catalogue search ─────────────

  async searchProducts(context: UserContext, query = '') {
    const term = query.trim();
    const storeId = context.defaultStoreId;
    const variants = await this.prisma.productVariant.findMany({
      where: {
        organizationId: context.organizationId,
        status: { in: [...SELLABLE_STATUSES] },
        ...(term
          ? {
            OR: [
              { sku: { contains: term, mode: 'insensitive' } },
              { name: { contains: term, mode: 'insensitive' } },
              { product: { name: { contains: term, mode: 'insensitive' } } },
              { barcodes: { some: { code: { contains: term, mode: 'insensitive' } } } },
            ],
          }
          : {}),
      },
      include: {
        product: { select: { name: true } },
        taxGroup: { select: { rateBps: true } },
        barcodes: { select: { code: true }, orderBy: { code: 'asc' }, take: 1 },
        prices: this.currentPriceFilter(storeId),
      },
      orderBy: [{ product: { name: 'asc' } }, { name: 'asc' }],
      take: 100,
    });
    return variants.map((variant) => ({
      variantId: variant.id,
      sku: variant.sku,
      variantName: variant.name,
      productName: variant.product.name,
      priceCents: this.pickPrice(variant.prices, storeId)?.amountCents ?? 0,
      barcode: variant.barcodes[0]?.code ?? '',
      taxBps: variant.taxGroup?.rateBps ?? 0,
    }));
  }

  // ───────────── Register sessions & cash ─────────────

  async listSessions(context: UserContext, storeId?: string) {
    const store = storeId ?? context.defaultStoreId;
    if (!store) return [];
    this.authorization.assertStoreAccess(context, store);
    const sessions = await this.prisma.registerSession.findMany({
      where: { organizationId: context.organizationId, storeId: store },
      include: { register: { select: { code: true, name: true } } },
      orderBy: { openedAt: 'desc' },
    });
    return sessions.map((session) => this.sessionDto(session));
  }

  async openSession(context: UserContext, input: JsonObject) {
    const storeId = uuid(input.storeId ?? context.defaultStoreId, 'storeId');
    const registerId = uuid(input.registerId, 'registerId');
    this.authorization.assertStoreAccess(context, storeId);
    const register = await this.prisma.register.findFirst({
      where: { id: registerId, organizationId: context.organizationId, status: 'ACTIVE' },
    });
    if (!register || register.storeId !== storeId) throw new NotFoundException('Active register not found in store');
    const openingFloatCents = money(input.openingFloatCents ?? 0, 'openingFloatCents');

    try {
      const session = await this.prisma.$transaction(async (tx) => {
        const created = await tx.registerSession.create({
          data: {
            organizationId: context.organizationId,
            storeId,
            registerId,
            openedById: context.userId,
            openingFloatCents,
            expectedCashCents: openingFloatCents,
          },
          include: { register: { select: { code: true, name: true } } },
        });
        await this.audit.record(context, 'register-session.opened', 'RegisterSession', created.id, { storeId, registerId, openingFloatCents }, tx);
        return created;
      });
      return this.sessionDto(session);
    } catch (error) {
      // The partial unique index allows only one OPEN session per register.
      if (isUniqueViolation(error)) throw new ConflictException('This register already has an open session');
      throw error;
    }
  }

  async cashMovement(context: UserContext, sessionId: string, input: JsonObject) {
    const session = await this.openSessionRow(context, sessionId);
    const type = oneOf(input.type, CASH_MOVEMENTS, 'type');
    const amountCents = money(input.amountCents);
    const signed = OUTFLOW_MOVEMENTS.includes(type) ? -amountCents : amountCents;
    await this.prisma.$transaction(async (tx) => {
      await tx.cashMovement.create({
        data: { organizationId: context.organizationId, sessionId, type, amountCents: signed, reason: optionalString(input.reason) ?? '', actorUserId: context.userId },
      });
      await tx.registerSession.update({ where: { id: sessionId }, data: { expectedCashCents: { increment: signed } } });
      await this.audit.record(context, 'cash-movement.recorded', 'RegisterSession', sessionId, { type, amountCents: signed }, tx);
    });
    return this.sessionById(context, session.id);
  }

  async closeSession(context: UserContext, sessionId: string, input: JsonObject) {
    const counted = money(input.countedCashCents, 'countedCashCents');
    const closed = await this.prisma.$transaction(async (tx) => {
      const session = await this.openSessionRow(context, sessionId, tx);
      const variance = counted - session.expectedCashCents;
      // `status: OPEN` in the filter makes a concurrent double-close a no-op instead of a second close.
      const result = await tx.registerSession.updateMany({
        where: { id: sessionId, status: 'OPEN' },
        data: { status: 'CLOSED', countedCashCents: counted, varianceCents: variance, closedAt: new Date() },
      });
      if (result.count === 0) throw new ConflictException('Register session is already closed');
      if (variance !== 0) {
        await this.raiseAlert(tx, context, 'CASH_VARIANCE', variance < 0 ? 'HIGH' : 'MEDIUM', `Register variance is ${formatRupees(variance)}`, sessionId);
      }
      await this.audit.record(context, 'register-session.closed', 'RegisterSession', sessionId, { counted, expected: session.expectedCashCents, variance }, tx);
      return session.id;
    });
    return this.sessionById(context, closed);
  }

  async sessionSummary(context: UserContext, sessionId: string) {
    const session = await this.findSession(context, sessionId);
    const [sales, payments, movements] = await Promise.all([
      this.prisma.sale.aggregate({
        where: { sessionId, status: 'COMPLETED' },
        _count: { _all: true },
        _sum: { totalCents: true },
      }),
      this.prisma.salePayment.groupBy({
        by: ['tenderType'],
        where: { sale: { sessionId, status: 'COMPLETED' } },
        _sum: { amountCents: true },
      }),
      this.prisma.cashMovement.findMany({ where: { sessionId }, orderBy: { createdAt: 'desc' } }),
    ]);
    return {
      session: await this.sessionById(context, session.id),
      sales: { count: sales._count._all, totalCents: sales._sum.totalCents ?? 0 },
      payments: payments.map((payment) => ({ tenderType: payment.tenderType, amountCents: payment._sum.amountCents ?? 0 })),
      movements: movements.map((movement) => ({
        type: movement.type,
        amountCents: movement.amountCents,
        reason: movement.reason,
        createdAt: movement.createdAt,
      })),
    };
  }

  // ───────────── Hold / resume ─────────────

  async holdSale(context: UserContext, input: JsonObject) {
    const storeId = uuid(input.storeId ?? context.defaultStoreId, 'storeId');
    const registerId = uuid(input.registerId, 'registerId');
    this.authorization.assertStoreAccess(context, storeId);
    const register = await this.prisma.register.findFirst({ where: { id: registerId, storeId, organizationId: context.organizationId }, select: { id: true } });
    if (!register) throw new NotFoundException('Register not found in store');
    const clientHoldId = optionalString(input.clientHoldId) || undefined;
    try {
      const held = await this.prisma.heldSale.create({
        data: {
          organizationId: context.organizationId,
          storeId,
          registerId,
          clientHoldId: clientHoldId ?? randomUUID(),
          payload: (input.payload ?? {}) as Prisma.InputJsonValue,
          createdById: context.userId,
        },
      });
      return { id: held.id, clientHoldId: held.clientHoldId, payload: held.payload, createdAt: held.createdAt };
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A held sale with this clientHoldId already exists');
      throw error;
    }
  }

  async listHeldSales(context: UserContext, storeId?: string) {
    const store = storeId ?? context.defaultStoreId;
    if (!store) return [];
    this.authorization.assertStoreAccess(context, store);
    const holds = await this.prisma.heldSale.findMany({
      where: { organizationId: context.organizationId, storeId: store },
      orderBy: { createdAt: 'desc' },
    });
    return holds.map((held) => ({ id: held.id, clientHoldId: held.clientHoldId, registerId: held.registerId, payload: held.payload, createdAt: held.createdAt }));
  }

  async resumeHold(context: UserContext, holdId: string) {
    const held = await this.prisma.heldSale.findFirst({ where: { id: uuid(holdId, 'holdId'), organizationId: context.organizationId } });
    if (!held) throw new NotFoundException('Held sale not found');
    this.authorization.assertStoreAccess(context, held.storeId);
    // Deleting by id is the claim: only one concurrent resume can succeed.
    const deleted = await this.prisma.heldSale.deleteMany({ where: { id: held.id } });
    if (deleted.count === 0) throw new ConflictException('Held sale was already resumed');
    return { id: held.id, payload: held.payload };
  }

  // ───────────── Checkout ─────────────

  async completeSale(context: UserContext, input: JsonObject) {
    const storeId = uuid(input.storeId ?? context.defaultStoreId, 'storeId');
    const registerId = uuid(input.registerId, 'registerId');
    const sessionId = uuid(input.sessionId, 'sessionId');
    const clientSaleId = optionalString(input.clientSaleId) || randomUUID();
    this.authorization.assertStoreAccess(context, storeId);

    // A retried checkout returns the original sale.
    const existing = await this.findSaleByClientId(context.organizationId, clientSaleId);
    if (existing) return this.saleResult(existing);

    const session = await this.openSessionRow(context, sessionId);
    if (session.storeId !== storeId || session.registerId !== registerId) {
      throw new BadRequestException('Session does not belong to this register and store');
    }
    const rawLines = Array.isArray(input.lines) ? input.lines as LineInput[] : [];
    if (!rawLines.length) throw new BadRequestException('At least one sale line is required');
    const lines = await Promise.all(rawLines.map((line) => this.priceLine(context, line, storeId)));

    const orderDiscount = money(input.discountCents ?? 0, 'discountCents');
    const subtotal = lines.reduce((sum, line) => sum + line.netCents, 0);
    await this.assertDiscountAllowed(context, orderDiscount, subtotal, input.approvalId);

    const discount = Math.min(orderDiscount, subtotal);
    const lineTax = lines.reduce((sum, line) => sum + line.taxCents, 0);
    const tax = Math.max(0, lineTax - Math.round((discount * lineTax) / Math.max(1, subtotal)));
    const total = subtotal - discount + tax;

    const payments = this.paymentLines(input.payments);
    const paymentTotal = payments.reduce((sum, payment) => sum + payment.amountCents, 0);
    if (paymentTotal !== total) throw new BadRequestException(`Payment total must equal ${formatRupees(total)}`);

    const customerId = typeof input.customerId === 'string' ? uuid(input.customerId, 'customerId') : null;
    if (customerId && !(await this.prisma.customer.findFirst({ where: { id: customerId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new BadRequestException('Customer not found');
    }

    try {
      const saleId = await this.prisma.$transaction(async (tx) => {
        const receiptNumber = await this.nextDocumentNumber(tx, context.organizationId, storeId, 'TAX');
        const sale = await tx.sale.create({
          data: {
            organizationId: context.organizationId,
            storeId,
            registerId,
            sessionId,
            clientSaleId,
            receiptNumber,
            subtotalCents: subtotal,
            discountCents: discount,
            taxCents: tax,
            totalCents: total,
            notes: optionalString(input.notes) ?? '',
            customerId,
            createdById: context.userId,
            lines: {
              create: lines.map((line) => ({
                variantId: line.variantId,
                sku: line.sku,
                name: line.name,
                quantity: line.quantity,
                unitPriceCents: line.unitPriceCents,
                taxCents: line.taxCents,
                lineTotalCents: line.lineTotalCents,
                note: line.note,
              })),
            },
            payments: { create: payments },
          },
        });

        const cashReceived = payments.filter((payment) => payment.tenderType === 'CASH').reduce((sum, payment) => sum + payment.amountCents, 0);
        if (cashReceived > 0) {
          await tx.registerSession.update({ where: { id: sessionId }, data: { expectedCashCents: { increment: cashReceived } } });
        }
        await tx.outboxEvent.create({
          data: {
            organizationId: context.organizationId,
            eventType: 'sale.completed',
            aggregateId: sale.id,
            payload: { saleId: sale.id, storeId, lines } as unknown as Prisma.InputJsonValue,
          },
        });
        const location = await this.storeLocation(tx, context.organizationId, storeId);
        if (location) {
          for (const line of lines) {
            await this.postInventory(tx, context, location.id, line.variantId, -line.quantity, 'SALE', sale.id, 'Sale completed', 0, 'SELLABLE');
          }
        }
        if (customerId) await this.earnPoints(tx, customerId, total, sale.id);
        await this.audit.record(context, 'sale.completed', 'Sale', sale.id, { receiptNumber, total, clientSaleId }, tx);
        return sale.id;
      });
      return this.saleResult(await this.findSaleOrThrow(context.organizationId, saleId));
    } catch (error) {
      if (isUniqueViolation(error)) {
        // A concurrent request with the same clientSaleId won the race.
        const winner = await this.findSaleByClientId(context.organizationId, clientSaleId);
        if (winner) return this.saleResult(winner);
      }
      throw error;
    }
  }

  // ───────────── Approvals ─────────────

  async requestApproval(context: UserContext, input: JsonObject) {
    const approval = await this.prisma.approval.create({
      data: {
        organizationId: context.organizationId,
        action: requiredString(input.action, 'action').toUpperCase(),
        referenceId: requiredString(input.referenceId, 'referenceId'),
        requestedById: context.userId,
        reason: requiredString(input.reason ?? 'Manager approval requested', 'reason'),
      },
    });
    return { id: approval.id, action: approval.action, referenceId: approval.referenceId, status: approval.status, reason: approval.reason, createdAt: approval.createdAt };
  }

  async decideApproval(context: UserContext, approvalId: string, input: JsonObject) {
    const status = oneOf(input.status, ['APPROVED', 'DENIED'] as const, 'status');
    const approval = await this.prisma.approval.findFirst({ where: { id: uuid(approvalId, 'approvalId'), organizationId: context.organizationId } });
    if (!approval) throw new NotFoundException('Approval not found');
    const decided = await this.prisma.approval.updateMany({
      where: { id: approval.id, status: 'PENDING' },
      data: { status, approvedById: context.userId, decidedAt: new Date() },
    });
    if (decided.count === 0) throw new ConflictException('Approval has already been decided');
    await this.audit.record(context, `approval.${status.toLowerCase()}`, 'Approval', approval.id, { action: approval.action, referenceId: approval.referenceId });
    const result = await this.prisma.approval.findUniqueOrThrow({ where: { id: approval.id } });
    return {
      id: result.id,
      action: result.action,
      referenceId: result.referenceId,
      status: result.status,
      reason: result.reason,
      approvedBy: result.approvedById,
      decidedAt: result.decidedAt,
    };
  }

  // ───────────── Inventory ─────────────

  async inventory(context: UserContext, storeId?: string) {
    if (storeId) this.authorization.assertStoreAccess(context, storeId);
    const locationFilter = storeId ? { location: { storeId } } : {};
    const [balances, movements] = await Promise.all([
      this.prisma.inventoryBalance.findMany({
        where: { organizationId: context.organizationId, ...locationFilter },
        include: { location: { select: { name: true } }, variant: { select: { sku: true, name: true } } },
        orderBy: { variant: { name: 'asc' } },
      }),
      this.prisma.inventoryMovement.findMany({
        where: { organizationId: context.organizationId, ...locationFilter },
        include: { variant: { select: { sku: true, name: true } } },
        orderBy: { createdAt: 'desc' },
        take: 100,
      }),
    ]);
    return {
      balances: balances.map((balance) => ({
        locationId: balance.locationId,
        locationName: balance.location.name,
        variantId: balance.variantId,
        sku: balance.variant.sku,
        name: balance.variant.name,
        status: balance.status,
        quantity: num(balance.quantity),
        reorderPoint: num(balance.reorderPoint),
        safetyStock: num(balance.safetyStock),
        updatedAt: balance.updatedAt,
      })),
      movements: movements.map((movement) => ({
        id: movement.id,
        locationId: movement.locationId,
        variantId: movement.variantId,
        sku: movement.variant.sku,
        name: movement.variant.name,
        quantity: num(movement.quantity),
        status: movement.status,
        type: movement.type,
        reason: movement.reason,
        referenceId: movement.referenceId,
        createdAt: movement.createdAt,
      })),
    };
  }

  async listLocations(context: UserContext) {
    const locations = await this.prisma.stockLocation.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return locations.map((location) => this.locationDto(location));
  }

  async createLocation(context: UserContext, input: JsonObject) {
    const storeId = typeof input.storeId === 'string' && input.storeId.trim() ? uuid(input.storeId, 'storeId') : null;
    if (storeId && !(await this.prisma.store.findFirst({ where: { id: storeId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new NotFoundException('Store not found');
    }
    try {
      const location = await this.prisma.$transaction(async (tx) => {
        const created = await tx.stockLocation.create({
          data: { organizationId: context.organizationId, storeId, code: requiredString(input.code, 'code').toUpperCase(), name: requiredString(input.name, 'name') },
        });
        await this.audit.record(context, 'stock-location.created', 'StockLocation', created.id, { code: created.code }, tx);
        return created;
      });
      return this.locationDto(location);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A stock location with this code already exists');
      throw error;
    }
  }

  async adjustInventory(context: UserContext, input: JsonObject) {
    const locationId = uuid(input.locationId, 'locationId');
    const variantId = uuid(input.variantId, 'variantId');
    const quantity = finiteNumber(input.quantity, 'quantity');
    const status = input.status === undefined ? 'SELLABLE' : oneOf(input.status, INVENTORY_STATUSES, 'status');
    const reason = requiredString(input.reason ?? 'Manual adjustment', 'reason');
    const unitCostCents = money(input.unitCostCents ?? 0, 'unitCostCents');

    const location = await this.prisma.stockLocation.findFirst({ where: { id: locationId, organizationId: context.organizationId } });
    if (!location) throw new NotFoundException('Stock location not found');
    if (location.storeId) this.authorization.assertStoreAccess(context, location.storeId);
    if (!(await this.prisma.productVariant.findFirst({ where: { id: variantId, organizationId: context.organizationId }, select: { id: true } }))) {
      throw new NotFoundException('Product variant not found');
    }

    await this.prisma.$transaction(async (tx) => {
      await this.postInventory(tx, context, locationId, variantId, quantity, 'ADJUSTMENT', null, reason, unitCostCents, status);
      await this.audit.record(context, 'inventory.adjusted', 'StockLocation', locationId, { variantId, quantity, status, reason }, tx);
    });
    return this.inventory(context);
  }

  // ───────────── Returns ─────────────

  async createReturn(context: UserContext, input: JsonObject) {
    const saleId = uuid(input.saleId, 'saleId');
    const sale = await this.prisma.sale.findFirst({ where: { id: saleId, organizationId: context.organizationId }, include: { lines: true } });
    if (!sale) throw new NotFoundException('Original sale not found');
    this.authorization.assertStoreAccess(context, sale.storeId);
    const session = await this.openSessionRow(context, uuid(input.sessionId, 'sessionId'));
    if (session.storeId !== sale.storeId) throw new BadRequestException('Return session must belong to the store of the original sale');

    const rawLines = Array.isArray(input.lines) ? input.lines as JsonObject[] : [];
    if (!rawLines.length) throw new BadRequestException('At least one return line is required');
    const restockStatus = input.restockStatus === undefined ? 'SELLABLE' : oneOf(input.restockStatus, INVENTORY_STATUSES, 'restockStatus');
    const refundTender = input.tenderType === undefined ? 'CASH' : oneOf(input.tenderType, TENDERS, 'tenderType');
    const reason = requiredString(input.reason ?? 'Customer return', 'reason');

    const returned = await this.prisma.returnLine.groupBy({
      by: ['saleLineId'],
      where: { saleLineId: { in: sale.lines.map((line) => line.id) } },
      _sum: { quantity: true },
    });
    const alreadyReturned = new Map(returned.map((row) => [row.saleLineId, num(row._sum.quantity)]));

    const requested = new Map<string, number>();
    const returnLines = rawLines.map((raw) => {
      const saleLineId = uuid(raw.saleLineId, 'saleLineId');
      const original = sale.lines.find((line) => line.id === saleLineId);
      if (!original) throw new BadRequestException('Sale line not found');
      const quantity = finiteNumber(raw.quantity, 'quantity');
      const requestedSoFar = (requested.get(saleLineId) ?? 0) + quantity;
      requested.set(saleLineId, requestedSoFar);
      const soldQuantity = num(original.quantity);
      if (quantity <= 0 || (alreadyReturned.get(saleLineId) ?? 0) + requestedSoFar > soldQuantity) {
        throw new BadRequestException('Return quantity exceeds the remaining sale quantity');
      }
      // Refund the tax-inclusive line value pro rata, so tax-exclusive items refund their tax too.
      const amount = Math.round((original.lineTotalCents * quantity) / soldQuantity);
      const tax = Math.round((original.taxCents * quantity) / soldQuantity);
      return { saleLineId, variantId: original.variantId, quantity, amount, tax };
    });
    const total = returnLines.reduce((sum, line) => sum + line.amount, 0);
    const tax = returnLines.reduce((sum, line) => sum + line.tax, 0);

    const result = await this.prisma.$transaction(async (tx) => {
      const creditNoteNumber = await this.nextDocumentNumber(tx, context.organizationId, sale.storeId, 'CN');
      const created = await tx.saleReturn.create({
        data: {
          organizationId: context.organizationId,
          originalSaleId: saleId,
          storeId: sale.storeId,
          sessionId: session.id,
          creditNoteNumber,
          refundTender,
          subtotalCents: total - tax,
          taxCents: tax,
          totalCents: total,
          reason,
          createdById: context.userId,
          lines: {
            create: returnLines.map((line) => ({
              saleLineId: line.saleLineId,
              variantId: line.variantId,
              quantity: line.quantity,
              restockStatus,
              amountCents: line.amount,
            })),
          },
        },
      });
      const location = await this.storeLocation(tx, context.organizationId, sale.storeId);
      if (location) {
        for (const line of returnLines) {
          await this.postInventory(tx, context, location.id, line.variantId, line.quantity, 'RETURN', created.id, 'Customer return', 0, restockStatus);
        }
      }
      if (refundTender === 'CASH') {
        await tx.registerSession.update({ where: { id: session.id }, data: { expectedCashCents: { decrement: total } } });
      }
      await this.audit.record(context, 'return.completed', 'Return', created.id, { saleId, total, creditNoteNumber }, tx);
      return created;
    });
    return {
      id: result.id,
      creditNoteNumber: result.creditNoteNumber,
      originalSaleId: result.originalSaleId,
      totalCents: result.totalCents,
      reason: result.reason,
      createdAt: result.createdAt,
    };
  }

  // ───────────── Reporting & alerts ─────────────

  async reports(context: UserContext, from?: string, to?: string) {
    const end = to ? this.dayBoundary(to, 'to', true) : new Date();
    const start = from ? this.dayBoundary(from, 'from', false) : new Date(Date.now() - 30 * 86_400_000);
    const period = { gte: start, lte: end };
    const orgId = context.organizationId;

    const [sales, tenders, returns, topProducts] = await Promise.all([
      this.prisma.sale.aggregate({
        where: { organizationId: orgId, status: 'COMPLETED', createdAt: period },
        _count: { _all: true },
        _sum: { subtotalCents: true, taxCents: true, totalCents: true, discountCents: true },
      }),
      this.prisma.salePayment.groupBy({
        by: ['tenderType'],
        where: { sale: { organizationId: orgId, status: 'COMPLETED', createdAt: period } },
        _sum: { amountCents: true },
      }),
      this.prisma.saleReturn.aggregate({
        where: { organizationId: orgId, createdAt: period },
        _count: { _all: true },
        _sum: { totalCents: true },
      }),
      this.prisma.saleLine.groupBy({
        by: ['variantId', 'sku', 'name'],
        where: { sale: { organizationId: orgId, status: 'COMPLETED', createdAt: period } },
        _sum: { quantity: true, lineTotalCents: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 10,
      }),
    ]);

    return {
      period: { from: start.toISOString(), to: end.toISOString() },
      sales: {
        count: sales._count._all,
        subtotalCents: sales._sum.subtotalCents ?? 0,
        taxCents: sales._sum.taxCents ?? 0,
        totalCents: sales._sum.totalCents ?? 0,
        discountsCents: sales._sum.discountCents ?? 0,
      },
      tenders: tenders.map((tender) => ({ tenderType: tender.tenderType, amountCents: tender._sum.amountCents ?? 0 })),
      returns: { count: returns._count._all, totalCents: returns._sum.totalCents ?? 0 },
      topProducts: topProducts.map((product) => ({
        sku: product.sku,
        name: product.name,
        quantity: num(product._sum.quantity),
        totalCents: product._sum.lineTotalCents ?? 0,
      })),
      alerts: await this.alerts(context),
    };
  }

  async alerts(context: UserContext) {
    const alerts = await this.prisma.alert.findMany({ where: { organizationId: context.organizationId }, orderBy: { createdAt: 'desc' }, take: 50 });
    return alerts.map((alert) => ({
      id: alert.id,
      type: alert.type,
      severity: alert.severity,
      message: alert.message,
      referenceId: alert.referenceId,
      status: alert.status,
      createdAt: alert.createdAt,
    }));
  }

  // ───────────── Customers ─────────────

  async listCustomers(context: UserContext) {
    const customers = await this.prisma.customer.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return customers.map((customer) => ({
      id: customer.id,
      name: customer.name,
      phone: customer.phone,
      email: customer.email,
      groupName: customer.groupName,
      notes: customer.notes,
      consentMarketing: customer.consentMarketing,
      walletBalanceCents: customer.walletBalanceCents,
      pointsBalance: customer.pointsBalance,
      createdAt: customer.createdAt,
    }));
  }

  async createCustomer(context: UserContext, input: JsonObject) {
    const customer = await this.prisma.customer.create({
      data: {
        organizationId: context.organizationId,
        name: requiredString(input.name, 'name'),
        phone: optionalString(input.phone) ?? '',
        email: optionalString(input.email)?.toLowerCase() ?? '',
        groupName: optionalString(input.groupName) || 'General',
        notes: optionalString(input.notes) ?? '',
        consentMarketing: input.consentMarketing === true,
      },
    });
    return { id: customer.id, name: customer.name, phone: customer.phone, email: customer.email, groupName: customer.groupName, walletBalanceCents: customer.walletBalanceCents, pointsBalance: customer.pointsBalance };
  }

  async customerLedger(context: UserContext, customerId: string, input: JsonObject) {
    const customer = await this.prisma.customer.findFirst({ where: { id: uuid(customerId, 'customerId'), organizationId: context.organizationId }, select: { id: true } });
    if (!customer) throw new NotFoundException('Customer not found');
    const type = oneOf(input.type, Object.values(CustomerLedgerType) as CustomerLedgerType[], 'type');
    const amount = type === 'CREDIT' || type === 'DEBIT' ? money(input.amountCents) : 0;
    const points = type === 'POINTS_EARN' || type === 'POINTS_REDEEM' ? Math.trunc(finiteNumber(input.points, 'points')) : 0;
    if (points < 0) throw new BadRequestException('points must not be negative');
    const walletDelta = type === 'CREDIT' ? amount : type === 'DEBIT' ? -amount : 0;
    const pointsDelta = type === 'POINTS_EARN' ? points : type === 'POINTS_REDEEM' ? -points : 0;

    const updated = await this.prisma.$transaction(async (tx) => {
      // Balances can never go negative: a debit or redemption only applies if the balance covers it.
      const result = await tx.customer.updateMany({
        where: {
          id: customer.id,
          ...(walletDelta < 0 ? { walletBalanceCents: { gte: -walletDelta } } : {}),
          ...(pointsDelta < 0 ? { pointsBalance: { gte: -pointsDelta } } : {}),
        },
        data: { walletBalanceCents: { increment: walletDelta }, pointsBalance: { increment: pointsDelta } },
      });
      if (result.count === 0) throw new BadRequestException('Insufficient wallet or points balance');
      await tx.customerLedger.create({
        data: { customerId: customer.id, type, amountCents: walletDelta, points: pointsDelta, referenceId: optionalString(input.referenceId) || null },
      });
      return tx.customer.findUniqueOrThrow({ where: { id: customer.id } });
    });
    return { id: updated.id, name: updated.name, walletBalanceCents: updated.walletBalanceCents, pointsBalance: updated.pointsBalance };
  }

  // ───────────── Promotions & bundles ─────────────

  async listPromotions(context: UserContext) {
    const promotions = await this.prisma.promotion.findMany({ where: { organizationId: context.organizationId }, orderBy: { code: 'asc' } });
    return promotions.map((promotion) => this.promotionDto(promotion));
  }

  async createPromotion(context: UserContext, input: JsonObject) {
    const type = input.type === undefined ? 'PERCENT' : oneOf(input.type, Object.values(PromotionType) as PromotionType[], 'type');
    const value = finiteNumber(input.value, 'value');
    if (value <= 0 || (type === 'PERCENT' && value > 100)) throw new BadRequestException('Promotion value is out of range');
    const startsAt = this.optionalDate(input.startsAt, 'startsAt');
    const endsAt = this.optionalDate(input.endsAt, 'endsAt');
    try {
      const promotion = await this.prisma.promotion.create({
        data: {
          organizationId: context.organizationId,
          code: requiredString(input.code, 'code').toUpperCase(),
          type,
          value,
          minSubtotalCents: money(input.minSubtotalCents ?? 0, 'minSubtotalCents'),
          usageLimit: input.usageLimit === undefined ? null : Math.trunc(finiteNumber(input.usageLimit, 'usageLimit')),
          startsAt,
          endsAt,
        },
      });
      return this.promotionDto(promotion);
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A promotion with this code already exists');
      throw error;
    }
  }

  async listBundles(context: UserContext) {
    const bundles = await this.prisma.bundle.findMany({ where: { organizationId: context.organizationId }, orderBy: { name: 'asc' } });
    return bundles.map((bundle) => ({ id: bundle.id, name: bundle.name, sku: bundle.sku, priceCents: bundle.priceCents, status: bundle.status }));
  }

  async createBundle(context: UserContext, input: JsonObject) {
    const components = Array.isArray(input.components) ? input.components as JsonObject[] : [];
    if (!components.length) throw new BadRequestException('Bundle needs at least one component');
    const parsed = components.map((component) => {
      const quantity = finiteNumber(component.quantity, 'quantity');
      if (quantity <= 0) throw new BadRequestException('Component quantity must be positive');
      return { variantId: uuid(component.variantId, 'variantId'), quantity };
    });
    await this.assertVariantsInOrganization(context.organizationId, parsed.map((component) => component.variantId));
    try {
      const bundle = await this.prisma.bundle.create({
        data: {
          organizationId: context.organizationId,
          name: requiredString(input.name, 'name'),
          sku: requiredString(input.sku, 'sku').toUpperCase(),
          priceCents: money(input.priceCents, 'priceCents'),
          components: { create: parsed },
        },
      });
      return { id: bundle.id, name: bundle.name, sku: bundle.sku, priceCents: bundle.priceCents, status: bundle.status };
    } catch (error) {
      if (isUniqueViolation(error)) throw new ConflictException('A bundle with this SKU already exists, or a component is repeated');
      throw error;
    }
  }

  // ───────────── Transfers ─────────────

  async listTransfers(context: UserContext) {
    const transfers = await this.prisma.transfer.findMany({
      where: { organizationId: context.organizationId },
      include: { fromLocation: { select: { name: true } }, toLocation: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    });
    return transfers.map((transfer) => this.transferDto(transfer));
  }

  async createTransfer(context: UserContext, input: JsonObject) {
    const lines = Array.isArray(input.lines) ? input.lines as JsonObject[] : [];
    if (!lines.length) throw new BadRequestException('Transfer needs at least one line');
    const fromLocationId = uuid(input.fromLocationId, 'fromLocationId');
    const toLocationId = uuid(input.toLocationId, 'toLocationId');
    if (fromLocationId === toLocationId) throw new BadRequestException('Source and destination must differ');
    const parsed = lines.map((line) => {
      const quantity = finiteNumber(line.quantity, 'quantity');
      if (quantity <= 0) throw new BadRequestException('Line quantity must be positive');
      return { variantId: uuid(line.variantId, 'variantId'), requestedQuantity: quantity };
    });
    const locations = await this.prisma.stockLocation.count({ where: { organizationId: context.organizationId, id: { in: [fromLocationId, toLocationId] } } });
    if (locations !== 2) throw new NotFoundException('Stock location not found');
    await this.assertVariantsInOrganization(context.organizationId, parsed.map((line) => line.variantId));

    const transfer = await this.prisma.$transaction(async (tx) => {
      const created = await tx.transfer.create({
        data: {
          organizationId: context.organizationId,
          fromLocationId,
          toLocationId,
          notes: optionalString(input.notes) ?? '',
          createdById: context.userId,
          lines: { create: parsed },
        },
        include: { fromLocation: { select: { name: true } }, toLocation: { select: { name: true } } },
      });
      await this.audit.record(context, 'transfer.requested', 'Transfer', created.id, { fromLocationId, toLocationId }, tx);
      return created;
    });
    return this.transferDto(transfer);
  }

  async updateTransfer(context: UserContext, transferId: string, input: JsonObject) {
    const status = oneOf(input.status, TRANSFER_STATUSES, 'status');
    const transfer = await this.prisma.transfer.findFirst({ where: { id: uuid(transferId, 'transferId'), organizationId: context.organizationId } });
    if (!transfer) throw new NotFoundException('Transfer not found');
    if (!TRANSFER_FLOW[transfer.status].includes(status)) {
      throw new ConflictException(`A ${transfer.status} transfer cannot move to ${status}`);
    }
    const updated = await this.prisma.$transaction(async (tx) => {
      const result = await tx.transfer.update({
        where: { id: transfer.id },
        data: { status },
        include: { fromLocation: { select: { name: true } }, toLocation: { select: { name: true } } },
      });
      await this.audit.record(context, 'transfer.status-changed', 'Transfer', transfer.id, { from: transfer.status, to: status }, tx);
      return result;
    });
    return this.transferDto(updated);
  }

  // ───────────── Demo workspace ─────────────

  async seedDemo(context: UserContext) {
    const organizationId = context.organizationId;
    return this.prisma.$transaction(async (tx) => {
      let store = await tx.store.findUnique({ where: { organizationId_code: { organizationId, code: 'MAIN' } } });
      if (!store) {
        await tx.$queryRaw`SELECT id FROM organizations WHERE id = ${organizationId}::uuid FOR UPDATE`;
        const entitlement = await tx.organizationEntitlement.findUnique({ where: { organizationId } });
        const current = await tx.store.count({ where: { organizationId, status: 'ACTIVE' } });
        if (!entitlement || current >= entitlement.maxStores) throw new ConflictException(`Store limit reached (${entitlement?.maxStores ?? 0})`);
        store = await tx.store.create({ data: { organizationId, code: 'MAIN', name: 'Main Store' } });
      }
      await tx.stockLocation.upsert({
        where: { organizationId_code: { organizationId, code: 'MAIN-STOCKROOM' } },
        create: { organizationId, storeId: store.id, code: 'MAIN-STOCKROOM', name: 'Main Stockroom' },
        update: {},
      });
      const register = await tx.register.upsert({
        where: { storeId_code: { storeId: store.id, code: 'REG-01' } },
        create: { organizationId, storeId: store.id, code: 'REG-01', name: 'Front Till' },
        update: {},
      });

      let variant = await tx.productVariant.findUnique({ where: { organizationId_sku: { organizationId, sku: 'MUG-BLUE' } } });
      if (!variant) {
        const category = await tx.category.findFirst({ where: { organizationId, name: 'Everyday' } })
          ?? await tx.category.create({ data: { organizationId, name: 'Everyday' } });
        const uom = await tx.unitOfMeasure.upsert({
          where: { organizationId_code: { organizationId, code: 'EA' } },
          create: { organizationId, code: 'EA', name: 'Each' },
          update: {},
        });
        const tax = await tx.taxGroup.upsert({
          where: { organizationId_code: { organizationId, code: 'GST5' } },
          create: { organizationId, code: 'GST5', name: 'GST 5%', rateBps: 500 },
          update: {},
        });
        const product = await tx.product.findFirst({ where: { organizationId, name: 'Demo Coffee Mug' } })
          ?? await tx.product.create({ data: { organizationId, categoryId: category.id, name: 'Demo Coffee Mug', brand: 'Demo' } });
        variant = await tx.productVariant.create({
          data: { organizationId, productId: product.id, sku: 'MUG-BLUE', name: 'Blue', uomId: uom.id, taxGroupId: tax.id },
        });
        await tx.barcode.upsert({
          where: { organizationId_code: { organizationId, code: '890000000001' } },
          create: { organizationId, variantId: variant.id, code: '890000000001' },
          update: {},
        });
        await tx.variantPrice.create({ data: { organizationId, variantId: variant.id, amountCents: 49900, currency: 'INR', includesTax: true } });
      }
      await tx.approvalPolicy.upsert({
        where: { organizationId_action: { organizationId, action: 'SALE_DISCOUNT' } },
        create: { organizationId, action: 'SALE_DISCOUNT', thresholdPercent: 10 },
        update: {},
      });
      return { storeId: store.id, registerId: register.id, variantId: variant.id, message: 'Demo workspace is ready' };
    });
  }

  // ───────────── Internals ─────────────

  /** Prices that apply to a store right now: that store's own, plus organisation-wide ones. */
  private currentPriceFilter(storeId: string | null) {
    return {
      where: { effectiveFrom: { lte: new Date() }, OR: [{ storeId: null }, ...(storeId ? [{ storeId }] : [])] },
      orderBy: { effectiveFrom: 'desc' as const },
    };
  }

  /** A store-specific price beats an organisation-wide one; within each, the most recent wins. */
  private pickPrice<T extends { storeId: string | null; effectiveFrom: Date }>(prices: T[], storeId: string | null): T | undefined {
    const latest = (list: T[]) => [...list].sort((a, b) => b.effectiveFrom.getTime() - a.effectiveFrom.getTime())[0];
    return latest(prices.filter((price) => storeId !== null && price.storeId === storeId)) ?? latest(prices.filter((price) => price.storeId === null));
  }

  private async priceLine(context: UserContext, input: LineInput, storeId: string): Promise<PricedLine> {
    const variantId = uuid(input.variantId, 'variantId');
    const quantity = finiteNumber(input.quantity ?? 1, 'quantity');
    if (quantity <= 0) throw new BadRequestException('quantity must be positive');
    const variant = await this.prisma.productVariant.findFirst({
      where: { id: variantId, organizationId: context.organizationId, status: { in: [...SELLABLE_STATUSES] } },
      include: { product: { select: { name: true } }, taxGroup: { select: { rateBps: true } }, prices: this.currentPriceFilter(storeId) },
    });
    if (!variant) throw new NotFoundException(`Sellable variant not found: ${variantId}`);

    const price = this.pickPrice(variant.prices, storeId);
    const unitPriceCents = price?.amountCents ?? 0;
    const taxBps = variant.taxGroup?.rateBps ?? 0;
    const gross = Math.round(unitPriceCents * quantity);
    const tax = price?.includesTax ? gross - Math.round((gross * 10_000) / (10_000 + taxBps)) : Math.round((gross * taxBps) / 10_000);
    const netCents = price?.includesTax ? gross - tax : gross;
    return {
      variantId,
      sku: variant.sku,
      name: `${variant.product.name} · ${variant.name}`,
      quantity,
      unitPriceCents,
      taxCents: tax,
      netCents,
      lineTotalCents: netCents + tax,
      note: optionalString(input.note) ?? '',
    };
  }

  private paymentLines(value: unknown) {
    const values = Array.isArray(value) ? value as JsonObject[] : [];
    if (!values.length) throw new BadRequestException('At least one payment is required');
    return values.map((payment) => ({
      tenderType: oneOf(payment.tenderType, TENDERS, 'tenderType'),
      amountCents: money(payment.amountCents),
      reference: optionalString(payment.reference) ?? '',
    }));
  }

  /** Discounts above the configured threshold need an approved manager authorisation for SALE_DISCOUNT. */
  private async assertDiscountAllowed(context: UserContext, discountCents: number, subtotalCents: number, approvalId: unknown) {
    const policy = await this.prisma.approvalPolicy.findUnique({
      where: { organizationId_action: { organizationId: context.organizationId, action: 'SALE_DISCOUNT' } },
    });
    if (!policy || policy.status !== 'ACTIVE') return;
    const allowed = Math.round((subtotalCents * num(policy.thresholdPercent)) / 100);
    if (discountCents <= allowed) return;
    const requireApproval = () => new ForbiddenException({
      code: 'REQUIRE_APPROVAL',
      action: 'SALE_DISCOUNT',
      message: 'This discount needs manager approval',
      thresholdPercent: num(policy.thresholdPercent),
    });
    if (approvalId === undefined) throw requireApproval();
    const approved = isUuid(approvalId)
      ? await this.prisma.approval.findFirst({ where: { id: approvalId, organizationId: context.organizationId, action: 'SALE_DISCOUNT', status: 'APPROVED' }, select: { id: true } })
      : null;
    if (!approved) throw requireApproval();
  }

  /** Sequential, gap-free numbering per store and document kind. Must run inside the document's transaction. */
  private async nextDocumentNumber(tx: Tx, organizationId: string, storeId: string, kind: 'TAX' | 'CN') {
    const sequence = await tx.documentSequence.upsert({
      where: { storeId_kind: { storeId, kind } },
      create: { organizationId, storeId, kind, lastValue: 1 },
      update: { lastValue: { increment: 1 } },
    });
    const date = new Date().toISOString().slice(0, 10).replaceAll('-', '');
    return `${kind}-${date}-${String(sequence.lastValue).padStart(4, '0')}`;
  }

  private async postInventory(
    tx: Tx,
    context: UserContext,
    locationId: string,
    variantId: string,
    quantity: number,
    type: InventoryMovementType,
    referenceId: string | null,
    reason: string,
    unitCostCents: number,
    status: InventoryStatus,
  ) {
    await tx.inventoryMovement.create({
      data: { organizationId: context.organizationId, locationId, variantId, quantity, status, type, referenceId, reason, unitCostCents, actorUserId: context.userId },
    });
    await tx.inventoryBalance.upsert({
      where: { locationId_variantId_status: { locationId, variantId, status } },
      create: { organizationId: context.organizationId, locationId, variantId, status, quantity },
      update: { quantity: { increment: quantity } },
    });
  }

  private storeLocation(tx: Tx, organizationId: string, storeId: string) {
    return tx.stockLocation.findFirst({ where: { organizationId, storeId }, orderBy: { createdAt: 'asc' }, select: { id: true } });
  }

  private async earnPoints(tx: Tx, customerId: string, totalCents: number, saleId: string) {
    const points = Math.floor(totalCents / 1000);
    if (points <= 0) return;
    await tx.customer.update({ where: { id: customerId }, data: { pointsBalance: { increment: points } } });
    await tx.customerLedger.create({ data: { customerId, type: 'POINTS_EARN', points, referenceId: saleId } });
  }

  private async raiseAlert(tx: Tx, context: UserContext, type: string, severity: AlertSeverity, message: string, referenceId: string | null) {
    await tx.alert.create({ data: { organizationId: context.organizationId, type, severity, message, referenceId } });
  }

  private async assertVariantsInOrganization(organizationId: string, variantIds: string[]) {
    const unique = [...new Set(variantIds)];
    const found = await this.prisma.productVariant.count({ where: { organizationId, id: { in: unique } } });
    if (found !== unique.length) throw new NotFoundException('Product variant not found');
  }

  private async findSession(context: UserContext, sessionId: string, tx: Tx | PrismaService = this.prisma) {
    const session = await tx.registerSession.findFirst({ where: { id: uuid(sessionId, 'sessionId'), organizationId: context.organizationId } });
    if (!session) throw new NotFoundException('Register session not found');
    this.authorization.assertStoreAccess(context, session.storeId);
    return session;
  }

  private async openSessionRow(context: UserContext, sessionId: string, tx: Tx | PrismaService = this.prisma) {
    const session = await this.findSession(context, sessionId, tx);
    if (session.status !== 'OPEN') throw new BadRequestException('Register session is closed');
    return session;
  }

  private async sessionById(context: UserContext, sessionId: string) {
    const session = await this.prisma.registerSession.findFirstOrThrow({
      where: { id: sessionId, organizationId: context.organizationId },
      include: { register: { select: { code: true, name: true } } },
    });
    return this.sessionDto(session);
  }

  private findSaleByClientId(organizationId: string, clientSaleId: string) {
    return this.prisma.sale.findUnique({
      where: { organizationId_clientSaleId: { organizationId, clientSaleId } },
      include: { lines: true, payments: true },
    });
  }

  private async findSaleOrThrow(organizationId: string, saleId: string) {
    const sale = await this.prisma.sale.findFirst({ where: { id: saleId, organizationId }, include: { lines: true, payments: true } });
    if (!sale) throw new NotFoundException('Sale not found');
    return sale;
  }

  private dayBoundary(value: string, field: string, endOfDay: boolean): Date {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new BadRequestException(`${field} must be a YYYY-MM-DD date`);
    const date = new Date(`${value}T${endOfDay ? '23:59:59.999' : '00:00:00.000'}Z`);
    if (Number.isNaN(date.getTime())) throw new BadRequestException(`${field} must be a valid date`);
    return date;
  }

  private optionalDate(value: unknown, field: string): Date | null {
    if (value === undefined || value === null || value === '') return null;
    const date = new Date(String(value));
    if (Number.isNaN(date.getTime())) throw new BadRequestException(`${field} must be a valid date`);
    return date;
  }

  // ───────────── DTO mapping ─────────────

  private sessionDto(session: Prisma.RegisterSessionGetPayload<{ include: { register: { select: { code: true; name: true } } } }>) {
    return {
      id: session.id,
      storeId: session.storeId,
      registerId: session.registerId,
      registerCode: session.register.code,
      registerName: session.register.name,
      status: session.status,
      openingFloatCents: session.openingFloatCents,
      expectedCashCents: session.expectedCashCents,
      countedCashCents: session.countedCashCents,
      varianceCents: session.varianceCents,
      openedAt: session.openedAt,
      closedAt: session.closedAt,
    };
  }

  private saleResult(sale: SaleWithDetails) {
    return {
      sale: {
        id: sale.id,
        receiptNumber: sale.receiptNumber,
        storeId: sale.storeId,
        registerId: sale.registerId,
        sessionId: sale.sessionId,
        status: sale.status,
        subtotalCents: sale.subtotalCents,
        discountCents: sale.discountCents,
        taxCents: sale.taxCents,
        totalCents: sale.totalCents,
        notes: sale.notes,
        customerId: sale.customerId,
        createdAt: sale.createdAt,
        lines: sale.lines.map((line) => ({
          id: line.id,
          variantId: line.variantId,
          sku: line.sku,
          name: line.name,
          quantity: num(line.quantity),
          unitPriceCents: line.unitPriceCents,
          taxCents: line.taxCents,
          lineTotalCents: line.lineTotalCents,
          note: line.note,
        })),
        payments: sale.payments.map((payment) => ({ tenderType: payment.tenderType, amountCents: payment.amountCents, reference: payment.reference })),
      },
    };
  }

  private locationDto(location: { id: string; storeId: string | null; code: string; name: string; status: string; createdAt: Date }) {
    return { id: location.id, storeId: location.storeId, code: location.code, name: location.name, status: location.status, createdAt: location.createdAt };
  }

  private promotionDto(promotion: Prisma.PromotionGetPayload<object>) {
    return {
      id: promotion.id,
      code: promotion.code,
      type: promotion.type,
      value: num(promotion.value),
      minSubtotalCents: promotion.minSubtotalCents,
      usageLimit: promotion.usageLimit,
      usageCount: promotion.usageCount,
      startsAt: promotion.startsAt,
      endsAt: promotion.endsAt,
      status: promotion.status,
    };
  }

  private transferDto(transfer: Prisma.TransferGetPayload<{ include: { fromLocation: { select: { name: true } }; toLocation: { select: { name: true } } } }>) {
    return {
      id: transfer.id,
      fromLocationId: transfer.fromLocationId,
      fromLocationName: transfer.fromLocation.name,
      toLocationId: transfer.toLocationId,
      toLocationName: transfer.toLocation.name,
      status: transfer.status,
      notes: transfer.notes,
      createdAt: transfer.createdAt,
      updatedAt: transfer.updatedAt,
    };
  }
}
