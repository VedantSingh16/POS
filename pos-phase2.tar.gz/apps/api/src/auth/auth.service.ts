import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import { AuditService } from '../audit/audit.service.js';
import { PrismaService } from '../database/prisma.service.js';
import { hashPassword, verifyPassword } from '../security/password.js';
import { AuthorizationService } from './authorization.service.js';
import { UserContext } from './auth.types.js';

type LoginInput = {
  email?: unknown;
  password?: unknown;
  pin?: unknown;
  organizationSlug?: unknown;
};

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const SESSION_HOURS = 8;
const IDLE_MINUTES = 60;

const sha256 = (value: string) => createHash('sha256').update(value).digest('hex');

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly authorization: AuthorizationService,
    private readonly audit: AuditService,
  ) {}

  async login(input: LoginInput): Promise<{ accessToken: string; expiresAt: string; user: UserContext }> {
    const email = this.normalizedEmail(input.email);
    const password = typeof input.password === 'string' ? input.password : '';
    const pin = typeof input.pin === 'string' ? input.pin : '';
    const organizationSlug = typeof input.organizationSlug === 'string' ? input.organizationSlug.trim() : undefined;

    // An email can exist in more than one organisation. Without an organisation slug the account is
    // ambiguous: the organisations are only revealed to someone who proves they know the password.
    const candidates = await this.prisma.user.findMany({
      where: { email, ...(organizationSlug ? { organization: { slug: organizationSlug } } : {}) },
      include: { organization: { select: { slug: true, name: true } } },
      take: 20,
    });
    const isLocked = (u: (typeof candidates)[number]) => Boolean(u.lockedUntil && u.lockedUntil.getTime() > Date.now());
    const credentialOk = (u: (typeof candidates)[number]) =>
      u.status === 'ACTIVE' && ((password && verifyPassword(password, u.passwordHash)) || (pin && u.pinHash && verifyPassword(pin, u.pinHash)));

    if (candidates.length > 1) {
      const matching = candidates.filter((u) => !isLocked(u) && credentialOk(u));
      if (matching.length > 0) {
        throw new ConflictException({
          code: 'ORGANISATION_REQUIRED',
          message: 'This email belongs to more than one organisation. Choose one to continue.',
          organisations: matching.map((u) => ({ slug: u.organization.slug, name: u.organization.name })),
        });
      }
      for (const candidate of candidates) await this.recordFailure(candidate);
      throw new UnauthorizedException('Invalid email or password');
    }

    const user = candidates[0];
    if (user && isLocked(user)) {
      throw new UnauthorizedException('Account temporarily locked after repeated failed attempts');
    }
    if (!user || !credentialOk(user)) {
      if (user) await this.recordFailure(user);
      throw new UnauthorizedException('Invalid email or password');
    }

    const rawToken = randomBytes(32).toString('base64url');
    const now = new Date();
    const expiresAt = new Date(now.getTime() + SESSION_HOURS * 3_600_000);

    await this.prisma.$transaction(async (tx) => {
      await tx.session.create({
        data: { tokenHash: sha256(rawToken), userId: user.id, organizationId: user.organizationId, expiresAt, lastSeenAt: now },
      });
      await tx.user.update({ where: { id: user.id }, data: { lastLoginAt: now, failedAttempts: 0, lockedUntil: null } });
      await this.audit.record({ organizationId: user.organizationId, userId: user.id }, 'auth.login', 'User', user.id, {}, tx);
    });

    return { accessToken: rawToken, expiresAt: expiresAt.toISOString(), user: await this.authorization.getUserContext(user.id) };
  }

  async authenticateToken(rawToken: string): Promise<UserContext> {
    const tokenHash = sha256(rawToken);
    const session = await this.prisma.session.findUnique({ where: { tokenHash } });

    if (!session || session.expiresAt.getTime() <= Date.now()) {
      if (session) await this.prisma.session.deleteMany({ where: { tokenHash } });
      throw new UnauthorizedException('Session is missing or expired');
    }
    if (session.lastSeenAt.getTime() + IDLE_MINUTES * 60_000 <= Date.now()) {
      await this.prisma.session.deleteMany({ where: { tokenHash } });
      throw new UnauthorizedException('Session expired after inactivity');
    }
    await this.prisma.session.update({ where: { tokenHash }, data: { lastSeenAt: new Date() } });
    return this.authorization.getUserContext(session.userId);
  }

  async logout(rawToken: string): Promise<void> {
    await this.prisma.session.deleteMany({ where: { tokenHash: sha256(rawToken) } });
  }

  async setPin(context: UserContext, pin: string): Promise<void> {
    if (!/^\d{4,8}$/.test(pin)) throw new UnauthorizedException('PIN must contain 4 to 8 digits');
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: context.userId }, data: { pinHash: hashPassword(pin) } });
      await this.audit.record(context, 'auth.pin.updated', 'User', context.userId, {}, tx);
    });
  }

  /** Counts a failed credential check and locks the account (audited) once the limit is reached. */
  private async recordFailure(user: { id: string; organizationId: string; failedAttempts: number }): Promise<void> {
    const failedAttempts = user.failedAttempts + 1;
    const locking = failedAttempts >= MAX_FAILED_ATTEMPTS;
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: user.id },
        data: { failedAttempts, lockedUntil: locking ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null },
      });
      if (locking) {
        await this.audit.record({ organizationId: user.organizationId, userId: user.id }, 'auth.lockout', 'User', user.id, { failedAttempts, lockMinutes: LOCK_MINUTES }, tx);
      }
    });
  }

  /** Re-checks the signed-in user's PIN to unlock a shared till. Shares the failure counter with login. */
  async verifyPin(context: UserContext, pin: unknown): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { id: context.userId } });
    if (!user || user.status !== 'ACTIVE') throw new UnauthorizedException('Invalid PIN');
    if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      throw new UnauthorizedException('Account temporarily locked after repeated failed attempts');
    }
    if (typeof pin !== 'string' || !user.pinHash || !verifyPassword(pin, user.pinHash)) {
      await this.recordFailure(user);
      throw new UnauthorizedException('Invalid PIN');
    }
    await this.prisma.user.update({ where: { id: user.id }, data: { failedAttempts: 0, lockedUntil: null } });
    await this.audit.record(context, 'auth.unlock', 'User', user.id, {});
  }

  private normalizedEmail(value: unknown): string {
    if (typeof value !== 'string' || !value.includes('@')) throw new UnauthorizedException('Invalid email or password');
    return value.trim().toLowerCase();
  }

  hashPassword(password: string): string {
    return hashPassword(password);
  }
}
