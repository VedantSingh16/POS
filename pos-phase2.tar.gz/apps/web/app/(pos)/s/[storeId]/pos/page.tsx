import { PosScreen } from "@/features/pos/pos-screen";
import { api } from "@/features/api";
import { requirePermission } from "@/lib/server/session";
import { SessionProvider } from "@/components/app/session-context";

export const metadata = { title: "Point of sale" };

export default async function PosPage({ params }: PageProps<"/s/[storeId]/pos">) {
  const { storeId } = await params;
  const me = await requirePermission("sale.create", storeId);
  const store = me.stores.find((s) => s.id === storeId)!;
  const [{ data: products, preview }, { data: categories }] = await Promise.all([api.products(), api.categories()]);
  return (
    <SessionProvider me={me}>
      <PosScreen storeId={storeId} storeName={store.name} cashier={me.user.displayName} preview={preview} products={products} categories={categories.map((c) => c.name)} canExit={me.permissions.organization.length > 0 || (me.permissions.stores[storeId] ?? []).some((p) => p !== "sale.create")} />
    </SessionProvider>
  );
}
