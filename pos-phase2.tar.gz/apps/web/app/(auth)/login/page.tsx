import { redirect } from "next/navigation";
import { Suspense } from "react";
import { LoginForm } from "@/features/auth/login-form";
import { landingPath } from "@/lib/permissions";
import { getSession, isLocked } from "@/lib/server/session";

export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  const me = await getSession();
  if (me) redirect((await isLocked()) ? "/lock" : landingPath(me));
  return <Suspense><LoginForm /></Suspense>;
}
