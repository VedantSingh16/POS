import { requirePermission } from "@/lib/server/session";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PermissionMatrix } from "@/features/permission-matrix";
import { api } from "@/features/api";

export default async function RoleDetail({ params }: PageProps<"/org/roles/[id]">) {
  await requirePermission("roles.view");
  const { id } = await params;
  const { data: role, preview } = await api.role(id);
  if (!role) notFound();
  const { data: groups } = await api.permissionGroups();
  return (
    <>
      <PageHeader title={role.name} description={role.description} preview={preview} crumbs={[{ label: "Organisation", href: "/org" }, { label: "Roles", href: "/org/roles" }, { label: role.name }]} />
      <Card>
        <CardHeader><CardTitle>Permissions</CardTitle><span className="text-xs text-muted-foreground">{role.system ? "System role: read only" : "Custom role"}</span></CardHeader>
        <CardContent><PermissionMatrix groups={groups} readOnly={role.system} /></CardContent>
      </Card>
    </>
  );
}
