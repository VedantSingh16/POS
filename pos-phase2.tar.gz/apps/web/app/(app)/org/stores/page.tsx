import { requirePermission } from "@/lib/server/session";
import { PageHeader } from "@/components/app/page-header";
import { NewStoreSheet } from "@/features/forms";
import { StoresTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Stores" };

export default async function StoresPage() {
  await requirePermission("stores.view");
  const [{ data, preview }, { data: org }] = await Promise.all([api.stores(), api.org()]);
  return (
    <>
      <PageHeader title="Stores" description="Locations, their registers and staff." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Stores" }]} preview={preview} actions={<NewStoreSheet used={data.length} max={org.maxStores} />} />
      <StoresTable data={data} />
    </>
  );
}
