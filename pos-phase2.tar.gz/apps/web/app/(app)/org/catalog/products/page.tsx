import { requirePermission } from "@/lib/server/session";
import Link from "next/link";
import { Plus, Upload } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { buttonVariants } from "@/components/ui/button";
import { PreviewAction } from "@/features/forms";
import { ProductsTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Products" };

export default async function ProductsPage() {
  await requirePermission("catalog.view");
  const { data, preview } = await api.products();
  return (
    <>
      <PageHeader title="Products" description="The organisation catalogue. Stock shown is across all stores." crumbs={[{ label: "Catalogue" }, { label: "Products" }]} preview={preview}
        actions={<><Link href="/org/catalog/import" className={buttonVariants({ variant: "outline" })}><Upload /> Import</Link><PreviewAction label="New product" icon={<Plus />} /></>} />
      <ProductsTable data={data} />
    </>
  );
}
