import { requirePermission } from "@/lib/server/session";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { Money, StatusBadge } from "@/components/data/primitives";
import { Card, CardContent } from "@/components/ui/card";
import { api } from "@/features/api";

export default async function ProductDetail({ params }: PageProps<"/org/catalog/products/[id]">) {
  await requirePermission("catalog.view");
  const { id } = await params;
  const { data: p, preview } = await api.product(id);
  if (!p) notFound();
  const rows: [string, React.ReactNode][] = [["SKU", p.sku], ["Barcode", p.barcode], ["Category", p.category], ["Price (incl. tax)", <Money key="m" minor={p.priceMinor} />], ["GST", `${p.taxRate}%`], ["Stock", p.stock], ["Status", <StatusBadge key="s" status={p.status} />]];
  return (
    <>
      <PageHeader title={p.name} preview={preview} crumbs={[{ label: "Catalogue" }, { label: "Products", href: "/org/catalog/products" }, { label: p.name }]} />
      <Card><CardContent className="grid gap-4 sm:grid-cols-3">{rows.map(([k, v]) => <div key={k}><p className="text-xs text-muted-foreground">{k}</p><p className="font-medium">{v}</p></div>)}</CardContent></Card>
    </>
  );
}
