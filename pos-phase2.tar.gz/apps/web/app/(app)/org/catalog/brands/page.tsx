import { requirePermission } from "@/lib/server/session";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { PreviewAction } from "@/features/forms";
import { NamedTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Brands" };

export default async function Page() {
  await requirePermission("catalog.view");
  const { data, preview } = await api.brands();
  return (
    <>
      <PageHeader title="Brands" description="Organisation-wide catalogue structure." crumbs={[{ label: "Catalogue", href: "/org/catalog/products" }, { label: "Brands" }]} preview={preview} actions={<PreviewAction label="Add" icon={<Plus />} />} />
      <NamedTable data={data} noun="Brand" />
    </>
  );
}
