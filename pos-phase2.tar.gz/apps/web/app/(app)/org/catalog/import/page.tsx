import { requirePermission } from "@/lib/server/session";
import { FileSpreadsheet } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { EmptyState } from "@/components/data/primitives";
import { Card } from "@/components/ui/card";
import { PreviewAction } from "@/features/forms";

export const metadata = { title: "Import products" };

export default async function ImportPage() {
  await requirePermission("catalog.manage");
  return (
    <>
      <PageHeader title="Import products" description="Upload a CSV, review the rows, then confirm." crumbs={[{ label: "Catalogue" }, { label: "Products", href: "/org/catalog/products" }, { label: "Import" }]} />
      <Card><EmptyState icon={FileSpreadsheet} title="No file selected" description="Import arrives in a later phase. Columns: SKU, name, category, price, GST, barcode." action={<PreviewAction label="Choose CSV" variant="outline" />} /></Card>
    </>
  );
}
