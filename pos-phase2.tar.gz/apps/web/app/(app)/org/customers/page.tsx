import { requirePermission } from "@/lib/server/session";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { PreviewAction } from "@/features/forms";
import { CustomersTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Customers" };

export default async function CustomersPage() {
  await requirePermission("customer.view");
  const { data, preview } = await api.customers();
  return (
    <>
      <PageHeader title="Customers" description="Shared across every store." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Customers" }]} preview={preview} actions={<PreviewAction label="New customer" icon={<Plus />} />} />
      <CustomersTable data={data} />
    </>
  );
}
