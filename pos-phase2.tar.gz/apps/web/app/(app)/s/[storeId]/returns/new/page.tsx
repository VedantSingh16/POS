import { requirePermission } from "@/lib/server/session";
import { Undo2 } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { EmptyState } from "@/components/data/primitives";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export const metadata = { title: "New return" };

export default async function NewReturn({ params }: PageProps<"/s/[storeId]/returns/new">) {
  const { storeId } = await params;
  await requirePermission("refund.create", storeId);
  return (
    <>
      <PageHeader title="New return" description="Find the original receipt first." crumbs={[{ label: "Returns", href: `/s/${storeId}/returns` }, { label: "New" }]} preview />
      <Card className="max-w-xl"><div className="p-4"><label htmlFor="rcpt" className="text-xs font-medium text-muted-foreground">Receipt number</label><Input id="rcpt" placeholder="TAX-YYYYMMDD-0000" className="mt-1.5" /></div>
        <EmptyState icon={Undo2} title="No receipt loaded" description="Enter a receipt number to choose the lines being returned." /></Card>
    </>
  );
}
