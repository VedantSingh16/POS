import { requirePermission } from "@/lib/server/session";
import { PageHeader } from "@/components/app/page-header";
import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";
import { InventoryTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Inventory" };

export default async function Page({ params }: PageProps<"/s/[storeId]/inventory">) {
  const { storeId } = await params;
  await requirePermission("inventory.view", storeId);
  const { data, preview } = await api.inventory();
  return (
    <>
      <PageHeader title="Inventory" description="Stock on hand in this store." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Inventory" }]} preview={preview} actions={<><Link href={`/s/${storeId}/inventory/ledger`} className={buttonVariants({ variant: "outline" })}>Ledger</Link><Link href={`/s/${storeId}/inventory/adjust`} className={buttonVariants()}>Adjust stock</Link></>} />
      <InventoryTable data={data} />
    </>
  );
}
