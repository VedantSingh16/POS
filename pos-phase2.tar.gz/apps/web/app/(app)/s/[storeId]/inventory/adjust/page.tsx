import { requirePermission } from "@/lib/server/session";
import { PageHeader } from "@/components/app/page-header";
import { AdjustStockForm } from "@/features/adjust-form";

export const metadata = { title: "Adjust stock" };

export default async function Adjust({ params }: PageProps<"/s/[storeId]/inventory/adjust">) {
  const { storeId } = await params;
  await requirePermission("inventory.manage", storeId);
  return (
    <>
      <PageHeader title="Adjust stock" description="Record a count correction, damage or receipt." crumbs={[{ label: "Inventory", href: `/s/${storeId}/inventory` }, { label: "Adjust" }]} preview />
      <AdjustStockForm />
    </>
  );
}
