import { hasOrgScope, hasPermission, type Me } from "@/lib/permissions";
import {
  LayoutDashboard, Users, ShieldCheck, Store, Package, Tags, Percent, UserRound, BarChart3, Settings,
  ScrollText, Receipt, Undo2, Boxes, Landmark, CheckCheck, Bell, ShoppingCart, type LucideIcon,
} from "lucide-react";

export type NavItem = {
  label: string;
  /** `:storeId` is replaced with the active store. */
  href: string;
  icon: LucideIcon;
  /** Permission code that gates visibility (enforced again by the API). Enforcement arrives in Phase 2. */
  permission?: string;
  keywords?: string[];
};
export type NavSection = { id: "org" | "store"; title: string; items: NavItem[] };

export const NAV: NavSection[] = [
  {
    id: "org",
    title: "Organisation",
    items: [
      { label: "Overview", href: "/org", icon: LayoutDashboard },
      { label: "Users", href: "/org/users", icon: Users, permission: "users.view" },
      { label: "Roles", href: "/org/roles", icon: ShieldCheck, permission: "roles.view" },
      { label: "Stores", href: "/org/stores", icon: Store, permission: "stores.view" },
      { label: "Products", href: "/org/catalog/products", icon: Package, permission: "catalog.view", keywords: ["catalogue", "items"] },
      { label: "Categories", href: "/org/catalog/categories", icon: Tags, permission: "catalog.view" },
      { label: "Brands", href: "/org/catalog/brands", icon: Tags, permission: "catalog.view" },
      { label: "Tax groups", href: "/org/catalog/tax", icon: Percent, permission: "catalog.view", keywords: ["gst"] },
      { label: "Customers", href: "/org/customers", icon: UserRound, permission: "customer.view" },
      { label: "Reports", href: "/org/reports", icon: BarChart3, permission: "report.view" },
      { label: "Settings", href: "/org/settings/general", icon: Settings, permission: "org.settings.manage" },
      { label: "Audit log", href: "/org/audit", icon: ScrollText, permission: "audit.view" },
    ],
  },
  {
    id: "store",
    title: "Store",
    items: [
      { label: "Dashboard", href: "/s/:storeId", icon: LayoutDashboard },
      { label: "Point of sale", href: "/s/:storeId/pos", icon: ShoppingCart, permission: "sale.create", keywords: ["checkout", "till", "register"] },
      { label: "Sales", href: "/s/:storeId/sales", icon: Receipt, permission: "sale.create", keywords: ["receipts"] },
      { label: "Returns", href: "/s/:storeId/returns", icon: Undo2, permission: "refund.create", keywords: ["refund"] },
      { label: "Inventory", href: "/s/:storeId/inventory", icon: Boxes, permission: "inventory.view", keywords: ["stock"] },
      { label: "Registers", href: "/s/:storeId/registers", icon: Landmark, permission: "registers.view", keywords: ["cash", "shift"] },
      { label: "Approvals", href: "/s/:storeId/approvals", icon: CheckCheck, permission: "approval.manage" },
      { label: "Alerts", href: "/s/:storeId/alerts", icon: Bell },
      { label: "Staff", href: "/s/:storeId/staff", icon: Users, permission: "users.view" },
      { label: "Store reports", href: "/s/:storeId/reports", icon: BarChart3, permission: "report.view" },
    ],
  },
];

export const resolveHref = (href: string, storeId: string) => href.replace(":storeId", storeId);

/** Labels for breadcrumb segments. */
export const SEGMENT_LABELS: Record<string, string> = {
  org: "Organisation", s: "Stores", users: "Users", roles: "Roles", stores: "Stores", catalog: "Catalogue",
  products: "Products", categories: "Categories", brands: "Brands", tax: "Tax groups", customers: "Customers",
  reports: "Reports", settings: "Settings", general: "General", receipts: "Receipts", approvals: "Approvals",
  security: "Security", audit: "Audit log", sales: "Sales", returns: "Returns", inventory: "Inventory",
  ledger: "Ledger", adjust: "Adjust stock", registers: "Registers", alerts: "Alerts", staff: "Staff",
  import: "Import", new: "New", pos: "Point of sale",
};


/** Navigation the user is allowed to see. Org section needs an organisation-wide grant; store items are checked against the active store. */
export function visibleNav(me: Me, storeId: string): NavSection[] {
  return NAV.flatMap((section) => {
    if (section.id === "org" && !hasOrgScope(me)) return [];
    if (section.id === "store" && !me.stores.some((s) => s.id === storeId)) return [];
    const items = section.items.filter((item) => !item.permission || hasPermission(me, item.permission, section.id === "store" ? storeId : undefined));
    return items.length ? [{ ...section, items }] : [];
  });
}
