import { describe, expect, it } from "vitest";
import { canAccessStore, hasOrgScope, hasPermission, landingPath, safeNext, type Me } from "../permissions";
import { visibleNav } from "../nav";

const A = "store-a";
const B = "store-b";
const base = { hasPin: false, organisation: { id: "o", name: "Org", slug: "org" } };
const user = (over: Partial<Me["user"]> = {}) => ({ userId: "u", email: "u@x", displayName: "U", defaultStoreId: A, isOrganisationAdministrator: false, ...over });
const stores = [{ id: A, code: "A", name: "Store A" }, { id: B, code: "B", name: "Store B" }];

const admin: Me = { ...base, user: user({ isOrganisationAdministrator: true }), roles: [], stores, permissions: { organization: ["org.overview.view", "users.view", "sale.create", "catalog.view"], stores: {} } };
const manager: Me = { ...base, user: user(), roles: [], stores: [stores[0]], permissions: { organization: [], stores: { [A]: ["org.overview.view", "report.view", "sale.create", "registers.view"] } } };
const cashier: Me = { ...base, user: user(), roles: [], stores: [stores[0]], permissions: { organization: [], stores: { [A]: ["sale.create", "registers.view", "catalog.view"] } } };
const inventory: Me = { ...base, user: user(), roles: [], stores: [stores[0]], permissions: { organization: [], stores: { [A]: ["catalog.view", "inventory.view"] } } };

describe("permissions", () => {
  it("org-wide grants apply to every store; store grants only to their store", () => {
    expect(hasPermission(admin, "sale.create", B)).toBe(true);
    expect(hasPermission(cashier, "sale.create", A)).toBe(true);
    expect(hasPermission(cashier, "sale.create", B)).toBe(false);
    expect(hasPermission(cashier, "sale.create")).toBe(false);
  });
  it("only organisation-wide grants open the organisation area", () => {
    expect(hasOrgScope(admin)).toBe(true);
    expect(hasOrgScope(manager)).toBe(false);
  });
  it("store access follows the reachable store list", () => {
    expect(canAccessStore(cashier, A)).toBe(true);
    expect(canAccessStore(cashier, B)).toBe(false);
  });
  it.each([
    ["admin", admin, "/org"],
    ["manager", manager, `/s/${A}`],
    ["cashier", cashier, `/s/${A}/pos`],
    ["inventory user", inventory, `/s/${A}`],
  ])("lands %s on the right page", (_n, me, expected) => expect(landingPath(me)).toBe(expected));
  it("a user with nothing is sent to /forbidden", () => {
    expect(landingPath({ ...cashier, stores: [], permissions: { organization: [], stores: {} } })).toBe("/forbidden");
  });
  it("navigation is filtered by role and store", () => {
    const labels = (me: Me, store: string) => visibleNav(me, store).flatMap((s) => s.items.map((i) => i.label));
    expect(labels(cashier, A)).toEqual(expect.arrayContaining(["Dashboard", "Point of sale", "Registers", "Alerts"]));
    expect(labels(cashier, A)).not.toEqual(expect.arrayContaining(["Users", "Roles", "Reports", "Audit log", "Inventory"]));
    expect(labels(cashier, B)).toEqual([]);
    expect(labels(admin, A)).toEqual(expect.arrayContaining(["Overview", "Users", "Products"]));
    expect(labels(manager, A)).toEqual(expect.arrayContaining(["Store reports"]));
    expect(labels(manager, A)).not.toContain("Users");
  });
  it("only same-site relative redirects are honoured", () => {
    expect(safeNext("/org/users")).toBe("/org/users");
    for (const bad of ["https://evil.example", "//evil.example", "/\\evil", "javascript:alert(1)", "", null, undefined]) expect(safeNext(bad as string)).toBeNull();
  });
});
