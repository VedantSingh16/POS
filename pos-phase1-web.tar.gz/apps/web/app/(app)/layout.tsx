import { AppShell } from "@/components/app/app-shell";
import { api } from "@/features/api";

export default async function AppLayout({ children }: LayoutProps<"/">) {
  const [{ data: org }, { data: stores }] = await Promise.all([api.org(), api.stores()]);
  const active = stores.filter((s) => s.status === "ACTIVE");
  return (
    <AppShell orgName={org.name} stores={active.map(({ id, code, name }) => ({ id, code, name }))} defaultStoreId={active[0]?.id ?? ""}>
      {children}
    </AppShell>
  );
}
