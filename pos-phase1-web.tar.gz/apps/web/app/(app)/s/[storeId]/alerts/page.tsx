import { AlertTriangle, Info, OctagonAlert } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { Card } from "@/components/ui/card";
import { timeAgo } from "@/lib/format";
import { api } from "@/features/api";

export const metadata = { title: "Alerts" };
const ICON = { warning: AlertTriangle, danger: OctagonAlert, info: Info } as const;
const COLOR = { warning: "text-warning", danger: "text-danger", info: "text-info" } as const;

export default async function Alerts({ params }: PageProps<"/s/[storeId]/alerts">) {
  const { storeId } = await params;
  const { data, preview } = await api.alerts();
  return (
    <>
      <PageHeader title="Alerts" description="Low stock, cash variance and registers left open." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Alerts" }]} preview={preview} />
      <Card><ul className="divide-y">{data.map((a) => { const Icon = ICON[a.severity as keyof typeof ICON]; return (
        <li key={a.id} className="flex items-start gap-3 p-4"><Icon className={`mt-0.5 size-4 ${COLOR[a.severity as keyof typeof COLOR]}`} /><div className="min-w-0 flex-1"><p className="font-medium">{a.title}</p><p className="text-sm text-muted-foreground">{a.detail}</p></div><span className="text-xs text-muted-foreground">{timeAgo(a.at)}</span></li>); })}</ul></Card>
    </>
  );
}
