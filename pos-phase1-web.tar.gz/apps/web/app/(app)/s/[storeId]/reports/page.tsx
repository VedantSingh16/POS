import { PageHeader } from "@/components/app/page-header";
import { HourChart, TenderChart, TrendChart } from "@/components/data/charts";
import { api } from "@/features/api";

export const metadata = { title: "Store reports" };

export default async function StoreReports({ params }: PageProps<"/s/[storeId]/reports">) {
  const { storeId } = await params;
  const { data, preview } = await api.charts();
  return (
    <>
      <PageHeader title="Store reports" description="Sales performance for this store." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Reports" }]} preview={preview} />
      <div className="grid gap-4 lg:grid-cols-2"><TrendChart data={data.trend} /><HourChart data={data.byHour} /><TenderChart data={data.tender} /></div>
    </>
  );
}
