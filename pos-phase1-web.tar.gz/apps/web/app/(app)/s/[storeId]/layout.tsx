import { notFound } from "next/navigation";
import { api } from "@/features/api";

export default async function StoreLayout({ children, params }: LayoutProps<"/s/[storeId]">) {
  const { storeId } = await params;
  const { data: store } = await api.store(storeId);
  if (!store) notFound();
  return <>{children}</>;
}
