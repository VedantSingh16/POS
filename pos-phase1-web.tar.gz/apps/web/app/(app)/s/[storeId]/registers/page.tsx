import { PageHeader } from "@/components/app/page-header";
import { RegistersTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Registers" };

export default async function Page({ params }: PageProps<"/s/[storeId]/registers">) {
  const { storeId } = await params;
  const { data, preview } = await api.registers();
  return (
    <>
      <PageHeader title="Registers" description="Tills and their current sessions." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Registers" }]} preview={preview} />
      <RegistersTable data={data} storeId={storeId} />
    </>
  );
}
