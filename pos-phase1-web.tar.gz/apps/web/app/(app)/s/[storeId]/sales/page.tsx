import { PageHeader } from "@/components/app/page-header";
import { SalesTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Sales" };

export default async function Page({ params }: PageProps<"/s/[storeId]/sales">) {
  const { storeId } = await params;
  const { data, preview } = await api.sales();
  return (
    <>
      <PageHeader title="Sales" description="Completed, voided and returned receipts." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Sales" }]} preview={preview} />
      <SalesTable data={data} storeId={storeId} />
    </>
  );
}
