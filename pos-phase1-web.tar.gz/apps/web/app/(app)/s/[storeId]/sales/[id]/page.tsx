import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { Money, StatusBadge } from "@/components/data/primitives";
import { Card, CardContent } from "@/components/ui/card";
import { api } from "@/features/api";

export default async function SaleDetail({ params }: PageProps<"/s/[storeId]/sales/[id]">) {
  const { storeId, id } = await params;
  const { data: s, preview } = await api.sale(id);
  if (!s) notFound();
  return (
    <>
      <PageHeader title={s.receipt} preview={preview} crumbs={[{ label: "Sales", href: `/s/${storeId}/sales` }, { label: s.receipt }]} />
      <Card><CardContent className="grid gap-4 sm:grid-cols-4">
        <div><p className="text-xs text-muted-foreground">Total</p><Money minor={s.totalMinor} /></div>
        <div><p className="text-xs text-muted-foreground">Tender</p><p>{s.tender}</p></div>
        <div><p className="text-xs text-muted-foreground">Cashier</p><p>{s.cashier}</p></div>
        <div><p className="text-xs text-muted-foreground">Status</p><StatusBadge status={s.status} /></div>
      </CardContent></Card>
    </>
  );
}
