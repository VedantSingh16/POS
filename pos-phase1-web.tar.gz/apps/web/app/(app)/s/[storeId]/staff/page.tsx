import { PageHeader } from "@/components/app/page-header";
import { UsersTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Staff" };

export default async function Page({ params }: PageProps<"/s/[storeId]/staff">) {
  const { storeId } = await params;
  const { data, preview } = await api.users();
  return (
    <>
      <PageHeader title="Staff" description="People assigned to this store." crumbs={[{ label: "Store", href: `/s/${storeId}` }, { label: "Staff" }]} preview={preview} />
      <UsersTable data={data} />
    </>
  );
}
