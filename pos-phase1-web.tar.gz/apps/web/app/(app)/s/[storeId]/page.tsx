import Link from "next/link";
import { Banknote, Receipt, ShoppingCart, TriangleAlert } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { HourChart, TenderChart } from "@/components/data/charts";
import { KpiTile } from "@/components/data/primitives";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Money } from "@/components/data/primitives";
import { api } from "@/features/api";

export const metadata = { title: "Store dashboard" };

export default async function StoreDashboard({ params }: PageProps<"/s/[storeId]">) {
  const { storeId } = await params;
  const [{ data: store, preview }, { data: charts }, { data: alerts }, { data: sales }] = await Promise.all([api.store(storeId), api.charts(), api.alerts(), api.sales()]);
  const today = sales.filter((s) => s.status !== "VOIDED" && s.at.startsWith("2026-10-07"));
  const gross = today.reduce((a, s) => a + s.totalMinor, 0);
  return (
    <>
      <PageHeader title={store?.name ?? "Store"} description="Today at a glance." crumbs={[{ label: "Stores" }, { label: store?.name ?? "" }]} preview={preview}
        actions={<Link href={`/s/${storeId}/pos`} className={buttonVariants()}><ShoppingCart /> Open POS</Link>} />
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiTile label="Sales today" value={<Money minor={gross} className="text-2xl font-semibold" />} hint={`${today.length} receipts`} icon={Receipt} />
        <KpiTile label="Average basket" value={<Money minor={today.length ? Math.round(gross / today.length) : 0} className="text-2xl font-semibold" />} icon={ShoppingCart} />
        <KpiTile label="Cash in open tills" value={<Money minor={2765000} className="text-2xl font-semibold" />} hint="2 registers open" icon={Banknote} />
        <KpiTile label="Open alerts" value={alerts.length} hint="Stock and register" icon={TriangleAlert} tone="warning" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2"><HourChart data={charts.byHour} /></div>
        <TenderChart data={charts.tender} />
        <Card className="lg:col-span-3">
          <CardHeader><CardTitle>Alerts</CardTitle><Link href={`/s/${storeId}/alerts`} className="text-xs text-primary hover:underline">View all</Link></CardHeader>
          <CardContent><ul className="grid gap-2">{alerts.map((a) => <li key={a.id} className="text-sm"><span className="font-medium">{a.title}</span> <span className="text-muted-foreground">· {a.detail}</span></li>)}</ul></CardContent>
        </Card>
      </div>
    </>
  );
}
