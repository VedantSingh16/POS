import { AlertTriangle, CheckCircle2, Circle, Store, Users } from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/app/page-header";
import { KpiTile } from "@/components/data/primitives";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AuditTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Overview" };

const CHECKLIST = [
  { label: "Organisation details", done: true, href: "/org/settings/general" },
  { label: "First store created", done: true, href: "/org/stores" },
  { label: "Roles reviewed", done: true, href: "/org/roles" },
  { label: "Products imported", done: false, href: "/org/catalog/import" },
  { label: "Tax and receipt settings", done: false, href: "/org/settings/tax" },
];

export default async function OrgOverview() {
  const [{ data: org }, { data: stores }, { data: users }, { data: audit }] = await Promise.all([api.org(), api.stores(), api.users(), api.audit()]);
  const done = CHECKLIST.filter((c) => c.done).length;
  return (
    <>
      <PageHeader title="Organisation overview" description={`${org.name}: setup, stores and recent activity.`} preview />
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <KpiTile label="Stores" value={`${stores.length} / ${org.maxStores}`} hint="Plan limit" icon={Store} />
        <KpiTile label="Active staff" value={users.filter((u) => u.status === "ACTIVE").length} hint={`${users.length} total`} icon={Users} />
        <KpiTile label="Setup progress" value={`${done} / ${CHECKLIST.length}`} hint="Checklist items" icon={CheckCircle2} tone="success" />
        <KpiTile label="Needs attention" value={users.filter((u) => u.status === "SUSPENDED").length} hint="Suspended users" icon={AlertTriangle} tone="warning" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader><CardTitle>Setup checklist</CardTitle></CardHeader>
          <CardContent>
            <ul className="grid gap-2">
              {CHECKLIST.map((c) => (
                <li key={c.label}>
                  <Link href={c.href} className="flex items-center gap-2 text-sm hover:underline">
                    {c.done ? <CheckCircle2 className="size-4 text-success" /> : <Circle className="size-4 text-muted-foreground" />}
                    <span className={c.done ? "text-muted-foreground line-through" : "font-medium"}>{c.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <div className="lg:col-span-2">
          <h2 className="mb-2 text-sm font-semibold">Recent activity</h2>
          <AuditTable data={audit} />
        </div>
      </div>
    </>
  );
}
