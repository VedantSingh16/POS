import { PageHeader } from "@/components/app/page-header";
import { HourChart, TenderChart, TrendChart } from "@/components/data/charts";
import { api } from "@/features/api";

export const metadata = { title: "Reports" };

export default async function ReportsPage() {
  const { data, preview } = await api.charts();
  return (
    <>
      <PageHeader title="Reports" description="Organisation-wide sales performance." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Reports" }]} preview={preview} />
      <div className="grid gap-4 lg:grid-cols-2"><TrendChart data={data.trend} /><HourChart data={data.byHour} /><TenderChart data={data.tender} /></div>
    </>
  );
}
