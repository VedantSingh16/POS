import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { StatusBadge } from "@/components/data/primitives";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RegistersTable, UsersTable } from "@/features/tables";
import { api } from "@/features/api";

export default async function StoreDetail({ params }: PageProps<"/org/stores/[id]">) {
  const { id } = await params;
  const { data: store, preview } = await api.store(id);
  if (!store) notFound();
  const [{ data: registers }, { data: users }] = await Promise.all([api.registers(), api.users()]);
  return (
    <>
      <PageHeader title={store.name} description={`${store.code} · ${store.city}`} preview={preview} crumbs={[{ label: "Organisation", href: "/org" }, { label: "Stores", href: "/org/stores" }, { label: store.name }]}
        actions={<Link href={`/s/${store.id}`} className={buttonVariants({ variant: "outline" })}>Open store</Link>} />
      <Tabs defaultValue="overview">
        <TabsList>{["overview", "registers", "staff", "settings"].map((t) => <TabsTrigger key={t} value={t} className="capitalize">{t}</TabsTrigger>)}</TabsList>
        <TabsContent value="overview"><Card><CardContent className="grid gap-3 sm:grid-cols-3">
          <div><p className="text-xs text-muted-foreground">Status</p><StatusBadge status={store.status} /></div>
          <div><p className="text-xs text-muted-foreground">Registers</p><p>{store.registers}</p></div>
          <div><p className="text-xs text-muted-foreground">Staff</p><p>{store.staff}</p></div>
        </CardContent></Card></TabsContent>
        <TabsContent value="registers"><RegistersTable data={registers} storeId={store.id} /></TabsContent>
        <TabsContent value="staff"><UsersTable data={users} /></TabsContent>
        <TabsContent value="settings"><Card><CardContent className="text-sm text-muted-foreground">Store-level receipt, tax and approval overrides arrive with the settings module.</CardContent></Card></TabsContent>
      </Tabs>
    </>
  );
}
