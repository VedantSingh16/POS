import { Card, CardContent } from "@/components/ui/card";
import { PreviewAction } from "@/features/forms";

export const metadata = { title: "Security settings" };
const ROWS = [["Lock after idle", "60 minutes"],["Failed sign-in lockout", "5 attempts / 15 minutes"],["Session length", "8 hours"]];

export default function Page() {
  return (
    <Card><CardContent className="grid gap-4">
      {ROWS.map(([k, v]) => <div key={k} className="flex items-center justify-between gap-4 border-b pb-3 last:border-0 last:pb-0"><div><p className="text-sm font-medium">{k}</p><p className="text-sm text-muted-foreground">{v}</p></div><PreviewAction label="Edit" variant="outline" /></div>)}
    </CardContent></Card>
  );
}
