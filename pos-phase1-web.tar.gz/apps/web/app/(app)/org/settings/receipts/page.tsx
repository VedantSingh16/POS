import { Card, CardContent } from "@/components/ui/card";
import { PreviewAction } from "@/features/forms";

export const metadata = { title: "Receipts settings" };
const ROWS = [["Receipt prefix", "TAX-"],["Footer text", "Thank you for shopping with us."],["Credit note prefix", "CN-"]];

export default function Page() {
  return (
    <Card><CardContent className="grid gap-4">
      {ROWS.map(([k, v]) => <div key={k} className="flex items-center justify-between gap-4 border-b pb-3 last:border-0 last:pb-0"><div><p className="text-sm font-medium">{k}</p><p className="text-sm text-muted-foreground">{v}</p></div><PreviewAction label="Edit" variant="outline" /></div>)}
    </CardContent></Card>
  );
}
