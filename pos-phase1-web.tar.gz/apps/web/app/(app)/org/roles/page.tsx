import { Plus } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { PreviewAction } from "@/features/forms";
import { RolesTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Roles" };

export default async function RolesPage() {
  const { data, preview } = await api.roles();
  return (
    <>
      <PageHeader title="Roles" description="Bundles of permissions you can assign organisation-wide or per store." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Roles" }]} preview={preview} actions={<PreviewAction label="New role" icon={<Plus />} />} />
      <RolesTable data={data} />
    </>
  );
}
