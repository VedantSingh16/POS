import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { Money } from "@/components/data/primitives";
import { Card, CardContent } from "@/components/ui/card";
import { api } from "@/features/api";

export default async function CustomerDetail({ params }: PageProps<"/org/customers/[id]">) {
  const { id } = await params;
  const { data: c, preview } = await api.customer(id);
  if (!c) notFound();
  return (
    <>
      <PageHeader title={c.name} description={c.phone} preview={preview} crumbs={[{ label: "Customers", href: "/org/customers" }, { label: c.name }]} />
      <Card><CardContent className="grid gap-4 sm:grid-cols-3">
        <div><p className="text-xs text-muted-foreground">Tier</p><p className="font-medium">{c.tier}</p></div>
        <div><p className="text-xs text-muted-foreground">Wallet</p><Money minor={c.walletMinor} /></div>
        <div><p className="text-xs text-muted-foreground">Lifetime spend</p><Money minor={c.lifetimeMinor} /></div>
      </CardContent></Card>
    </>
  );
}
