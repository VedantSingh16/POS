import { PageHeader } from "@/components/app/page-header";
import { InviteUserSheet } from "@/features/forms";
import { UsersTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Users" };

export default async function UsersPage() {
  const [{ data, preview }, { data: roles }] = await Promise.all([api.users(), api.roles()]);
  return (
    <>
      <PageHeader title="Users" description="People who can sign in, and what they can do." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Users" }]} preview={preview} actions={<InviteUserSheet roles={roles.map((r) => r.name)} />} />
      <UsersTable data={data} />
    </>
  );
}
