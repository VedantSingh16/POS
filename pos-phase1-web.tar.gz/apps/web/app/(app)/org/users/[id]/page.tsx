import { notFound } from "next/navigation";
import { PageHeader } from "@/components/app/page-header";
import { StatusBadge } from "@/components/data/primitives";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PreviewAction } from "@/features/forms";
import { AuditTable } from "@/features/tables";
import { api } from "@/features/api";

export default async function UserDetail({ params }: PageProps<"/org/users/[id]">) {
  const { id } = await params;
  const { data: user, preview } = await api.user(id);
  if (!user) notFound();
  const { data: audit } = await api.audit();
  return (
    <>
      <PageHeader title={user.name} description={user.email} preview={preview} crumbs={[{ label: "Organisation", href: "/org" }, { label: "Users", href: "/org/users" }, { label: user.name }]} actions={<PreviewAction label="Suspend" variant="outline" />} />
      <Tabs defaultValue="profile">
        <TabsList><TabsTrigger value="profile">Profile</TabsTrigger><TabsTrigger value="access">Access</TabsTrigger><TabsTrigger value="activity">Activity</TabsTrigger></TabsList>
        <TabsContent value="profile"><Card><CardContent className="grid gap-3 sm:grid-cols-2">
          <div><p className="text-xs text-muted-foreground">Email</p><p>{user.email}</p></div>
          <div><p className="text-xs text-muted-foreground">Status</p><StatusBadge status={user.status} /></div>
        </CardContent></Card></TabsContent>
        <TabsContent value="access"><Card><CardContent><p className="font-medium">{user.role}</p><p className="text-sm text-muted-foreground">Scope: {user.scope}</p></CardContent></Card></TabsContent>
        <TabsContent value="activity"><AuditTable data={audit} /></TabsContent>
      </Tabs>
    </>
  );
}
