import { PageHeader } from "@/components/app/page-header";
import { AuditTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Audit log" };

export default async function AuditPage() {
  const { data, preview } = await api.audit();
  return (
    <>
      <PageHeader title="Audit log" description="Who changed what, and when." crumbs={[{ label: "Organisation", href: "/org" }, { label: "Audit log" }]} preview={preview} />
      <AuditTable data={data} />
    </>
  );
}
