import { Plus } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { PreviewAction } from "@/features/forms";
import { NamedTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Categories" };

export default async function Page() {
  const { data, preview } = await api.categories();
  return (
    <>
      <PageHeader title="Categories" description="Organisation-wide catalogue structure." crumbs={[{ label: "Catalogue", href: "/org/catalog/products" }, { label: "Categories" }]} preview={preview} actions={<PreviewAction label="Add" icon={<Plus />} />} />
      <NamedTable data={data} noun="Category" />
    </>
  );
}
