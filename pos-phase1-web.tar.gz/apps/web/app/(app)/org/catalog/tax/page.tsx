import { Plus } from "lucide-react";
import { PageHeader } from "@/components/app/page-header";
import { PreviewAction } from "@/features/forms";
import { TaxTable } from "@/features/tables";
import { api } from "@/features/api";

export const metadata = { title: "Tax groups" };

export default async function Page() {
  const { data, preview } = await api.taxGroups();
  return (
    <>
      <PageHeader title="Tax groups" description="Organisation-wide catalogue structure." crumbs={[{ label: "Catalogue", href: "/org/catalog/products" }, { label: "Tax groups" }]} preview={preview} actions={<PreviewAction label="Add" icon={<Plus />} />} />
      <TaxTable data={data} />
    </>
  );
}
