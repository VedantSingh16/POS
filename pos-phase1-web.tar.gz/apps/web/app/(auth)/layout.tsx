export default function AuthLayout({ children }: LayoutProps<"/">) {
  return <main className="grid min-h-screen place-items-center bg-sidebar px-4 py-10">{children}</main>;
}
