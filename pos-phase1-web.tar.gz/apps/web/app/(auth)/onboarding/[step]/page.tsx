import Link from "next/link";
import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PreviewBadge } from "@/components/data/primitives";
import { cn } from "@/lib/utils";

const STEPS = [
  { slug: "welcome", label: "Welcome", text: "A few minutes to get your organisation ready to sell." },
  { slug: "organization", label: "Organisation", text: "Name, currency and time zone." },
  { slug: "administrator", label: "Administrator", text: "The first person with full access." },
  { slug: "stores", label: "Stores", text: "Add your first store and its registers." },
  { slug: "roles", label: "Roles", text: "Review the default roles." },
  { slug: "users", label: "Users", text: "Invite your team." },
  { slug: "tax-receipts", label: "Tax & receipts", text: "GST defaults and receipt numbering." },
  { slug: "review", label: "Review", text: "Check everything, then finish." },
];

export function generateStaticParams() { return STEPS.map((s) => ({ step: s.slug })); }

export default async function Onboarding({ params }: PageProps<"/onboarding/[step]">) {
  const { step } = await params;
  const i = STEPS.findIndex((s) => s.slug === step);
  if (i === -1) notFound();
  const cur = STEPS[i];
  const prev = STEPS[i - 1]; const next = STEPS[i + 1];
  return (
    <Card className="w-full max-w-2xl"><CardContent className="grid gap-6 p-6">
      <ol className="flex flex-wrap gap-2 text-xs" aria-label="Progress">{STEPS.map((s, j) => (
        <li key={s.slug} aria-current={j === i ? "step" : undefined} className={cn("flex items-center gap-1 rounded-full px-2.5 py-1", j === i ? "bg-primary text-primary-foreground" : j < i ? "bg-success-soft text-success" : "bg-muted text-muted-foreground")}>{j < i && <Check className="size-3" />}{s.label}</li>))}</ol>
      <div><div className="flex items-center gap-2"><h1 className="text-xl font-semibold">{cur.label}</h1><PreviewBadge /></div><p className="mt-1 text-sm text-muted-foreground">{cur.text}</p></div>
      <div className="flex justify-between">
        {prev ? <Link href={`/onboarding/${prev.slug}`} className={buttonVariants({ variant: "outline", size: "touch" })}>Back</Link> : <span />}
        {next ? <Link href={`/onboarding/${next.slug}`} className={buttonVariants({ size: "touch" })}>Continue</Link> : <Link href="/org" className={buttonVariants({ size: "touch" })}>Finish</Link>}
      </div>
    </CardContent></Card>
  );
}
