import { LockScreen } from "@/features/auth/lock-screen";

export const metadata = { title: "Locked" };
export default function LockPage() { return <LockScreen />; }
