import { notFound } from "next/navigation";
import { PosScreen } from "@/features/pos/pos-screen";
import { api } from "@/features/api";

export const metadata = { title: "Point of sale" };

export default async function PosPage({ params }: PageProps<"/s/[storeId]/pos">) {
  const { storeId } = await params;
  const [{ data: store, preview }, { data: products }, { data: categories }] = await Promise.all([api.store(storeId), api.products(), api.categories()]);
  if (!store) notFound();
  return <PosScreen storeId={storeId} storeName={store.name} preview={preview} products={products} categories={categories.map((c) => c.name)} />;
}
