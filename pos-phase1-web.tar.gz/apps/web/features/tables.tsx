"use client";
// Column definitions for every list page. One DataTable, many column sets.
import Link from "next/link";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/data/data-table";
import { Money, StatusBadge } from "@/components/data/primitives";
import { Badge } from "@/components/ui/badge";
import { formatNumber, timeAgo } from "@/lib/format";
import type * as M from "@/mocks/data";

type Row<T> = ColumnDef<T, unknown>[];
type Of<T extends readonly unknown[]> = T[number];
const when = (v: string) => (v ? <span className="text-muted-foreground" title={v}>{timeAgo(v)}</span> : <span className="text-muted-foreground">—</span>);
const mono = (v: string) => <span className="font-mono text-xs">{v}</span>;
const num = (v: number) => <span className="tabular">{formatNumber(v)}</span>;

type User = Of<typeof M.users>;
export function UsersTable({ data }: { data: User[] }) {
  const cols: Row<User> = [
    { accessorKey: "name", header: "Name", cell: (c) => <Link href={`/org/users/${c.row.original.id}`} className="font-medium hover:underline">{c.getValue() as string}</Link> },
    { accessorKey: "email", header: "Email" },
    { accessorKey: "role", header: "Role" },
    { accessorKey: "scope", header: "Scope" },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
    { accessorKey: "lastLogin", header: "Last sign-in", cell: (c) => when(c.getValue() as string) },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/org/users/${r.id}`} searchPlaceholder="Search users…" emptyTitle="No users yet" emptyDescription="Invite your first teammate to get started." />;
}

type Role = Of<typeof M.roles>;
export function RolesTable({ data }: { data: Role[] }) {
  const cols: Row<Role> = [
    { accessorKey: "name", header: "Role", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "description", header: "Description" },
    { accessorKey: "users", header: "Users", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "permissions", header: "Permissions", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "system", header: "Type", cell: (c) => <Badge tone={c.getValue() ? "brand" : "neutral"}>{c.getValue() ? "System" : "Custom"}</Badge> },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/org/roles/${r.id}`} searchPlaceholder="Search roles…" />;
}

type Store = Of<typeof M.stores>;
export function StoresTable({ data }: { data: Store[] }) {
  const cols: Row<Store> = [
    { accessorKey: "code", header: "Code", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "name", header: "Store", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "city", header: "City" },
    { accessorKey: "registers", header: "Registers", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "staff", header: "Staff", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/org/stores/${r.id}`} searchPlaceholder="Search stores…" />;
}

type Product = M.Product;
export function ProductsTable({ data }: { data: Product[] }) {
  const cols: Row<Product> = [
    { accessorKey: "sku", header: "SKU", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "name", header: "Product", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "category", header: "Category" },
    { accessorKey: "barcode", header: "Barcode", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "priceMinor", header: "Price", cell: (c) => <Money minor={c.getValue() as number} /> },
    { accessorKey: "taxRate", header: "GST", cell: (c) => <span className="tabular">{c.getValue() as number}%</span> },
    { accessorKey: "stock", header: "Stock", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/org/catalog/products/${r.id}`} searchPlaceholder="Search name, SKU or barcode…" />;
}

type Named = { id: string; name: string; products: number };
export function NamedTable({ data, noun }: { data: Named[]; noun: string }) {
  const cols: Row<Named> = [
    { accessorKey: "name", header: noun, cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "products", header: "Products", cell: (c) => num(c.getValue() as number) },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder={`Search ${noun.toLowerCase()}…`} />;
}

type Tax = Of<typeof M.taxGroups>;
export function TaxTable({ data }: { data: Tax[] }) {
  const cols: Row<Tax> = [
    { accessorKey: "name", header: "Tax group", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "rate", header: "Rate", cell: (c) => <span className="tabular">{c.getValue() as number}%</span> },
    { accessorKey: "products", header: "Products", cell: (c) => num(c.getValue() as number) },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search tax groups…" />;
}

type Customer = Of<typeof M.customers>;
export function CustomersTable({ data }: { data: Customer[] }) {
  const cols: Row<Customer> = [
    { accessorKey: "name", header: "Customer", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "phone", header: "Phone" },
    { accessorKey: "tier", header: "Tier", cell: (c) => <Badge tone="brand">{c.getValue() as string}</Badge> },
    { accessorKey: "walletMinor", header: "Wallet", cell: (c) => <Money minor={c.getValue() as number} /> },
    { accessorKey: "lifetimeMinor", header: "Lifetime spend", cell: (c) => <Money minor={c.getValue() as number} /> },
    { accessorKey: "lastVisit", header: "Last visit", cell: (c) => when(c.getValue() as string) },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/org/customers/${r.id}`} searchPlaceholder="Search name or phone…" />;
}

type Sale = Of<typeof M.sales>;
export function SalesTable({ data, storeId }: { data: Sale[]; storeId: string }) {
  const cols: Row<Sale> = [
    { accessorKey: "receipt", header: "Receipt", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "at", header: "When", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "cashier", header: "Cashier" },
    { accessorKey: "register", header: "Register" },
    { accessorKey: "items", header: "Items", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "tender", header: "Tender" },
    { accessorKey: "totalMinor", header: "Total", cell: (c) => <Money minor={c.getValue() as number} /> },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => `/s/${storeId}/sales/${r.id}`} searchPlaceholder="Search receipt or cashier…" />;
}

type Ret = Of<typeof M.returns>;
export function ReturnsTable({ data }: { data: Ret[] }) {
  const cols: Row<Ret> = [
    { accessorKey: "number", header: "Credit note", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "receipt", header: "Original receipt", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "at", header: "When", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "reason", header: "Reason" },
    { accessorKey: "method", header: "Refund to" },
    { accessorKey: "refundMinor", header: "Refund", cell: (c) => <Money minor={c.getValue() as number} /> },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search credit note or receipt…" />;
}

type Inv = Of<typeof M.inventory>;
export function InventoryTable({ data }: { data: Inv[] }) {
  const cols: Row<Inv> = [
    { accessorKey: "sku", header: "SKU", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "name", header: "Product", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "onHand", header: "On hand", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "reorderLevel", header: "Reorder level", cell: (c) => num(c.getValue() as number) },
    { accessorKey: "status", header: "Stock", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search product or SKU…" />;
}

type Led = Of<typeof M.ledger>;
export function LedgerTable({ data }: { data: Led[] }) {
  const cols: Row<Led> = [
    { accessorKey: "at", header: "When", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "name", header: "Product", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "type", header: "Type", cell: (c) => <Badge>{c.getValue() as string}</Badge> },
    { accessorKey: "qty", header: "Qty", cell: (c) => { const v = c.getValue() as number; return <span className={`tabular font-medium ${v < 0 ? "text-danger" : "text-success"}`}>{v > 0 ? `+${v}` : v}</span>; } },
    { accessorKey: "ref", header: "Reference" },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search ledger…" />;
}

type Reg = Of<typeof M.registers>;
export function RegistersTable({ data, storeId }: { data: Reg[]; storeId: string }) {
  const cols: Row<Reg> = [
    { accessorKey: "name", header: "Register", cell: (c) => <span className="font-medium">{c.getValue() as string}</span> },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
    { accessorKey: "cashier", header: "Cashier" },
    { accessorKey: "openedAt", header: "Opened", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "expectedMinor", header: "Expected cash", cell: (c) => <Money minor={c.getValue() as number} /> },
  ];
  return <DataTable columns={cols} data={data} rowHref={(r) => (r.sessionId ? `/s/${storeId}/registers/${r.sessionId}` : `/s/${storeId}/registers`)} searchPlaceholder="Search registers…" />;
}

type Appr = Of<typeof M.approvals>;
export function ApprovalsTable({ data }: { data: Appr[] }) {
  const cols: Row<Appr> = [
    { accessorKey: "at", header: "When", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "type", header: "Type", cell: (c) => <Badge>{(c.getValue() as string).replaceAll("_", " ")}</Badge> },
    { accessorKey: "requestedBy", header: "Requested by" },
    { accessorKey: "detail", header: "Detail" },
    { accessorKey: "status", header: "Status", cell: (c) => <StatusBadge status={c.getValue() as string} /> },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search approvals…" />;
}

type Aud = Of<typeof M.audit>;
export function AuditTable({ data }: { data: Aud[] }) {
  const cols: Row<Aud> = [
    { accessorKey: "at", header: "When", cell: (c) => when(c.getValue() as string) },
    { accessorKey: "actor", header: "Actor" },
    { accessorKey: "action", header: "Action", cell: (c) => mono(c.getValue() as string) },
    { accessorKey: "entity", header: "Entity" },
    { accessorKey: "detail", header: "Detail" },
  ];
  return <DataTable columns={cols} data={data} searchPlaceholder="Search audit log…" />;
}
