"use client";
import * as React from "react";
import { Delete, Lock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function LockScreen() {
  const [pin, setPin] = React.useState("");
  const press = (d: string) => setPin((p) => { const n = (p + d).slice(0, 6); if (n.length === 6) { toast.info("Preview only: PIN unlock is not connected yet."); return ""; } return n; });
  return (
    <Card className="w-full max-w-xs"><CardContent className="grid gap-4 p-6 text-center">
      <Lock className="mx-auto size-6 text-muted-foreground" /><h1 className="text-lg font-semibold">Till locked</h1>
      <div role="status" aria-label={`${pin.length} of 6 digits entered`} className="flex justify-center gap-2">{Array.from({ length: 6 }, (_, i) => <span key={i} className={`size-3 rounded-full border ${i < pin.length ? "bg-primary" : ""}`} />)}</div>
      <div className="grid grid-cols-3 gap-2">
        {"123456789".split("").map((d) => <Button key={d} size="touch" variant="outline" onClick={() => press(d)}>{d}</Button>)}
        <span /><Button size="touch" variant="outline" onClick={() => press("0")}>0</Button>
        <Button size="touch" variant="ghost" aria-label="Delete" onClick={() => setPin((p) => p.slice(0, -1))}><Delete /></Button>
      </div>
    </CardContent></Card>
  );
}
