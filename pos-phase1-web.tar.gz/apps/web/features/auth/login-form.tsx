"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/form/field";
import { PreviewBadge } from "@/components/data/primitives";

const schema = z.object({ email: z.string().trim().toLowerCase().email("Enter a valid email address"), password: z.string().min(1, "Enter your password") });
type In = z.input<typeof schema>;

export function LoginForm() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<In>({ resolver: zodResolver(schema), defaultValues: { email: "", password: "" } });
  return (
    <Card className="w-full max-w-sm"><CardContent className="grid gap-5 p-6">
      <div><div className="mb-3 flex items-center gap-2"><span className="grid size-8 place-items-center rounded-md bg-primary text-sm font-bold text-primary-foreground">D</span><PreviewBadge /></div>
        <h1 className="text-xl font-semibold">Sign in</h1><p className="text-sm text-muted-foreground">Use your work email. Sign-in is wired up in Phase 2.</p></div>
      <form className="grid gap-4" noValidate onSubmit={handleSubmit(async () => { toast.info("Preview only: authentication is not connected yet."); })}>
        <Field label="Email" htmlFor="email" error={errors.email?.message}><Input id="email" type="email" autoComplete="username" aria-invalid={!!errors.email} {...register("email")} /></Field>
        <Field label="Password" htmlFor="password" error={errors.password?.message}><Input id="password" type="password" autoComplete="current-password" aria-invalid={!!errors.password} {...register("password")} /></Field>
        <Button type="submit" disabled={isSubmitting}>Sign in</Button>
      </form>
    </CardContent></Card>
  );
}
