"use client";
import * as React from "react";

type Group = { group: string; codes: string[] };

/** Preview matrix: selections are local state only until the API is connected. */
export function PermissionMatrix({ groups, readOnly }: { groups: Group[]; readOnly?: boolean }) {
  const [on, setOn] = React.useState<Set<string>>(() => new Set(groups.flatMap((g) => g.codes).filter((_, i) => i % 3 !== 1)));
  const toggle = (code: string) => setOn((s) => { const n = new Set(s); if (n.has(code)) n.delete(code); else n.add(code); return n; });
  return (
    <div className="grid gap-5 md:grid-cols-2">
      {groups.map((g) => (
        <fieldset key={g.group} disabled={readOnly} className="min-w-0">
          <legend className="mb-2 text-sm font-semibold">{g.group}</legend>
          <ul className="grid gap-1.5">
            {g.codes.map((code) => (
              <li key={code}>
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" className="size-4 accent-[var(--primary)]" checked={on.has(code)} onChange={() => toggle(code)} />
                  <span className="font-mono text-xs">{code}</span>
                </label>
              </li>
            ))}
          </ul>
        </fieldset>
      ))}
    </div>
  );
}
