"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect } from "@/components/ui/input";
import { Field } from "@/components/form/field";
import { FormSheet } from "@/components/form/dialogs";
import { SheetClose } from "@/components/ui/sheet";

const userSchema = z.object({
  name: z.string().trim().min(2, "Enter the full name"),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  role: z.string().min(1, "Choose a role"),
});
type UserInput = z.input<typeof userSchema>;

export function InviteUserSheet({ roles }: { roles: string[] }) {
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<UserInput>({ resolver: zodResolver(userSchema), defaultValues: { name: "", email: "", role: "" } });
  return (
    <FormSheet trigger={<Button><Plus /> Invite user</Button>} title="Invite user" description="Creates the user and assigns a role. Saving is disabled until the API is connected (Phase 2).">
      <form className="grid gap-4" onSubmit={handleSubmit(async () => { toast.info("Preview only: nothing was saved."); reset(); })} noValidate>
        <Field label="Full name" htmlFor="u-name" error={errors.name?.message}><Input id="u-name" aria-invalid={!!errors.name} {...register("name")} /></Field>
        <Field label="Email" htmlFor="u-email" error={errors.email?.message} hint="Stored in lowercase."><Input id="u-email" type="email" aria-invalid={!!errors.email} {...register("email")} /></Field>
        <Field label="Role" htmlFor="u-role" error={errors.role?.message}>
          <NativeSelect id="u-role" aria-invalid={!!errors.role} {...register("role")}>
            <option value="">Select a role…</option>
            {roles.map((r) => <option key={r}>{r}</option>)}
          </NativeSelect>
        </Field>
        <div className="flex justify-end gap-2 pt-2">
          <SheetClose asChild><Button type="button" variant="outline">Cancel</Button></SheetClose>
          <Button type="submit" disabled={isSubmitting}>Send invite</Button>
        </div>
      </form>
    </FormSheet>
  );
}

const storeSchema = z.object({ code: z.string().trim().min(2, "At least 2 characters").max(10).toUpperCase(), name: z.string().trim().min(2, "Enter a store name"), city: z.string().trim().min(2, "Enter a city") });
type StoreInput = z.input<typeof storeSchema>;

export function NewStoreSheet({ used, max }: { used: number; max: number }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<StoreInput>({ resolver: zodResolver(storeSchema), defaultValues: { code: "", name: "", city: "" } });
  const full = used >= max;
  return (
    <FormSheet trigger={<Button disabled={full} title={full ? "Store limit reached" : undefined}><Plus /> New store</Button>} title="New store" description={`${used} of ${max} stores used.`}>
      <form className="grid gap-4" onSubmit={handleSubmit(() => { toast.info("Preview only: nothing was saved."); reset(); })} noValidate>
        <Field label="Store code" htmlFor="s-code" error={errors.code?.message}><Input id="s-code" {...register("code")} /></Field>
        <Field label="Name" htmlFor="s-name" error={errors.name?.message}><Input id="s-name" {...register("name")} /></Field>
        <Field label="City" htmlFor="s-city" error={errors.city?.message}><Input id="s-city" {...register("city")} /></Field>
        <div className="flex justify-end gap-2 pt-2"><SheetClose asChild><Button type="button" variant="outline">Cancel</Button></SheetClose><Button type="submit">Create store</Button></div>
      </form>
    </FormSheet>
  );
}

export function PreviewAction({ label, icon, variant = "default" }: { label: string; icon?: React.ReactNode; variant?: "default" | "outline" }) {
  return <Button variant={variant} onClick={() => toast.info(`${label}: preview only, not connected to the API yet.`)}>{icon}{label}</Button>;
}
