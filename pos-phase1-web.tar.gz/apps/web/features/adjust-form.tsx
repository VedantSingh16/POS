"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input, NativeSelect } from "@/components/ui/input";
import { Field } from "@/components/form/field";
import { ConfirmDialog } from "@/components/form/dialogs";

const schema = z.object({
  sku: z.string().trim().min(1, "Enter a SKU"),
  quantity: z.coerce.number().int("Whole units only").refine((n) => n !== 0, "Quantity cannot be zero"),
  reason: z.enum(["DAMAGE", "COUNT", "RECEIPT", "OTHER"]),
});
type In = z.input<typeof schema>;
type Out = z.output<typeof schema>;

export function AdjustStockForm() {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<In, unknown, Out>({ resolver: zodResolver(schema), defaultValues: { sku: "", quantity: 0, reason: "COUNT" } });
  const onValid = () => { toast.info("Preview only: nothing was saved."); reset(); };
  return (
    <Card className="max-w-xl"><CardContent>
      <form className="grid gap-4" onSubmit={handleSubmit(onValid)} noValidate>
        <Field label="SKU" htmlFor="a-sku" error={errors.sku?.message}><Input id="a-sku" {...register("sku")} /></Field>
        <Field label="Quantity change" htmlFor="a-qty" hint="Use a negative number to remove stock." error={errors.quantity?.message}><Input id="a-qty" type="number" {...register("quantity")} /></Field>
        <Field label="Reason" htmlFor="a-reason"><NativeSelect id="a-reason" {...register("reason")}><option value="COUNT">Stock count</option><option value="DAMAGE">Damage</option><option value="RECEIPT">Goods received</option><option value="OTHER">Other</option></NativeSelect></Field>
        <div className="flex justify-end gap-2">
          <ConfirmDialog trigger={<Button type="button" variant="outline">Clear</Button>} title="Clear the form?" description="Entered values will be discarded." confirmLabel="Clear" destructive onConfirm={() => reset()} />
          <Button type="submit">Record adjustment</Button>
        </div>
      </form>
    </CardContent></Card>
  );
}
