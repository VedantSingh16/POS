// Single seam between pages and data. Phase 1: every function returns preview fixtures.
// Phase 2 swaps individual functions to the real API (session cookie + BFF) without touching pages.
import * as m from "@/mocks/data";

export type Result<T> = { data: T; preview: boolean };
const preview = <T,>(data: T): Promise<Result<T>> => Promise.resolve({ data, preview: true });

export const api = {
  org: () => preview(m.org),
  stores: () => preview(m.stores),
  store: (id: string) => preview(m.stores.find((s) => s.id === id) ?? null),
  users: () => preview(m.users),
  user: (id: string) => preview(m.users.find((u) => u.id === id) ?? null),
  roles: () => preview(m.roles),
  role: (id: string) => preview(m.roles.find((r) => r.id === id) ?? null),
  permissionGroups: () => preview(m.permissionGroups),
  products: () => preview(m.products),
  product: (id: string) => preview(m.products.find((p) => p.id === id) ?? null),
  categories: () => preview(m.categories),
  brands: () => preview(m.brands),
  taxGroups: () => preview(m.taxGroups),
  customers: () => preview(m.customers),
  customer: (id: string) => preview(m.customers.find((c) => c.id === id) ?? null),
  sales: () => preview(m.sales),
  sale: (id: string) => preview(m.sales.find((s) => s.id === id) ?? null),
  returns: () => preview(m.returns),
  inventory: () => preview(m.inventory),
  ledger: () => preview(m.ledger),
  registers: () => preview(m.registers),
  registerSession: (id: string) => preview(m.registers.find((r) => r.sessionId === id) ?? null),
  approvals: () => preview(m.approvals),
  alerts: () => preview(m.alerts),
  audit: () => preview(m.audit),
  charts: () => preview({ trend: m.salesTrend, byHour: m.salesByHour, tender: m.tenderMix }),
};
