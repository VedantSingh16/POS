"use client";
import * as React from "react";
import Link from "next/link";
import { ArrowLeft, Minus, PauseCircle, Plus, Search, ShoppingCart, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Money, PreviewBadge } from "@/components/data/primitives";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { formatMoney } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { Product } from "@/mocks/data";

type Line = { product: Product; qty: number };

export function PosScreen({ storeId, storeName, preview, products, categories }: { storeId: string; storeName: string; preview: boolean; products: Product[]; categories: string[] }) {
  const [category, setCategory] = React.useState<string>("Quick keys");
  const [query, setQuery] = React.useState("");
  const [lines, setLines] = React.useState<Line[]>([]);
  const [payOpen, setPayOpen] = React.useState(false);
  const searchRef = React.useRef<HTMLInputElement>(null);

  const visible = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => (q ? p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || p.barcode.includes(q) : category === "Quick keys" ? p.hot : p.category === category));
  }, [products, query, category]);

  const add = React.useCallback((p: Product) => {
    if (p.stock <= 0) { toast.warning(`${p.name} is out of stock`); return; }
    setLines((ls) => {
      const i = ls.findIndex((l) => l.product.id === p.id);
      if (i === -1) return [...ls, { product: p, qty: 1 }];
      return ls.map((l, j) => (j === i ? { ...l, qty: Math.min(l.qty + 1, p.stock) } : l));
    });
  }, []);
  const setQty = (id: string, delta: number) => setLines((ls) => ls.flatMap((l) => (l.product.id !== id ? [l] : l.qty + delta <= 0 ? [] : [{ ...l, qty: Math.min(l.qty + delta, l.product.stock) }])));
  const remove = (id: string) => setLines((ls) => ls.filter((l) => l.product.id !== id));

  // Prices are tax-inclusive. Tax portion = gross * rate / (100 + rate), rounded per line.
  const gross = lines.reduce((a, l) => a + l.product.priceMinor * l.qty, 0);
  const tax = lines.reduce((a, l) => a + Math.round((l.product.priceMinor * l.qty * l.product.taxRate) / (100 + l.product.taxRate)), 0);
  const itemCount = lines.reduce((a, l) => a + l.qty, 0);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      const typing = t.tagName === "INPUT" || t.tagName === "TEXTAREA";
      if (e.key === "/" && !typing) { e.preventDefault(); searchRef.current?.focus(); }
      if (e.key === "F9" && lines.length) { e.preventDefault(); setPayOpen(true); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lines.length]);

  const tabs = ["Quick keys", ...categories];

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="flex h-12 shrink-0 items-center gap-3 border-b bg-card px-3">
        <Button variant="ghost" size="sm" asChild><Link href={`/s/${storeId}`}><ArrowLeft /> Exit</Link></Button>
        <span className="font-semibold">{storeName}</span><span className="text-sm text-muted-foreground">Till 1 · Priya Shah</span>
        {preview && <PreviewBadge />}
        <span className="ml-auto hidden text-xs text-muted-foreground md:block"><kbd className="rounded border bg-muted px-1">/</kbd> search · <kbd className="rounded border bg-muted px-1">F9</kbd> pay</span>
      </header>
      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <nav aria-label="Categories" className="flex shrink-0 gap-1 overflow-x-auto border-b bg-card p-2 md:w-40 md:flex-col md:overflow-y-auto md:border-b-0 md:border-r">
          {tabs.map((c) => (
            <button key={c} onClick={() => { setCategory(c); setQuery(""); }} aria-pressed={category === c && !query}
              className={cn("h-11 shrink-0 rounded-md px-3 text-left text-sm font-medium hover:bg-accent", category === c && !query && "bg-primary text-primary-foreground hover:bg-primary")}>{c}</button>
          ))}
        </nav>
        <section aria-label="Products" className="flex min-h-0 flex-1 flex-col">
          <div className="relative border-b bg-card p-2">
            <Search className="pointer-events-none absolute left-5 top-5 size-4 text-muted-foreground" />
            <Input ref={searchRef} value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search products or scan barcode" placeholder="Scan barcode or search…" className="h-11 pl-9! text-base"
              onKeyDown={(e) => { if (e.key === "Enter" && visible[0]) { add(visible[0]); setQuery(""); } }} />
          </div>
          <div className="grid flex-1 content-start gap-2 overflow-y-auto p-2 [grid-template-columns:repeat(auto-fill,minmax(9.5rem,1fr))]">
            {visible.length === 0 && <p className="col-span-full py-10 text-center text-sm text-muted-foreground">No products match.</p>}
            {visible.map((p) => (
              <button key={p.id} onClick={() => add(p)} disabled={p.stock <= 0}
                className="flex min-h-24 flex-col justify-between rounded-lg border bg-card p-3 text-left hover:border-primary hover:bg-accent disabled:cursor-not-allowed disabled:opacity-50">
                <span className="line-clamp-2 text-sm font-medium">{p.name}</span>
                <span className="flex items-end justify-between"><Money minor={p.priceMinor} /><span className={cn("text-xs", p.stock <= 5 ? "text-danger" : "text-muted-foreground")}>{p.stock <= 0 ? "Out" : `${p.stock} left`}</span></span>
              </button>
            ))}
          </div>
        </section>
        <aside aria-label="Cart" className="flex h-[45vh] shrink-0 flex-col border-t bg-card md:h-auto md:w-96 md:border-l md:border-t-0">
          <div className="flex items-center justify-between border-b px-4 py-3"><h2 className="flex items-center gap-2 font-semibold"><ShoppingCart className="size-4" /> Cart <span className="tabular text-sm text-muted-foreground">({itemCount})</span></h2>
            <Button variant="ghost" size="sm" disabled={!lines.length} onClick={() => { setLines([]); toast.info("Sale held (preview)"); }}><PauseCircle /> Hold</Button></div>
          <ul className="min-h-0 flex-1 divide-y overflow-y-auto">
            {lines.length === 0 && <li className="p-8 text-center text-sm text-muted-foreground">Cart is empty. Scan or tap a product.</li>}
            {lines.map((l) => (
              <li key={l.product.id} className="flex items-center gap-2 px-3 py-2">
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{l.product.name}</p><p className="tabular text-xs text-muted-foreground">{formatMoney(l.product.priceMinor)} · GST {l.product.taxRate}%</p></div>
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="icon" aria-label={`Decrease ${l.product.name}`} onClick={() => setQty(l.product.id, -1)}><Minus /></Button>
                  <span className="tabular w-7 text-center font-medium" aria-live="polite">{l.qty}</span>
                  <Button variant="outline" size="icon" aria-label={`Increase ${l.product.name}`} onClick={() => setQty(l.product.id, 1)}><Plus /></Button>
                </div>
                <Money minor={l.product.priceMinor * l.qty} className="w-20 text-right" />
                <Button variant="ghost" size="icon" aria-label={`Remove ${l.product.name}`} onClick={() => remove(l.product.id)}><Trash2 /></Button>
              </li>
            ))}
          </ul>
          <div className="space-y-1 border-t p-4">
            <div className="flex justify-between text-sm text-muted-foreground"><span>Subtotal (excl. GST)</span><Money minor={gross - tax} className="font-normal" /></div>
            <div className="flex justify-between text-sm text-muted-foreground"><span>GST</span><Money minor={tax} className="font-normal" /></div>
            <div className="flex items-baseline justify-between pt-1"><span className="font-semibold">Total</span><Money minor={gross} className="text-2xl font-semibold" /></div>
            <Button size="touch" className="mt-3 w-full" disabled={!lines.length} onClick={() => setPayOpen(true)}>Pay {lines.length ? formatMoney(gross) : ""}</Button>
          </div>
        </aside>
      </div>
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent>
          <DialogTitle>Take payment</DialogTitle>
          <DialogDescription>Payments are not connected yet (Phase 3). Choosing a tender only clears the cart.</DialogDescription>
          <p className="tabular text-3xl font-semibold">{formatMoney(gross)}</p>
          <div className="grid grid-cols-3 gap-2">
            {["Cash", "UPI", "Card"].map((t) => (
              <DialogClose asChild key={t}><Button size="touch" variant="outline" onClick={() => { setLines([]); toast.success(`Preview sale paid by ${t}`); }}>{t}</Button></DialogClose>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
