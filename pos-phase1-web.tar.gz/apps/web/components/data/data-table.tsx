"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import {
  flexRender, getCoreRowModel, getFilteredRowModel, getPaginationRowModel, getSortedRowModel,
  useReactTable, type ColumnDef, type SortingState, type VisibilityState,
} from "@tanstack/react-table";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Columns3, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { DropdownMenu as M } from "radix-ui";
import { EmptyState, ErrorState } from "./primitives";

type Props<T> = {
  columns: ColumnDef<T, unknown>[];
  data: T[];
  /** Row link, e.g. (row) => `/org/users/${row.id}`. */
  rowHref?: (row: T) => string;
  searchPlaceholder?: string;
  toolbar?: React.ReactNode;
  loading?: boolean;
  error?: string;
  emptyTitle?: string;
  emptyDescription?: string;
  pageSize?: number;
};

/** One table for every list in the product. Client-side paging here; swap to server-side with manualPagination in Phase 2+. */
export function DataTable<T>({ columns, data, rowHref, searchPlaceholder = "Search…", toolbar, loading, error, emptyTitle = "Nothing here yet", emptyDescription, pageSize = 10 }: Props<T>) {
  const router = useRouter();
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [filter, setFilter] = React.useState("");
  const [visibility, setVisibility] = React.useState<VisibilityState>({});
  const table = useReactTable({
    data, columns,
    state: { sorting, globalFilter: filter, columnVisibility: visibility },
    onSortingChange: setSorting, onGlobalFilterChange: setFilter, onColumnVisibilityChange: setVisibility,
    getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(), getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize } },
  });
  const rows = table.getRowModel().rows;
  const total = table.getFilteredRowModel().rows.length;

  return (
    <div className="rounded-lg border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b p-3">
        <div className="relative min-w-48 flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input aria-label="Search table" value={filter} onChange={(e) => setFilter(e.target.value)} placeholder={searchPlaceholder} className="pl-8!" />
        </div>
        {toolbar}
        <div className="ml-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm"><Columns3 /> Columns</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {table.getAllLeafColumns().filter((c) => c.getCanHide()).map((c) => (
                <M.CheckboxItem key={c.id} checked={c.getIsVisible()} onCheckedChange={(v) => c.toggleVisibility(!!v)} onSelect={(e) => e.preventDefault()}
                  className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm capitalize outline-none data-[highlighted]:bg-accent">
                  <span className="w-4">{c.getIsVisible() ? "✓" : ""}</span>{typeof c.columnDef.header === "string" ? c.columnDef.header : c.id}
                </M.CheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {error ? <ErrorState description={error} /> : (
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((hg) => (
              <TableRow key={hg.id} className="hover:bg-transparent">
                {hg.headers.map((h) => {
                  const sorted = h.column.getIsSorted();
                  return (
                    <TableHead key={h.id} aria-sort={sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : undefined}>
                      {h.isPlaceholder ? null : h.column.getCanSort() ? (
                        <button className="inline-flex items-center gap-1 uppercase hover:text-foreground" onClick={h.column.getToggleSortingHandler()}>
                          {flexRender(h.column.columnDef.header, h.getContext())}
                          {sorted === "asc" ? <ArrowUp className="size-3" /> : sorted === "desc" ? <ArrowDown className="size-3" /> : null}
                        </button>
                      ) : flexRender(h.column.columnDef.header, h.getContext())}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? Array.from({ length: 5 }, (_, i) => (
              <TableRow key={i}>{table.getVisibleLeafColumns().map((c) => <TableCell key={c.id}><Skeleton className="h-4 w-full max-w-32" /></TableCell>)}</TableRow>
            )) : rows.map((row) => (
              <TableRow key={row.id} data-clickable={!!rowHref}
                onClick={rowHref ? () => router.push(rowHref(row.original)) : undefined}
                onKeyDown={rowHref ? (e) => { if (e.key === "Enter") router.push(rowHref(row.original)); } : undefined}
                tabIndex={rowHref ? 0 : undefined}>
                {row.getVisibleCells().map((cell) => <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>)}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      {!loading && !error && rows.length === 0 && <EmptyState title={filter ? "No matches" : emptyTitle} description={filter ? "Try a different search term." : emptyDescription} />}

      <div className="flex items-center justify-between gap-2 border-t px-3 py-2 text-xs text-muted-foreground">
        <span className="tabular">{total} {total === 1 ? "row" : "rows"}</span>
        <div className="flex items-center gap-1">
          <span className="tabular mr-2">Page {table.getState().pagination.pageIndex + 1} of {Math.max(table.getPageCount(), 1)}</span>
          <Button variant="outline" size="icon-sm" aria-label="Previous page" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}><ChevronLeft /></Button>
          <Button variant="outline" size="icon-sm" aria-label="Next page" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}><ChevronRight /></Button>
        </div>
      </div>
    </div>
  );
}
