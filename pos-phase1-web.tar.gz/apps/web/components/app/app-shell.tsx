"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Command } from "cmdk";
import { Bell, Check, ChevronsUpDown, LogOut, Menu, Moon, PanelLeftClose, PanelLeftOpen, Search, Store as StoreIcon, Sun, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { NAV, resolveHref, type NavSection } from "@/lib/nav";
import { cn } from "@/lib/utils";

export type ShellStore = { id: string; code: string; name: string };
type Ctx = { stores: ShellStore[]; storeId: string; setPaletteOpen: (v: boolean) => void };
const ShellContext = React.createContext<Ctx | null>(null);
const useShell = () => { const c = React.useContext(ShellContext); if (!c) throw new Error("AppShell missing"); return c; };

function activeStoreId(pathname: string, fallback: string) {
  const m = pathname.match(/^\/s\/([^/]+)/);
  return m ? m[1] : fallback;
}

function isActive(pathname: string, href: string) {
  const parts = href.split("/").length;
  if (href === "/org" || /^\/s\/[^/]+$/.test(href)) return pathname === href;
  if (href.startsWith("/org/settings")) return pathname.startsWith("/org/settings");
  return pathname === href || (parts > 2 && pathname.startsWith(href + "/"));
}

function SidebarNav({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();
  const { storeId } = useShell();
  return (
    <nav aria-label="Main" className="flex-1 space-y-5 overflow-y-auto px-2 py-3">
      {NAV.map((section: NavSection) => (
        <div key={section.id}>
          {!collapsed && <p className="px-2 pb-1 text-[11px] font-semibold uppercase tracking-wider text-sidebar-muted">{section.title}</p>}
          <ul className="space-y-0.5">
            {section.items.map((item) => {
              const href = resolveHref(item.href, storeId);
              const active = isActive(pathname, href);
              return (
                <li key={item.href}>
                  <Link href={href} onClick={onNavigate} title={collapsed ? item.label : undefined} aria-current={active ? "page" : undefined}
                    className={cn("flex h-9 items-center gap-2.5 rounded-md px-2.5 text-sm text-sidebar-foreground/90 hover:bg-sidebar-accent", active && "bg-sidebar-accent font-medium text-white", collapsed && "justify-center px-0")}>
                    <item.icon className="size-4 shrink-0" />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                    {collapsed && <span className="sr-only">{item.label}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
      <div>
        <Link href="/pilot" onClick={onNavigate} className={cn("flex h-9 items-center gap-2.5 rounded-md px-2.5 text-xs text-sidebar-muted hover:bg-sidebar-accent", collapsed && "justify-center px-0")}>
          <span aria-hidden>↗</span>{!collapsed && <span>Legacy pilot console</span>}
        </Link>
      </div>
    </nav>
  );
}

function Brand({ collapsed }: { collapsed: boolean }) {
  return (
    <div className={cn("flex h-14 items-center gap-2 border-b border-white/10 px-4 text-white", collapsed && "justify-center px-0")}>
      <span className="grid size-7 place-items-center rounded-md bg-primary text-xs font-bold text-primary-foreground">D</span>
      {!collapsed && <span className="font-semibold tracking-tight">DeltCRM POS</span>}
    </div>
  );
}

function StoreSwitcher() {
  const { stores, storeId } = useShell();
  const router = useRouter();
  const pathname = usePathname();
  const current = stores.find((s) => s.id === storeId) ?? stores[0];
  const go = (id: string) => {
    // Keep the user on the same page type when switching store; the URL is the source of truth.
    const m = pathname.match(/^\/s\/[^/]+(\/[^/]+)?/);
    router.push(`/s/${id}${m?.[1] && m[1] !== "/pos" ? m[1] : ""}`);
  };
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="max-w-52 justify-between" aria-label="Switch store">
          <StoreIcon /><span className="truncate">{current?.name ?? "Select store"}</span><ChevronsUpDown className="opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start">
        <DropdownMenuLabel>Stores</DropdownMenuLabel>
        {stores.map((s) => (
          <DropdownMenuItem key={s.id} onSelect={() => go(s.id)}>
            <span className="flex-1 truncate">{s.name}</span><span className="text-xs text-muted-foreground">{s.code}</span>
            {s.id === storeId && <Check />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function CommandMenu({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  const router = useRouter();
  const { stores, storeId } = useShell();
  const run = (href: string) => { setOpen(false); router.push(href); };
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="top-24 max-w-xl translate-y-0 gap-0 overflow-hidden p-0">
        <DialogTitle className="sr-only">Command menu</DialogTitle>
        <Command label="Command menu" className="flex flex-col">
          <Command.Input autoFocus placeholder="Go to a page or switch store…" className="h-12 border-b bg-transparent px-4 text-sm outline-none" />
          <Command.List className="max-h-80 overflow-y-auto p-2">
            <Command.Empty className="px-3 py-6 text-center text-sm text-muted-foreground">No results.</Command.Empty>
            {NAV.map((section) => (
              <Command.Group key={section.id} heading={section.title} className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted-foreground">
                {section.items.map((item) => (
                  <Command.Item key={item.href} value={`${section.title} ${item.label} ${item.keywords?.join(" ") ?? ""}`} onSelect={() => run(resolveHref(item.href, storeId))}
                    className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-sm data-[selected=true]:bg-accent"><item.icon className="size-4" />{item.label}</Command.Item>
                ))}
              </Command.Group>
            ))}
            <Command.Group heading="Switch store" className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted-foreground">
              {stores.map((s) => (
                <Command.Item key={s.id} value={`switch store ${s.name} ${s.code}`} onSelect={() => run(`/s/${s.id}`)}
                  className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-sm data-[selected=true]:bg-accent"><StoreIcon className="size-4" />{s.name}<span className="ml-auto text-xs text-muted-foreground">{s.code}</span></Command.Item>
              ))}
            </Command.Group>
          </Command.List>
        </Command>
      </DialogContent>
    </Dialog>
  );
}

function ThemeToggle() {
  // The initial theme is applied by a script in the root layout; the icon follows the `dark` class via CSS.
  const toggle = () => {
    const d = document.documentElement.classList.toggle("dark");
    try { localStorage.setItem("pos-theme", d ? "dark" : "light"); } catch { /* storage unavailable */ }
  };
  return (
    <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
      <Moon className="dark:hidden" /><Sun className="hidden dark:block" />
    </Button>
  );
}

function Topbar({ orgName, onMenu }: { orgName: string; onMenu: () => void }) {
  const { setPaletteOpen, storeId } = useShell();
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-card/95 px-3 backdrop-blur sm:px-4">
      <Button variant="ghost" size="icon" className="lg:hidden" onClick={onMenu} aria-label="Open navigation"><Menu /></Button>
      <span className="hidden text-sm font-semibold sm:block">{orgName}</span>
      <span className="hidden h-5 w-px bg-border sm:block" />
      <StoreSwitcher />
      <Button variant="outline" className="ml-auto hidden w-56 justify-between text-muted-foreground sm:inline-flex" onClick={() => setPaletteOpen(true)}>
        <span className="flex items-center gap-2"><Search /> Search…</span><kbd className="rounded border bg-muted px-1.5 text-[11px]">Ctrl K</kbd>
      </Button>
      <Button variant="ghost" size="icon" className="ml-auto sm:hidden" onClick={() => setPaletteOpen(true)} aria-label="Open command menu"><Search /></Button>
      <ThemeToggle />
      <Button variant="ghost" size="icon" aria-label="Notifications" asChild><Link href={`/s/${storeId}/alerts`}><Bell /></Link></Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="User menu"><User /></Button></DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Asha Nair (preview)</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild><Link href="/lock"><Check /> Lock till</Link></DropdownMenuItem>
          <DropdownMenuItem asChild><Link href="/login"><LogOut /> Sign out</Link></DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}

export function AppShell({ stores, orgName, defaultStoreId, children }: { stores: ShellStore[]; orgName: string; defaultStoreId: string; children: React.ReactNode }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [paletteOpen, setPaletteOpen] = React.useState(false);
  const storeId = activeStoreId(pathname, defaultStoreId);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPaletteOpen((v) => !v); } };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <ShellContext.Provider value={{ stores, storeId, setPaletteOpen }}>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-card focus:px-3 focus:py-2">Skip to content</a>
      <div className="flex min-h-screen">
        <aside className={cn("sticky top-0 hidden h-screen shrink-0 flex-col bg-sidebar lg:flex", collapsed ? "w-14" : "w-60")}>
          <Brand collapsed={collapsed} />
          <SidebarNav collapsed={collapsed} />
          <button onClick={() => setCollapsed((v) => !v)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="m-2 flex h-9 items-center justify-center rounded-md text-sidebar-muted hover:bg-sidebar-accent">
            {collapsed ? <PanelLeftOpen className="size-4" /> : <PanelLeftClose className="size-4" />}
          </button>
        </aside>
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="left" className="bg-sidebar">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <Brand collapsed={false} />
            <SidebarNav collapsed={false} onNavigate={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar orgName={orgName} onMenu={() => setMobileOpen(true)} />
          <main id="main" className="mx-auto w-full max-w-7xl flex-1 p-4 sm:p-6">{children}</main>
        </div>
      </div>
      <CommandMenu open={paletteOpen} setOpen={setPaletteOpen} />
    </ShellContext.Provider>
  );
}
