// Preview fixtures. Used only where the API has no endpoint (or no browser session yet, until Phase 2).
// Every page that reads from here shows a "Preview data" badge. Money is in paise.
export const org = { id: "org-preview", name: "Delt Retail Pvt Ltd", maxStores: 5 };

export const stores = [
  { id: "st-1", code: "BLR-01", name: "Indiranagar", city: "Bengaluru", status: "ACTIVE", registers: 3, staff: 9 },
  { id: "st-2", code: "BLR-02", name: "Koramangala", city: "Bengaluru", status: "ACTIVE", registers: 2, staff: 6 },
  { id: "st-3", code: "MUM-01", name: "Bandra", city: "Mumbai", status: "ACTIVE", registers: 2, staff: 7 },
  { id: "st-4", code: "PUN-01", name: "Koregaon Park", city: "Pune", status: "INACTIVE", registers: 1, staff: 0 },
];

export const users = [
  { id: "u-1", name: "Asha Nair", email: "asha@delt.example", role: "Organisation Administrator", scope: "Organisation", status: "ACTIVE", lastLogin: "2026-10-07T06:50:00Z" },
  { id: "u-2", name: "Rahul Mehta", email: "rahul@delt.example", role: "Store Manager", scope: "Indiranagar", status: "ACTIVE", lastLogin: "2026-10-07T05:12:00Z" },
  { id: "u-3", name: "Priya Shah", email: "priya@delt.example", role: "Cashier", scope: "Indiranagar", status: "ACTIVE", lastLogin: "2026-10-06T17:40:00Z" },
  { id: "u-4", name: "Imran Khan", email: "imran@delt.example", role: "Supervisor", scope: "Koramangala", status: "ACTIVE", lastLogin: "2026-10-06T12:05:00Z" },
  { id: "u-5", name: "Neha Iyer", email: "neha@delt.example", role: "Inventory User", scope: "Bandra", status: "SUSPENDED", lastLogin: "2026-09-21T09:30:00Z" },
];

export const roles = [
  { id: "r-1", name: "Organisation Administrator", description: "Full control of the organisation", users: 1, permissions: 34, system: true },
  { id: "r-2", name: "Store Manager", description: "Manage assigned store operations", users: 3, permissions: 12, system: true },
  { id: "r-3", name: "Supervisor", description: "Operational support and permitted approvals", users: 4, permissions: 10, system: true },
  { id: "r-4", name: "Cashier", description: "Normal sales and register operations", users: 14, permissions: 6, system: true },
  { id: "r-5", name: "Inventory User", description: "Catalogue and inventory-related tasks", users: 2, permissions: 5, system: true },
];

export const permissionGroups = [
  { group: "Organisation", codes: ["org.settings.manage", "org.overview.view", "audit.view"] },
  { group: "People", codes: ["users.view", "users.manage", "roles.view", "roles.manage"] },
  { group: "Stores", codes: ["stores.view", "stores.manage", "registers.view", "registers.manage"] },
  { group: "Catalogue", codes: ["catalog.view", "catalog.manage", "pricing.view", "pricing.manage", "tax.view", "tax.manage"] },
  { group: "Selling", codes: ["sale.create", "sale.hold", "sale.discount", "sale.void", "refund.create", "register.open", "register.close", "cash.manage"] },
  { group: "Inventory", codes: ["inventory.view", "inventory.manage", "transfer.manage"] },
  { group: "Other", codes: ["approval.manage", "customer.view", "customer.manage", "promotion.manage", "report.view", "report.export"] },
];

export const categories = [
  { id: "c-1", name: "Beverages", products: 42 },
  { id: "c-2", name: "Snacks", products: 58 },
  { id: "c-3", name: "Dairy", products: 21 },
  { id: "c-4", name: "Personal care", products: 37 },
  { id: "c-5", name: "Household", products: 29 },
];
export const brands = [
  { id: "b-1", name: "Himalaya Farms", products: 18 },
  { id: "b-2", name: "Kaveri", products: 26 },
  { id: "b-3", name: "Urban Pantry", products: 31 },
];
export const taxGroups = [
  { id: "t-1", name: "GST 0%", rate: 0, products: 14 },
  { id: "t-2", name: "GST 5%", rate: 5, products: 96 },
  { id: "t-3", name: "GST 12%", rate: 12, products: 41 },
  { id: "t-4", name: "GST 18%", rate: 18, products: 36 },
];

export type Product = { id: string; sku: string; barcode: string; name: string; category: string; priceMinor: number; taxRate: number; stock: number; status: "ACTIVE" | "INACTIVE"; hot: boolean };
export const products: Product[] = [
  ["Masala Chai 250ml", "Beverages", 4500, 5, 120, true], ["Filter Coffee 200g", "Beverages", 28000, 5, 36, true],
  ["Cold Brew Can", "Beverages", 9900, 12, 64, true], ["Mineral Water 1L", "Beverages", 2000, 12, 240, true],
  ["Salted Peanuts 100g", "Snacks", 3500, 12, 88, true], ["Banana Chips 150g", "Snacks", 6000, 12, 4, false],
  ["Multigrain Biscuits", "Snacks", 4000, 12, 150, true], ["Dark Chocolate 80g", "Snacks", 18000, 18, 52, true],
  ["Full Cream Milk 500ml", "Dairy", 3300, 0, 70, true], ["Paneer 200g", "Dairy", 9000, 5, 18, false],
  ["Greek Yoghurt Cup", "Dairy", 5500, 5, 0, false], ["Salted Butter 100g", "Dairy", 6200, 12, 41, false],
  ["Herbal Shampoo 200ml", "Personal care", 24900, 18, 26, false], ["Aloe Face Wash", "Personal care", 17900, 18, 33, false],
  ["Dishwash Liquid 500ml", "Household", 11500, 18, 47, false], ["Floor Cleaner 1L", "Household", 19900, 18, 12, false],
].map(([name, category, priceMinor, taxRate, stock, hot], i) => ({
  id: `p-${i + 1}`, sku: `SKU-${1000 + i}`, barcode: `890${String(1000000 + i * 137).padStart(10, "0")}`,
  name: name as string, category: category as string, priceMinor: priceMinor as number, taxRate: taxRate as number,
  stock: stock as number, status: "ACTIVE" as const, hot: hot as boolean,
}));

export const customers = [
  { id: "cu-1", name: "Sanjay Rao", phone: "+91 98450 11122", tier: "Gold", walletMinor: 25000, lifetimeMinor: 4850000, lastVisit: "2026-10-06T14:10:00Z" },
  { id: "cu-2", name: "Meera Pillai", phone: "+91 98860 33344", tier: "Silver", walletMinor: 0, lifetimeMinor: 1260000, lastVisit: "2026-10-03T10:25:00Z" },
  { id: "cu-3", name: "Arjun Desai", phone: "+91 99020 55566", tier: "Standard", walletMinor: 8000, lifetimeMinor: 310000, lastVisit: "2026-09-28T18:45:00Z" },
];

export const sales = [
  { id: "s-1", receipt: "TAX-20261007-0014", at: "2026-10-07T07:22:00Z", cashier: "Priya Shah", register: "Till 1", items: 4, totalMinor: 48650, tender: "UPI", status: "COMPLETED" },
  { id: "s-2", receipt: "TAX-20261007-0013", at: "2026-10-07T07:05:00Z", cashier: "Priya Shah", register: "Till 1", items: 2, totalMinor: 12800, tender: "CASH", status: "COMPLETED" },
  { id: "s-3", receipt: "TAX-20261007-0012", at: "2026-10-07T06:41:00Z", cashier: "Rahul Mehta", register: "Till 2", items: 7, totalMinor: 96400, tender: "CARD", status: "COMPLETED" },
  { id: "s-4", receipt: "TAX-20261007-0011", at: "2026-10-07T06:20:00Z", cashier: "Priya Shah", register: "Till 1", items: 1, totalMinor: 4500, tender: "CASH", status: "VOIDED" },
  { id: "s-5", receipt: "TAX-20261006-0097", at: "2026-10-06T19:02:00Z", cashier: "Priya Shah", register: "Till 1", items: 3, totalMinor: 33300, tender: "UPI", status: "PARTIALLY_RETURNED" },
];
export const returns = [
  { id: "rt-1", number: "CN-20261007-0002", at: "2026-10-07T06:55:00Z", receipt: "TAX-20261006-0097", reason: "Damaged item", refundMinor: 9000, method: "UPI", status: "COMPLETED" },
  { id: "rt-2", number: "CN-20261005-0001", at: "2026-10-05T16:20:00Z", receipt: "TAX-20261005-0044", reason: "Wrong size", refundMinor: 24900, method: "CASH", status: "COMPLETED" },
];
export const inventory = products.map((p) => ({ id: p.id, sku: p.sku, name: p.name, onHand: p.stock, reorderLevel: 20, status: p.stock === 0 ? "OUT" : p.stock <= 20 ? "LOW" : "OK" }));
export const ledger = [
  { id: "l-1", at: "2026-10-07T07:22:00Z", sku: "SKU-1000", name: "Masala Chai 250ml", type: "SALE", qty: -2, ref: "TAX-20261007-0014" },
  { id: "l-2", at: "2026-10-07T06:55:00Z", sku: "SKU-1014", name: "Dishwash Liquid 500ml", type: "RETURN", qty: 1, ref: "CN-20261007-0002" },
  { id: "l-3", at: "2026-10-06T09:10:00Z", sku: "SKU-1005", name: "Banana Chips 150g", type: "ADJUSTMENT", qty: -3, ref: "Damaged" },
  { id: "l-4", at: "2026-10-05T11:00:00Z", sku: "SKU-1003", name: "Mineral Water 1L", type: "RECEIPT", qty: 120, ref: "PO-8841" },
];
export const registers = [
  { id: "rg-1", name: "Till 1", status: "OPEN", cashier: "Priya Shah", openedAt: "2026-10-07T03:30:00Z", expectedMinor: 1845000, sessionId: "rs-1" },
  { id: "rg-2", name: "Till 2", status: "OPEN", cashier: "Rahul Mehta", openedAt: "2026-10-07T03:45:00Z", expectedMinor: 920000, sessionId: "rs-2" },
  { id: "rg-3", name: "Till 3", status: "CLOSED", cashier: "—", openedAt: "", expectedMinor: 0, sessionId: "" },
];
export const approvals = [
  { id: "ap-1", at: "2026-10-07T07:10:00Z", type: "DISCOUNT_OVERRIDE", requestedBy: "Priya Shah", detail: "25% off Cold Brew Can ×6", status: "PENDING" },
  { id: "ap-2", at: "2026-10-07T05:50:00Z", type: "VOID_SALE", requestedBy: "Priya Shah", detail: "Void TAX-20261007-0011", status: "APPROVED" },
];
export const alerts = [
  { id: "al-1", at: "2026-10-07T07:00:00Z", severity: "warning", title: "Low stock: Banana Chips 150g", detail: "4 left, reorder level 20" },
  { id: "al-2", at: "2026-10-07T06:00:00Z", severity: "danger", title: "Out of stock: Greek Yoghurt Cup", detail: "Zero on hand in this store" },
  { id: "al-3", at: "2026-10-06T22:30:00Z", severity: "info", title: "Till 3 was left open overnight", detail: "Session closed automatically" },
];
export const audit = [
  { id: "au-1", at: "2026-10-07T06:50:00Z", actor: "Asha Nair", action: "user.role_assigned", entity: "User u-3", detail: "Cashier @ Indiranagar" },
  { id: "au-2", at: "2026-10-07T05:30:00Z", actor: "Rahul Mehta", action: "register.opened", entity: "Till 2", detail: "Float ₹2,000.00" },
  { id: "au-3", at: "2026-10-06T16:05:00Z", actor: "Asha Nair", action: "store.created", entity: "Koramangala", detail: "BLR-02" },
];
export const salesTrend = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => ({ day, sales: [182, 204, 190, 231, 268, 342, 301][i] * 1000 }));
export const salesByHour = Array.from({ length: 12 }, (_, i) => ({ hour: `${i + 9}:00`, sales: [8, 14, 22, 31, 26, 19, 24, 33, 41, 38, 27, 12][i] * 1000 }));
export const tenderMix = [{ name: "UPI", value: 48 }, { name: "Cash", value: 27 }, { name: "Card", value: 25 }];
